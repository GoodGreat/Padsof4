package paneles;

import javax.swing.*;
import ejercicio.*;

public class VistaPreguntaBooleanaProf extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaEnunciado, etiquetaPuntuacion;
	private JButton botonCambiarPregunta;

	
	public VistaPreguntaBooleanaProf(PreguntaBooleana pregunta){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		botonCambiarPregunta = new JButton("Cambiar Pregunta");
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		if(pregunta.getFalloResta() == true){
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y en caso de fallo resta: "+ pregunta.getResta());
		} else {
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y  no resta en caso de fallo: "+ pregunta.getResta());
		}
	
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaPuntuacion, 20, SpringLayout.NORTH, this);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 20, SpringLayout.NORTH, etiquetaPuntuacion);
		
		for(Opcion opcionAux: pregunta.getOpciones()){
			JButton opcion = new JButton(opcionAux.getOpcion());
			layout.putConstraint(SpringLayout.NORTH, opcion, i, SpringLayout.NORTH, etiquetaEnunciado);
			i += 30 /*Numero de pixeles necesarios para que queden separadas*/;
		}
		
		//Ponemos la derecha del botoncambiarApunte a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCambiarPregunta, 5, SpringLayout.WEST, this);
				
	}
	
}

