package paneles;

import javax.swing.*;
import ejercicio.*;

public class VistaEjercicioProf extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JLabel etiquetaFechas;
	private JButton botonCambiarEjercicio;
	
	
	public VistaEjercicioProf(Ejercicio ejercicio){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		etiquetaNombre = new JLabel(ejercicio.getNombre());
		etiquetaFechas = new JLabel("La fehca de inicio es el " + ejercicio.getFechaIni() + 
				"y la fecha limite es el " + ejercicio.getFechaIni());
		botonCambiarEjercicio = new JButton("Cambiar Ejercicio");
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//barajeamos las preguntas para que salgan en un orden aleatorio, distinto al introducido por el profesor
		if(ejercicio.getAleatorio() == true){
			ejercicio.barajarPreguntas();
		}
		
		for(Pregunta preguntaAux: ejercicio.getPreguntas()){
			JButton pregunta = new JButton(preguntaAux.getEnunciado());
			layout.putConstraint(SpringLayout.NORTH, pregunta, i, SpringLayout.NORTH, etiquetaNombre);
			i += 30 /*Numero de pixeles necesarios para que queden separadas*/;
		}

		//Ponemos la derecha del botoncambiarApunte a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCambiarEjercicio, 5, SpringLayout.WEST, this);
		
		//Ponemos el sur de la etiquetaFechas a 5 pixeles del sur del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaFechas, 5, SpringLayout.SOUTH, this);
	}
	
}
