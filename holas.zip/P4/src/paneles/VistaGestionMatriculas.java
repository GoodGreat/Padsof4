package paneles;

import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.SpringLayout;
import javax.swing.table.DefaultTableModel;

import sistema.*;

public class VistaGestionMatriculas extends JPanel{

	private String[] titulos;
	private Object[][] filas;
	private static final long serialVersionUID = 1L;
	private JTable tabla;
	private JLabel etiquetaTitulo;
	
	public VistaGestionMatriculas(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		int i = 0;
		Sistema sistema = Sistema.getInstance();
		JLabel  etiquetaTitulo = new JLabel("GESTION DE MATRICULAS");
		// Crear un array con el t�tulo de las columnas
		String[] titulos = {"alumno", "NIA", "Asignatura", "Aceptar", "Denegar"};
		// Crear una matriz con las filas de la tabla
		Object[][] filas = new Object[sistema.getSolicitudes().size()][];
		
		for(i=0; i < sistema.getSolicitudes().size(); i++){
			{
					filas[i][0] = sistema.getSolicitudes().get(i).getAlumno().getNombre();
					filas[i][1] = sistema.getSolicitudes().get(i).getAlumno().getNumA();
					filas[i][2] = sistema.getSolicitudes().get(i).getAsignatura().getNombre();
			}
		}
		
		// Crear un DefaultTableModel con las filas y los t�tulos de la tabla
		DefaultTableModel modeloDatos = new DefaultTableModel(filas, titulos);
		
		// Crear la tabla, pasando el modelo como par�metro
		JTable tabla = new JTable(modeloDatos);
		
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaTitulo, 20, SpringLayout.NORTH, this);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, tabla, 20, SpringLayout.NORTH, etiquetaTitulo);
		
		
	}
	
	// La clase debe implementar obligatoriamente los m�todos getColumnCount, getRowCount y getValueAt
	public int getColumnCount() {
		return titulos.length;
	}
	
	// M�todo que devuelve el n�mero de columnas
	public int getRowCount() {
		return filas.length;
	}
	
	// M�todo que devuelve el n�mero de filas
	public Object getValueAt(int row, int col) {
		return filas[row][col];
	} // M�todo que devuelve el contenido de una celda
	
}
