package paneles;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import sistema.*;
import asignatura.*;
import ejercicio.*;
import layout.SpringUtilities;


public class VistaPrincipalProf extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JButton botonCrearAsig;
	private JButton botonRegistrarAlumno;
	private JButton botonGestionSolicitudes;
	private JButton botonMostrarAsig;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private JTree arbol;
	
	/**
	 * Constructor de la vista principal de profesor
	 */
	public VistaPrincipalProf(){
		SpringLayout layout1 = new SpringLayout();
		SpringLayout layout2 = new SpringLayout();
		SpringLayout layout3 = new SpringLayout();

		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
		//panel_etiquetas.setLayout(layout1);
		
		//Panel de botones 
		JPanel panel_botones = new JPanel();
		//panel_botones.setLayout(layout2);
		
		//Panel del arbol de contenido 
		JPanel panel_arbol = new JPanel();
		//panel_arbol.setLayout(layout3);
				
		this.setLayout(new BorderLayout());
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel("MENU PRINCIPAL");
		panel_etiquetas.add(etiquetaNombre);
		
		//SpringUtilities.makeCompactGrid(panel_etiquetas, 2, 2, 6, 6, 6, 6);
		panel_etiquetas.setPreferredSize(new Dimension(100, 50));
		
		botonCrearAsig = new JButton("Crear Asignatura");
		botonCrearAsig.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCrearAsig);
		
		botonMostrarAsig = new JButton("Mostrar Asignaturas");
		botonMostrarAsig.setPreferredSize(new Dimension(175,75));
		panel_botones.add(botonMostrarAsig);
		
		botonRegistrarAlumno =  new JButton("Registrar Alumno");
		botonRegistrarAlumno.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonRegistrarAlumno);
		
		botonGestionSolicitudes = new JButton("Gesti�n Solicitudes");
		botonGestionSolicitudes.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonGestionSolicitudes);
		
		int i = 0;
		int j = 0;	
		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		//layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		//Ponemos la derecha del botonCrearAsig a 5 pixeles de la izquierda del contenedor 
		//layout.putConstraint(SpringLayout.EAST, botonCrearAsig, 5, SpringLayout.WEST, this);	
		//Ponemos el norte del botonRegistrarAlumno a 5 pixeles al sur del botonCrearAsig
		//layout.putConstraint(SpringLayout.NORTH, botonRegistrarAlumno, 5, SpringLayout.SOUTH, botonCrearAsig);	
		//Ponemos el norte del botonGestionSolicitudes a 5 pixeles de la sur del botonRegistrarAlumno
		//layout.putConstraint(SpringLayout.NORTH, botonGestionSolicitudes, 5, SpringLayout.SOUTH, botonRegistrarAlumno);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode("Asignaturas");
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		arbol = new JTree (modelo);
		
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(200, 40));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		Sistema sistema = Sistema.getInstance();
		
		for(Asignatura asignaturaAux: sistema.getAsignaturas()){
			DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(asignaturaAux);
			modelo.insertNodeInto(nodo_asignatura, raiz, i);
			j = 0;
			for(Tema temaAux: asignaturaAux.getTemas()){
				DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_tema, nodo_asignatura, j);
				construirArbol(temaAux, nodo_tema);
				j++;
			}
			i++;
		}
		
		panel_arbol.add(arbol);

		this.setPreferredSize(new Dimension(400, 150));
		this.add(panel_etiquetas, BorderLayout.NORTH);
		this.add(panel_botones, BorderLayout.SOUTH);
		this.add(panel_arbol, BorderLayout.EAST);
		//layout.putConstraint(SpringLayout.NORTH, arbol, 30, SpringLayout.NORTH, etiquetaNombre);
			
	}
	
	public void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		 
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
			modelo.insertNodeInto(new DefaultMutableTreeNode(ejercicioAux), nodo, i);
			i++;
		}
		
		for(Apunte apunteAux: tema.getApuntes()){
			modelo.insertNodeInto(new DefaultMutableTreeNode(apunteAux), nodo, i);
			i++;
		}
		for(Tema temaAux: tema.getSubtemas()){
			DefaultMutableTreeNode nodo_subtema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_subtema, nodo, i);
			i++;
			
			construirArbol(temaAux, nodo_subtema);
		}
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Login
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
    public void setControlador(ActionListener controlador){
		this.botonCrearAsig.addActionListener(controlador);
		this.botonMostrarAsig.addActionListener(controlador);
	    this.botonRegistrarAlumno.addActionListener(controlador);
	 	this.botonGestionSolicitudes.addActionListener(controlador);
	}
}