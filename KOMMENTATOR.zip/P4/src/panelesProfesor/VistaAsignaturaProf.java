package panelesProfesor;

import java.awt.*;

import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import asignatura.*;
import controladoresProfesor.ControlArbolAsignatura;
import controladoresProfesor.ControlArbolTema;
import controladoresProfesor.ControlGestionAlumnos;
import controladoresProfesor.ControlVistaCambiarAsignatura;
import controladoresProfesor.ControlVistaCrearTema;
import controladoresProfesor.ControlVistaTemaProf;

/**
 * Clase que implementa la Vista de Asignatura para un Profesor
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class VistaAsignaturaProf extends JPanel {

	private static final long serialVersionUID = 1L;

	final static String PRINCIPAL = "Carta con la vista principal de Asignatura (del Profesor)";
	final static String PROF_TEMAPANEL = "Carta con la vista de asignatura del Profesor";
	final static String CREARTEMA = "Carta con la vista de crear tema";
	final static String CAMBIARASIGNATURA = "Carta con la vista de cambiar Asignatura";
	final static String PROF_GESTIONALUMS = "Carta con la vista de gestion de alumnos";
	private Asignatura asignatura;
	private JLabel etiquetaNombre;
	private JTextField nombreAlum;
	private JLabel etiquetaNombreAlum;
	private JButton botonGestionAlum;
	private JButton botonCambiarAsig;
	private JButton botonCalcularNota;
	private JButton botonCrearTema;
	private JButton botonVolver;
	private JPanel principal_asignatura;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private JTree arbol;

	/**
	 * Constructor de la vista de Asignatura
	 * @param asignatura. asignatura que se quiere mostrar
	 */
	public VistaAsignaturaProf(Asignatura asignatura) {

		CardLayout card_layout = new CardLayout();
		this.setLayout(card_layout);

		this.asignatura = asignatura;
		SpringLayout layout = new SpringLayout();

		principal_asignatura = new JPanel();
		principal_asignatura.setLayout(layout);

		// Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();

		// Panel de botones
		JPanel panel_botones = new JPanel();

		// Panel del arbol de contenido
		JPanel panel_arbol = new JPanel();

		principal_asignatura.setLayout(new BorderLayout());

		// Creamos nuestros componentes
		etiquetaNombre = new JLabel(asignatura.getNombre());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		panel_etiquetas.add(etiquetaNombre);

		botonCrearTema = new JButton("Crear Tema");
		botonCrearTema.setPreferredSize(new Dimension(150, 75));
		panel_botones.add(botonCrearTema);

		botonGestionAlum = new JButton("Gesti�n Alumnos");
		botonGestionAlum.setPreferredSize(new Dimension(150, 75));
		panel_botones.add(botonGestionAlum);

		botonCambiarAsig = new JButton("Cambiar Asignatura");
		botonCambiarAsig.setPreferredSize(new Dimension(150, 75));
		panel_botones.add(botonCambiarAsig);

		botonCalcularNota = new JButton("Calcular Nota");
		botonCalcularNota.setPreferredSize(new Dimension(150, 75));
		panel_botones.add(botonCalcularNota);

		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(150, 75));
		panel_botones.add(botonVolver);

		int i = 0;

		// Ponemos el norte de la etiqueta del Nombre de la asignatura a 5
		// pixeles al norte del contenedor
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		// Ponemos la derecha del botonCrearTema a 5 pixeles de la izquierda del
		// contenedor
		layout.putConstraint(SpringLayout.EAST, botonCrearTema, 5, SpringLayout.WEST, this);
		// Ponemos el norte del botonGestionAlum a 5 pixeles al sur del
		// botonCrearTema
		layout.putConstraint(SpringLayout.NORTH, botonGestionAlum, 5, SpringLayout.SOUTH, botonCrearTema);
		// Ponemos el norte del botonCambiarAsig a 5 pixeles de la sur del
		// botonGestionAlum
		layout.putConstraint(SpringLayout.NORTH, botonCambiarAsig, 5, SpringLayout.SOUTH, botonGestionAlum);
		// Ponemos el norte del botonCalcularNota a 5 pixeles de la sur del
		// botonCambiarAsig
		layout.putConstraint(SpringLayout.NORTH, botonCalcularNota, 5, SpringLayout.SOUTH, botonCambiarAsig);
		// Ponemos el norte del botonCalcularNota a 5 pixeles de la sur del
		// botonCambiarAsig
		
		//Creamos nuestros componentes
		etiquetaNombreAlum = new JLabel("NIA del Alumno: ");
		panel_arbol.add(etiquetaNombreAlum);
		nombreAlum = new JTextField(15);
		panel_arbol.add(nombreAlum);
				
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombreAlum, 0, SpringLayout.HORIZONTAL_CENTER, panel_botones);
		layout.putConstraint(SpringLayout.SOUTH, etiquetaNombreAlum, 100, SpringLayout.NORTH, panel_botones);
		layout.putConstraint(SpringLayout.WEST, nombreAlum, 5, SpringLayout.EAST, etiquetaNombreAlum);
		layout.putConstraint(SpringLayout.NORTH, nombreAlum, 0, SpringLayout.NORTH, etiquetaNombreAlum);
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 5, SpringLayout.SOUTH, botonCalcularNota);

		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
		raiz = new DefaultMutableTreeNode(asignatura.getNombre());

		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		modelo = new DefaultTreeModel(raiz);

		// Crear el �rbol, pas�ndole el modelo de datos
		arbol = new JTree(modelo);

		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(300, 200));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);

		for (Tema temaAux : asignatura.getTemas()) {
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			// construirArbol(temaAux, nodo_tema);
			i++;
		}

		panel_arbol.add(arbol);

		// Constraints

		this.setPreferredSize(new Dimension(450, 150));
		this.principal_asignatura.add(panel_etiquetas, BorderLayout.NORTH);
		this.principal_asignatura.add(panel_botones, BorderLayout.SOUTH);
		this.principal_asignatura.add(panel_arbol, BorderLayout.EAST);

		this.add(principal_asignatura, PRINCIPAL);

		VistaCrearTema vista_crearTema = new VistaCrearTema(this);
		ControlVistaCrearTema control_crearTema = new ControlVistaCrearTema(vista_crearTema, this, this.asignatura);
		vista_crearTema.setControlador(control_crearTema);
		this.add(vista_crearTema, CREARTEMA);

		VistaCambiarAsignatura vista_cambiarAsig = new VistaCambiarAsignatura();
		ControlVistaCambiarAsignatura control_cambiarAsig = new ControlVistaCambiarAsignatura(vista_cambiarAsig, this,
				this.asignatura);
		vista_cambiarAsig.setControlador(control_cambiarAsig);
		this.add(vista_cambiarAsig, CAMBIARASIGNATURA);
	}

	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * 
	 * @author �lvaro Martinez de Navascues
	 */
	private void actualizarArbol() {

		// Borrar el arbol
		raiz.removeAllChildren();
		
		modelo.reload();

		int i = 0;

		// Construir el arbol actualizado
		for (Tema temaAux : this.asignatura.getTemas()) {
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			i++;
		}
	}

	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * 
	 * @author �lvaro Martinez de Navascues
	 */
	private void actualizar() {
		this.etiquetaNombre.setText(asignatura.getNombre());
	}

	/**
	 * Getter del boton "CrearTema"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton. El boton
	 */
	public JButton getBotonCrearTema() {
		return botonCrearTema;
	}

	/**
	 * Getter del boton "CambiarAsignatura"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton. El boton
	 */
	public JButton getBotonCambiarAsig() {
		return botonCambiarAsig;
	}

	/**
	 * Getter del boton "Gestion de Alumnos"
	 * 
	 * @author Alvaro Martinez de Navascues
	 * @return JButton. El boton
	 */
	public JButton getBotonGestionAlum() {
		return botonGestionAlum;
	}

	/**
	 * Getter del boton "Calcular Nota Alumno"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton.El boton
	 */
	public JButton getBotonCalcularNotaAlum() {
		return botonCalcularNota;
	}

	/**
	 * Getter del boton "CrearAsignatura"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton.
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}

	/**
	 * Metodo que sirve para aniadir un controlador a los botones de esta vista
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 * @param control_arbol. Controlador del arbol
	 */
	public void setControlador(ActionListener controlador, ControlArbolAsignatura control_arbol) {
		this.botonCrearTema.addActionListener(controlador);
		this.botonGestionAlum.addActionListener(controlador);
		this.botonCambiarAsig.addActionListener(controlador);
		this.botonCalcularNota.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);

		// Controlador del arbol
		arbol.addTreeSelectionListener(control_arbol);
	}

	/**
	 * Metodo que muestra la vista principal del profesor
	 * 
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaPrincipalProf() {
		this.actualizarArbol();
		this.actualizar();
		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, PRINCIPAL);
	}

	/**
	 * Metodo que muestra la vista Crear Tema del profesor
	 * 
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaCrearTema() {
		this.actualizarArbol();
		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, CREARTEMA);
	}

	/**
	 * Metodo que muestra la vista Cambiar Asignatura del profesor
	 * 
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaCambiarAsignatura() {
		this.actualizarArbol();
		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, CAMBIARASIGNATURA);
	}
	
	/**
	 * Metodo que muestra la vista Gestion Alumnos del profesor
	 * 
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaGestionAlum() {
		this.actualizarArbol();
		VistaGestionAlumnos vista_gestionAlum = new VistaGestionAlumnos(this.asignatura);
		ControlGestionAlumnos control_gestionAlum = new	ControlGestionAlumnos(vista_gestionAlum, this);
		vista_gestionAlum.setControlador(control_gestionAlum);
		this.add(vista_gestionAlum, PROF_GESTIONALUMS);
		vista_gestionAlum.actualizarListaAlumExp();
		vista_gestionAlum.actualizarListaAlumMat();
		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, PROF_GESTIONALUMS);
	}

	/**
	 * Getter del atributo raiz
	 * 
	 * @return DefaultMutableTreeNode. Raiz del arbol JTree
	 */
	public DefaultMutableTreeNode getRaiz() {
		return raiz;
	}

	/**
	 * Getter del atributo arbol
	 * 
	 * @return JTree. El arbol
	 */
	public JTree getArbol() {
		return arbol;
	}

	/**
	 * Metodo que sirve para retornar el texto contenido en el Nombre del ejercicio
	 * @author Alvaro Martinez de Navascues
	 * @return JTextField. El peso del ejercicio
	 */
	public JTextField getNombreAlum(){
		return this.nombreAlum;
	}
	
	/**
	 * Metodo que muestra la vista de un Tema
	 * 
	 * @author Alejandro Martin Climent
	 * @param tema. Tema del que se quiere mostrar la vista
	 */
	public void mostrarVistaTema(Tema tema) {
		VistaTemaProf vista_temaProf = new VistaTemaProf(tema, this);
		ControlVistaTemaProf control_tema = new ControlVistaTemaProf(vista_temaProf, tema);
		ControlArbolTema control_arbol = new ControlArbolTema(vista_temaProf);
		vista_temaProf.setControlador(control_tema, control_arbol);
		this.add(vista_temaProf, PROF_TEMAPANEL);

		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, PROF_TEMAPANEL);
	}
}
