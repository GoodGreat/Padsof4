package panelesProfesor;


import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.*;
import asignatura.*;
import controladoresProfesor.ControlVistaCambiarApunte;
/**
 * Clase que implementa la Vista de Apunte para un Profesor
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class VistaApunteProf extends JPanel{

	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista principal de apunte del profesor";
	final static String CAMBIAR_APUNTE = "Carta con la vista principal de Cambiar Apunte del profesor";
	private JLabel etiquetaNombre;
	private JLabel etiquetaTexto;
	private JButton botonCambiarApunte, botonVolver;
	private JPanel principal_apunte;
	private Apunte apunte;
	
	/**
	 * Constructor de la vista del Apunte para el profesor
	 * @param apunte. El apunte de la vista
	 */
	public VistaApunteProf(Apunte apunte){
		this.apunte = apunte;
		this.setLayout(new CardLayout());
		
		this.principal_apunte = new JPanel();
		SpringLayout layout = new SpringLayout();
		this.principal_apunte.setLayout(layout);
		
		etiquetaNombre = new JLabel(apunte.getTitulo());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.principal_apunte.add(etiquetaNombre);
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 10, SpringLayout.NORTH, this.principal_apunte);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_apunte);
		
		etiquetaTexto = new JLabel(apunte.getContenido());
		etiquetaTexto.setFont(new Font("Rockwell Extra Bold", Font.ITALIC, 12));
		this.principal_apunte.add(etiquetaTexto);
		layout.putConstraint(SpringLayout.NORTH, etiquetaTexto, 50, SpringLayout.SOUTH, etiquetaNombre);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaTexto, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaNombre);
		
		botonCambiarApunte = new JButton("Cambiar Apunte");
		botonCambiarApunte.setPreferredSize(new Dimension(150,75));
		this.principal_apunte.add(botonCambiarApunte);
		
		layout.putConstraint(SpringLayout.SOUTH, botonCambiarApunte, -5, SpringLayout.SOUTH, this.principal_apunte);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonCambiarApunte, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_apunte);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 40));
		this.principal_apunte.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 0, SpringLayout.NORTH, etiquetaNombre);
		layout.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this.principal_apunte);
		
		
		this.principal_apunte.setPreferredSize(new Dimension(800, 350));
		this.add(principal_apunte, PRINCIPAL);
	}

	/**
	 * Getter del boton Cambiar Apunte
	 * @return JButton. El boton
	 */
	public JButton getBotonCambiarApunte() {
		return botonCambiarApunte;
	}

	/**
	 * Getter del boton Volver
	 * @return JButton. El boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
	
	/**
	 * Getter del atributo apunte
	 * @return Apunte. El apunte
	 */
	public Apunte getApunte(){
		return apunte;
	}
	
	/**
	 * Metodo que sirve para actualizar el estado del Apunte
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizar(){
		this.etiquetaNombre.setText(apunte.getTitulo());
		this.etiquetaTexto.setText(apunte.getContenido());
	}
	
	/**
	 * Metodo que asigna el controlador a los botones de esta Vista
	 * @param controlador. El controlador asignado
	 */
	public void setControlador(ActionListener controlador){
		this.botonCambiarApunte.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}
	
	/**
	 * Metodo que muestra la vista de Apunte para un profesor
	 */
	public void mostrarVistaApunteProf(){
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Metodo que muestra la vista de Cambiar Apunte para un profesor
	 */
	public void mostrarVistaCambiarApunteProf(){
		VistaCambiarApunte vista_cambiarApunte = new VistaCambiarApunte();
		ControlVistaCambiarApunte control_cambiarApunte = new ControlVistaCambiarApunte(vista_cambiarApunte, this, this.apunte);
		vista_cambiarApunte.setControlador(control_cambiarApunte);
		this.add(vista_cambiarApunte, CAMBIAR_APUNTE);
		actualizar();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CAMBIAR_APUNTE);
	}
}
