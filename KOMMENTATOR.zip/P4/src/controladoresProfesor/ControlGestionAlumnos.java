package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaGestionAlumnos;
import sistema.*;

/**
 * Clase controlador de la vista de gestion alumnos, encargada de expulsar alumnos y revocar las expulsiones
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlGestionAlumnos implements ActionListener{
	private VistaGestionAlumnos vista;
	private VistaAsignaturaProf vista_principalAsig;
	private Alumno alumno;
	private Expulsion expulsion;
	
	/**
	 * Constructor de la clase ControlGestionAlumnos
	 * @param vista, la vista de gestion de alumnos
	 * @param vista_principalAsig, la vista de la asignatura a la que se podra regresar
	 */
	public ControlGestionAlumnos(VistaGestionAlumnos vista, VistaAsignaturaProf vista_principalAsig){
		this.vista = vista;
		this.vista_principalAsig =  vista_principalAsig;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonExpulsar())){
			if (this.vista.getListaAlumMat().getSelectedValue() != null){
				this.alumno = this.vista.getListaAlumMat().getSelectedValue();
				Sistema.getInstance().expulsarAlumno(alumno, this.vista.getAsignatura());
				this.vista.getModeloLista1().removeElement(alumno);
				this.vista.getModeloLista2().addElement(alumno);
				JOptionPane.showMessageDialog(this.vista,"Se ha expulsado a " + alumno.getNombre() + " "+
						alumno.getApellido() + " en " + this.vista.getAsignatura().getNombre(), "EXPULSION ALUMNO",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_principalAsig.mostrarVistaGestionAlum();
			}else{
				JOptionPane.showMessageDialog(this.vista, "Seleccione un alumno", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}else if (event.getSource().equals(this.vista.getBotonReadmitir())){
			if (this.vista.getListaAlumExp().getSelectedValue() != null){
				this.alumno = this.vista.getListaAlumExp().getSelectedValue();
				for (Expulsion expulsionAux: Sistema.getInstance().getExpulsiones()){
					if (expulsionAux.getAlumno().getNombre().equals(this.alumno.getNombre()) && 
							expulsionAux.getAlumno().getApellido().equals(this.alumno.getApellido()) &&
								expulsionAux.getAsignatura().getNombre().equals(this.vista.getAsignatura().getNombre())){
						this.expulsion = expulsionAux;
					}
				}
				Sistema.getInstance().revocarExpulsion(expulsion);
				this.vista.getModeloLista2().removeElement(alumno);
				this.vista.getModeloLista1().addElement(alumno);
				JOptionPane.showMessageDialog(this.vista,"Se ha readmitido a " + this.alumno.getNombre() +
						" " + alumno.getApellido() + " en " + this.vista.getAsignatura().getNombre(), "READMISION ALUMNO",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_principalAsig.mostrarVistaGestionAlum();
			}else{
				JOptionPane.showMessageDialog(this.vista, "Seleccione un alumno", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_principalAsig.mostrarVistaPrincipalProf();
		}
	}
}
