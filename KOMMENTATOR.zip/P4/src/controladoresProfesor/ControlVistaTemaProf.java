package controladoresProfesor;

import java.awt.event.*;
import asignatura.*;
import panelesProfesor.VistaTemaProf;
/**
 * Clase que implementa el controlador de Tema para un profesor
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaTemaProf implements ActionListener {
	private VistaTemaProf vista;

	/**
	 * Constructor del controlador de la Vista LOGIN
	 * 
	 * @author Alejandro Martin
	 * @param vista.
	 *            Panel que ve el usuario
	 * @param sistema.
	 *            Clase principal de nuestro proyecto
	 */
	public ControlVistaTemaProf(VistaTemaProf vista, Tema tema) {
		this.vista = vista;
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		if (event.getSource().equals(this.vista.getBotonCrearSubtema())) {
			this.vista.mostrarVistaCrearSubtema();
		} else if (event.getSource().equals(this.vista.getBotonCrearEjercicio())) {
			this.vista.mostrarVistaCrearEjercicio();
		} else if (event.getSource().equals(this.vista.getBotonCrearApunte())) {
			this.vista.mostrarVistaCrearApunte();
		} else if (event.getSource().equals(this.vista.getBotonCambiarTema())) {
			this.vista.mostrarVistaCambiarTema();
		} else if (event.getSource().equals(this.vista.getBotonVolver())) {
			this.vista.getVistaAsignatura().mostrarVistaPrincipalProf();
		}
	}
}