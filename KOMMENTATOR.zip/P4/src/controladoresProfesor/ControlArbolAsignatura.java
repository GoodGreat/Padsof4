package controladoresProfesor;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import interfaces.NodoInterfaz;
import panelesProfesor.VistaAsignaturaProf;

/**
 * ControlArbolAsignatura, implementa el controlador del JTree de la asignatura
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 */
public class ControlArbolAsignatura implements TreeSelectionListener{
	private VistaAsignaturaProf vista_asig;
	
	/**
	 * Contructor del controlador ControlArbolAsignatura
	 * @param vista_asig, vista d ela asignatura que controlara
	 */
	public ControlArbolAsignatura(VistaAsignaturaProf vista_asig){
		this.vista_asig = vista_asig;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).equals(this.vista_asig.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
			}else{
			if ((DefaultMutableTreeNode) this.vista_asig.getArbol().getLastSelectedPathComponent() != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_asig.getArbol()
						.getLastSelectedPathComponent()).getUserObject();

				if (nodo.getObjectClassName().equals("Tema")) {
					Tema tema = (Tema) nodo;
					this.vista_asig.mostrarVistaTema(tema);
				}
			}
		}		
	}
}
