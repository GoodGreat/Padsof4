package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.Asignatura;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaCrearTema;
import sistema.*;


/**
 * Clase que implementa el controlador de crear Temas para un profesor
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaCrearTema implements ActionListener{
	private VistaCrearTema vista;
	private VistaAsignaturaProf vista_asig;
	private Sistema sistema;
	private Asignatura asignatura;
	
	/**
	 * Constructor del controlador de la VistaCrearTema
	 * @author �lvaro Martinez de xNavascues
	 * @param vista. Panel que ve el usuario
	 * @param vista_asig, la vista de la asignatura de un profesor
	 * @param asignatura, la asignatura en la que se creara
	 */
	public ControlVistaCrearTema(VistaCrearTema vista, VistaAsignaturaProf vista_asig, Asignatura asignatura){
		this.vista = vista;
		this.vista_asig = vista_asig;
		this.sistema = Sistema.getInstance();
		this.asignatura = asignatura;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (event.getSource().equals(this.vista.getBotonCrearTema())){
			if (this.vista.getNombre().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos campos", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else if (sistema.crearTema(asignatura, this.vista.getNombre(),
					this.vista.getComboBoxSelected()) == false) {
				JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error", JOptionPane.ERROR_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(this.vista,
						"El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_asig.mostrarVistaPrincipalProf();
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_asig.mostrarVistaPrincipalProf();
		}
	}
}
