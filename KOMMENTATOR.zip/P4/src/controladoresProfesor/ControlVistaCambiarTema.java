package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.Tema;
import panelesProfesor.VistaCambiarTema;
import panelesProfesor.VistaTemaProf;

/**
 * Clase que se encargara de controlar la vista de cambiar un tema
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaCambiarTema implements ActionListener{
	private VistaCambiarTema vista;
	private VistaTemaProf vista_temaProf;
	private Tema tema;
	
	
	/**
	 * Constructor del controlador del ControlVistaCambiarTema
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param vista_temaProf. Vista de un tema
	 * @param tema, el tema que se cambiara
	 */
	public ControlVistaCambiarTema(VistaCambiarTema vista, VistaTemaProf vista_temaProf, Tema tema){
		this.vista = vista;
		this.vista_temaProf = vista_temaProf;
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// SI NO ES O "" O EL NOMBRE QUE YA TENIA ANTES, CAMBIAMOS POR EL INTRODUCIDO POR EL USUARIO
		if (event.getSource().equals(this.vista.getBotonGuardarCambios())){
			if (this.vista.getNombre().equals("") == false
					&& this.vista.getNombre().equals(tema.getNombre()) == false) {
				tema.setNombre(this.vista.getNombre());
			}

			if (this.vista.getComboBoxSelected() == false && this.tema.getVisible() == true) {
				tema.ocultarTema();
			} else if (this.vista.getComboBoxSelected() == true && this.tema.getVisible() == false) {
				tema.publicarTema();
			}
			JOptionPane.showMessageDialog(this.vista, "Se han guardado todos los cambios",
					"CAMBIAR TEMA", JOptionPane.INFORMATION_MESSAGE);
			this.vista_temaProf.actualizar();
			this.vista_temaProf.mostrarVistaTemaProf();
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_temaProf.mostrarVistaTemaProf();
		}
	}
}
