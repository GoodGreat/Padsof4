package controladoresProfesor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import ejercicio.Multipregunta;
import ejercicio.Pregunta;
import ejercicio.PreguntaBooleana;
import ejercicio.PreguntaLibre;
import ejercicio.PreguntaUnica;
import panelesProfesor.*;
/**
 * Clase que implementa el controlador de la vista de Ejercicio para un profesor
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaEjercicioProf implements ActionListener{
	private VistaEjercicioProf vista;
	private VistaTemaProf vista_tema;
	
	/**
	 * Constructor de la clase
	 * @param vista. Vista de ejercicio
	 * @param vista_tema. Vista del tema al que pertenece el ejercicio
	 */
	public ControlVistaEjercicioProf(VistaEjercicioProf vista, VistaTemaProf vista_tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_tema.mostrarVistaTemaProf();			
		}else if(event.getSource().equals(this.vista.getBotonCambiarEjercicio())){
			if (this.vista.getEjercicio().getnRealizaciones() > 0){
					JOptionPane.showMessageDialog(this.vista, "No se puede cambiar un ejercicio que ya ha sido realizado", "Error",
							JOptionPane.ERROR_MESSAGE);
			}else{
				this.vista.mostrarVistaCambiarEjercicio(this.vista.getEjercicio());
			}
		} else if(event.getSource().equals(this.vista.getBotonIr())){
			 this.vista.getComboBoxPregunta().getSelectedItem();
			 Pregunta pregunta = (Pregunta)this.vista.getComboBoxPregunta().getSelectedItem();
			if(pregunta.getTipo().equals("Booleana")){
				PreguntaBooleana preg = (PreguntaBooleana) pregunta;
				this.vista.mostrarVistaPreguntaBooleana(preg, vista);
			} else if(pregunta.getTipo().equals("Unica")){	
				PreguntaUnica preg = (PreguntaUnica) pregunta;
				this.vista.mostrarVistaPreguntaUnica(preg, vista);
			} else if(pregunta.getTipo().equals("Libre")){	
				PreguntaLibre preg = (PreguntaLibre) pregunta;
				this.vista.mostrarVistaPreguntaLibre(preg, vista);
			} else if(pregunta.getTipo().equals("Multipregunta")){
				Multipregunta preg = (Multipregunta) pregunta;
				this.vista.mostrarVistaMultipregunta(preg, vista);
			}
		}
	}
}
