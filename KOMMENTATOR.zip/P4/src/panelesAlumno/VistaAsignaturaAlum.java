package panelesAlumno;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import asignatura.*;
import controladoresAlumno.*;
/**
 * Clase que implementa la Vista de una Asignatura para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class VistaAsignaturaAlum extends JPanel{
	
	private static final long serialVersionUID = 1L;
	final static String ESTUD_MOSTRARASIGS = "Carta con la vista de Asignaturas de un Profesor";
	final static String ESTUD_ASIGPANEL = "Carta con la vista de asignatura del Profesor";
	final static String ESTUD_MOSTRARTEMA = "Carta con la vista de temas de un Profesor";
	private JLabel etiquetaNombre;
	private JTree arbol;
	private JButton botonVolver, botonCalcularNota;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private Asignatura asignatura;
	private JPanel principal_asignatura;
	
	/**
	 * Constructor de la Vista de Asignatura
	 * @param asignatura. Asignatura de la cual se hace la vista
	 */
	public VistaAsignaturaAlum(Asignatura asignatura){
		CardLayout card_layout = new CardLayout();
		this.setLayout(card_layout);
		
		this.asignatura = asignatura;
		SpringLayout layout = new SpringLayout();
		
		principal_asignatura = new JPanel();
		principal_asignatura.setLayout(layout);
		
		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
				
		//Panel de botones 
		JPanel panel_botones = new JPanel();
				
		//Panel del arbol de contenido 
		JPanel panel_arbol = new JPanel();
		
		principal_asignatura.setLayout(new BorderLayout());
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel(asignatura.getNombre());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		panel_etiquetas.add(etiquetaNombre);
		
		botonCalcularNota = new JButton("Calcular Nota");
		botonCalcularNota.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCalcularNota);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonVolver);
		
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		//Ponemos la derecha del botonCrearTema a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 5, SpringLayout.SOUTH, botonCalcularNota);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode(asignatura.getNombre());
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		arbol = new JTree (modelo);
				
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(300, 200));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);		
		
		for(Tema temaAux: asignatura.getTemas()){
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			//construirArbol(temaAux, nodo_tema);
			i++;
		}
		
		panel_arbol.add(arbol);

		//Constraints
		
		this.setPreferredSize(new Dimension(450, 150));
		this.principal_asignatura.add(panel_etiquetas, BorderLayout.NORTH);
		this.principal_asignatura.add(panel_botones, BorderLayout.SOUTH);
		this.principal_asignatura.add(panel_arbol, BorderLayout.EAST);
		
		this.add(principal_asignatura, ESTUD_ASIGPANEL);
	}


	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizarArbol(){
		
		//Borrar el arbol
		raiz.removeAllChildren();
		
		//Actualizar el arbol
		modelo.reload();
		
		int i =0;
		for(Tema temaAux: asignatura.getTemas()){
			if(temaAux.getVisible() == true){
				DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_asignatura, raiz, i);
				i++;
			}
		}
	}
	
	/**
	 * Getter del boton "Volver"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton. EL boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}

	/**
	 * Getter del boton "Calcular Nota"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton. El boton
	 */
	public JButton getBotonCalcularNota() {
		return botonCalcularNota;
	}

	/**
	 * Metodo que sirve para aniadir un controlador a los botones de esta Vista
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador, ControlArbolAsignaturaAlum controlador_arbol) {
		this.botonVolver.addActionListener(controlador);
		this.botonCalcularNota.addActionListener(controlador);

		// Controlador del arbol
		arbol.addTreeSelectionListener(controlador_arbol);
	}

	/**
	 * Getter del atributo Raiz del arbol
	 * @return DefaultMutableTreeNode. El nodo raiz del arbol
	 */
	public DefaultMutableTreeNode getRaiz() {
		return raiz;
	}

	/**
	 * Getter del atributo Arbol de la asignatura
	 * @return JTree. El arbol de la asignatura
	 */
	public JTree getArbol() {
		return arbol;
	}

	/**
	 * Metodo que muestra la vista de crear Asignatura
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param tema. Tema del que se quiere mostrar
	 */
	public void mostrarVistaTemaAlum(Tema tema) {
		// actualizarArbol();
		VistaTemaAlum vista_temaAlum = new VistaTemaAlum(tema, this);
		ControlVistaTemaAlum control_temaAlum = new ControlVistaTemaAlum(vista_temaAlum, this);
		ControlArbolTemaAlum controlador_arbol = new ControlArbolTemaAlum(vista_temaAlum);
		vista_temaAlum.setControlador(control_temaAlum, controlador_arbol);
		this.add(vista_temaAlum, ESTUD_MOSTRARTEMA);

		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, ESTUD_MOSTRARTEMA);
	}

	/**
	 * Metodo que muestra la vista principal la Asignatura para el Alumno 
	 */
	public void mostrarVistaAsignaturaAlum() {
		this.actualizarArbol();

		CardLayout cl = (CardLayout) (this.getLayout());
		cl.show(this, ESTUD_ASIGPANEL);
	}

}