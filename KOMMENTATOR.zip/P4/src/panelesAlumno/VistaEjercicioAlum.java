package panelesAlumno;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.*;

import controladoresAlumno.ControlVistaMostrarMultipreguntaAlum;
import controladoresAlumno.ControlVistaMostrarPreguntaBooleanaAlum;
import controladoresAlumno.ControlVistaMostrarPreguntaLibreAlum;
import controladoresAlumno.ControlVistaMostrarPreguntaUnicaAlum;
import ejercicio.*;

/**
 * Clase que implementa la Vista de un Ejercicio para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 */
public class VistaEjercicioAlum extends JPanel{

	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista de ejercicio del Profesor";
	final static String PREGUNTA_BOOL = "Carta con la vista principal de pregunta Booleana(del Profesor)";
	final static String PREGUNTA_LIBRE = "Carta con la vista principal de pregunta Libre(del Profesor)";
	final static String PREGUNTA_UNICA = "Carta con la vista principal de pregunta Unica(del Profesor)";
	final static String PREGUNTA_MULTI = "Carta con la vista principal de Multipregunta(del Profesor)";
	private JLabel etiquetaNombre;
	private JLabel etiquetaFechaIni;
	private JLabel etiquetaFechaFin;
	private JButton botonVolver, botonContestar;
	private JPanel principal_ejercicio;
	private Ejercicio ejercicio;
	private JLabel etiquetaPregunta;
	private JComboBox<Pregunta> comboBoxPregunta;
	
	/**
	 * Constructor de la vista Ejercicio
	 * @param ejercicio. Ejercicio que se quiere mostrar
	 */
	public VistaEjercicioAlum(Ejercicio ejercicio){
		this.ejercicio = ejercicio;
		this.setLayout(new CardLayout());
		
		this.principal_ejercicio = new JPanel();
		SpringLayout layout = new SpringLayout();
		this.principal_ejercicio.setLayout(layout);

		etiquetaNombre = new JLabel(ejercicio.getNombre());
		this.principal_ejercicio.add(etiquetaNombre);
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 10, SpringLayout.NORTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
	
	 	etiquetaFechaIni = new JLabel("Fecha de inicio: " + ejercicio.getFechaIni().getTime());
	 	this.principal_ejercicio.add(etiquetaFechaIni);
		layout.putConstraint(SpringLayout.NORTH, etiquetaFechaIni, 10, SpringLayout.SOUTH, etiquetaNombre);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaFechaIni, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaNombre);
		
		
		etiquetaFechaFin = new JLabel("Fecha de final: " + ejercicio.getFechaFin().getTime());
		this.principal_ejercicio.add(etiquetaFechaFin);
		layout.putConstraint(SpringLayout.NORTH, etiquetaFechaFin, 10, SpringLayout.SOUTH, etiquetaFechaIni);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaFechaFin, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaFechaIni);
			
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 40));
		this.principal_ejercicio.add(botonVolver);
		
		layout.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 20, SpringLayout.NORTH, this.principal_ejercicio);
		
	   	botonContestar = new JButton("Contestar");
		botonContestar.setPreferredSize(new Dimension(150,75));
		this.principal_ejercicio.add(botonContestar);
		
		layout.putConstraint(SpringLayout.SOUTH, botonContestar, -5, SpringLayout.SOUTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonContestar, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
		
		//barajeamos las preguntas para que salgan en un orden aleatorio, distinto al introducido por el profesor
		if(ejercicio.getAleatorio() == true){
			ejercicio.barajarPreguntas();
		}
		
		
		Pregunta[] opciones = new Pregunta[ejercicio.getPreguntas().size()];
		
		int i =0;
		
		for(i=0; i < ejercicio.getPreguntas().size(); i++){
			{
					opciones[i] = ejercicio.getPreguntas().get(i);
			}
		}
		
		etiquetaPregunta = new JLabel("Seleccione pregunta ");
		this.principal_ejercicio.add(etiquetaPregunta);
		comboBoxPregunta = new JComboBox<Pregunta>(opciones);
		this.principal_ejercicio.add(comboBoxPregunta);
		
		
		//Constraints
		layout.putConstraint(SpringLayout.NORTH, etiquetaPregunta, 200, SpringLayout.NORTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.EAST, etiquetaPregunta, -400, SpringLayout.EAST, this.principal_ejercicio);		
		layout.putConstraint(SpringLayout.EAST, comboBoxPregunta, -300, SpringLayout.EAST, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.NORTH, comboBoxPregunta, 200, SpringLayout.NORTH, this.principal_ejercicio);
		
		this.principal_ejercicio.setPreferredSize(new Dimension(800,350));
		this.add(this.principal_ejercicio, PRINCIPAL);
	}
	
	/**
	 * Metodo para asignar el controlador a los botones de esta vista
	 * @param controlador. Controlador de los botones
	 */
	public void setControlador(ActionListener controlador){
		this.botonContestar.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}

	/**
	 * Getter del boton Volver
	 * @return JButton. EL boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
	
	/**
	 * Getter del boton Contestar
	 * @return JButton. EL boton
	 */
	public JButton getBotonContestar() {
		return botonContestar;
	}

	/**
	 * Getter de la comboBox de preguntas
	 * @return JComboBox. La comboBox
	 */
	public JComboBox<Pregunta> getComboBoxPregunta() {
		return comboBoxPregunta;
	}
	
	/**
	 * Metodo que muestra la vista de pregunta booleana
	 * @author Alejandro Martin Climent
	 * @param pregunta. La pregunta booleana que se muestra
	 * @param vistaEjer. La vista del ejercicio que contiene a la pregunta
	 */
	public void mostrarVistaPreguntaBooleanaAlum(PreguntaBooleana pregunta, VistaEjercicioAlum vista_Ejer){
		VistaPreguntaBooleanaAlum vista_mostrarPreg = new VistaPreguntaBooleanaAlum(pregunta);
		ControlVistaMostrarPreguntaBooleanaAlum control_mostrarPreg = new ControlVistaMostrarPreguntaBooleanaAlum(vista_mostrarPreg, this, pregunta);
		vista_mostrarPreg.setControlador(control_mostrarPreg);
		this.add(vista_mostrarPreg, PREGUNTA_BOOL);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PREGUNTA_BOOL);
	}
	

	/**
	 * Metodo que muestra la vista de pregunta unica
	 * @author �lvaro Martinez de Navascues
	 * 
	 * @param pregunta. La pregunta unica que se muestra
	 * @param vistaEjer. La vista del ejercicio que contiene a la pregunta
	 */
	public void mostrarVistaPreguntaUnicaAlum(PreguntaUnica pregunta, VistaEjercicioAlum vista_Ejer){
		
		VistaPreguntaUnicaAlum vista_mostrarPreg = new VistaPreguntaUnicaAlum(pregunta);
		ControlVistaMostrarPreguntaUnicaAlum control_mostrarPreg = new ControlVistaMostrarPreguntaUnicaAlum(vista_mostrarPreg, this, pregunta);
		vista_mostrarPreg.setControlador(control_mostrarPreg);
		this.add(vista_mostrarPreg, PREGUNTA_UNICA);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PREGUNTA_UNICA);
	}
	

	/**
	 * Metodo que muestra la vista de pregunta libre
	 * @author Alejandro Martin Climent
	 * 
	 * @param pregunta. La pregunta libre que se muestra
	 * @param vistaEjer. La vista del ejercicio que contiene a la pregunta
	 */
	public void mostrarVistaPreguntaLibreAlum(PreguntaLibre pregunta, VistaEjercicioAlum vista_Ejer){
		
		VistaPreguntaLibreAlum vista_mostrarPreg = new VistaPreguntaLibreAlum(pregunta);
		ControlVistaMostrarPreguntaLibreAlum control_mostrarPreg = new ControlVistaMostrarPreguntaLibreAlum(vista_mostrarPreg, this, pregunta);
		vista_mostrarPreg.setControlador(control_mostrarPreg);
		this.add(vista_mostrarPreg, PREGUNTA_LIBRE);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PREGUNTA_LIBRE);
	}
	

	/**
	 * Metodo que muestra la vista de una multipregunta
	 * @author �lvaro Martinez de Navascues
	 * @param pregunta. La multipregunta que se muestra
	 * @param vistaEjer. La vista del ejercicio que contiene a la pregunta
	 */
	public void mostrarVistaMultipreguntaAlum(Multipregunta pregunta, VistaEjercicioAlum vista_Ejer){
		
		VistaMultipreguntaAlum vista_mostrarPreg = new VistaMultipreguntaAlum(pregunta);
		ControlVistaMostrarMultipreguntaAlum control_mostrarPreg= new ControlVistaMostrarMultipreguntaAlum(vista_mostrarPreg, this, pregunta);
		vista_mostrarPreg.setControlador(control_mostrarPreg);
		this.add(vista_mostrarPreg, PREGUNTA_MULTI);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PREGUNTA_MULTI);
	}
	
	/**
	 * Metodo que muestra la vista principal de esta clase
	 * @author �lvaro MArtinez de Navascues
	 */
	public void mostrarVistaPrincipal(){
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Getter del atributo ejercicio
	 * @return Ejercicio. El ejercicio
	 */
	public Ejercicio getEjercicio(){
		return this.ejercicio;
	}	
}
