package panelesAlumno;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import sistema.*;
import asignatura.*;
import controladoresAlumno.*;

/**
 * Clase que implementa la Vista de Mostrar Asignaturas para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 */
public class VistaMostrarAsignaturas extends JPanel{
	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista principal Alumno";
	final static String ESTUD_ASIGPANEL = "Carta con la vista de asignatura del Alumno";
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private JButton botonAtras;
	private JTree arbol;
	private JLabel titulo;
	private JPanel mostrarAsigsAlum;
	
	/**
	 * Constructor de la vista de Asignaturas Matriculadas
	 * @author Alejandro Martin Climent
	 */
	public VistaMostrarAsignaturas(){
		
		CardLayout card_layout = new CardLayout();
		this.setLayout(card_layout);
		
		this.mostrarAsigsAlum = new JPanel();
		SpringLayout layout = new SpringLayout();
				
		mostrarAsigsAlum.setLayout(layout);
		
		
		titulo = new JLabel("ASIGNATURAS");
		titulo.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.mostrarAsigsAlum.add(titulo);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, titulo, 0, SpringLayout.HORIZONTAL_CENTER, this.mostrarAsigsAlum);
		layout.putConstraint(SpringLayout.NORTH, titulo, 20, SpringLayout.NORTH, this.mostrarAsigsAlum);
		
		
		botonAtras = new JButton("Volver atras");
		botonAtras.setPreferredSize(new Dimension(120, 30));
		this.mostrarAsigsAlum.add(botonAtras);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode("Asignaturas");
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		arbol = new JTree (modelo);
		
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(400, 300));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);
		
		int i = 0;
		Sistema sistema = Sistema.getInstance();
		
		for(Asignatura asignaturaAux: sistema.getAsignaturas()){
			if(asignaturaAux.getVisible() == true ){
				for (Asignatura asignaturaAlum: sistema.getAlumnoLogueado().getAsignaturas()){
					if (asignaturaAlum.getNombre().equals(asignaturaAux.getNombre())){
						DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(asignaturaAux);
						modelo.insertNodeInto(nodo_asignatura, raiz, i);
						i++;
					}
				}
			}
		}
		
		this.mostrarAsigsAlum.add(arbol);
		
		
		layout.putConstraint(SpringLayout.NORTH, arbol, 20, SpringLayout.SOUTH, titulo);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, arbol, 0, SpringLayout.HORIZONTAL_CENTER, this.mostrarAsigsAlum);
		
		layout.putConstraint(SpringLayout.NORTH, botonAtras, 0, SpringLayout.NORTH, titulo);
		layout.putConstraint(SpringLayout.EAST, botonAtras, 0, SpringLayout.EAST, this.mostrarAsigsAlum);
		this.add(mostrarAsigsAlum, PRINCIPAL);
	}

	
	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * @author Alejandro Martin Climent
	 */
	public void actualizarArbol(){
		
		//Borrar el arbol
		raiz.removeAllChildren();
		//Actualizar el arbol
		modelo.reload();
		
		int i =0;
		Sistema sistema = Sistema.getInstance();
		for(Asignatura asignaturaAux: sistema.getAsignaturas()){
			if(asignaturaAux.getVisible() == true ){
				for (Asignatura asignaturaAlum: sistema.getAlumnoLogueado().getAsignaturas()){
					if (asignaturaAlum.getNombre().equals(asignaturaAux.getNombre())){
						DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(asignaturaAux);
						modelo.insertNodeInto(nodo_asignatura, raiz, i);
						i++;
					}
				}
			}
		}
	}
	
	/**
	 * Getter del boton Atras
	 * @return JButton. El botonAtras
	 */
	public JButton getBotonAtras() {
		actualizarArbol();
		return botonAtras;
	}
	
	/**
	 * Getter del atributo raiz
	 * @return DefaultMutableTreeNode. La raiz
	 */
	public DefaultMutableTreeNode getRaiz() {
		return raiz;
	}

	/**
	 * Getter del atributo arbol
	 * @return JTree. El arbol
	 */
	public JTree getArbol() {
		return arbol;
	}

	/**
	 * Metodo que muestra la vista de crear Asignatura
	 * @author �lvaro Martinez de Navascues
	 * @param asignatura. Asignatura que se quiere mostrar
	 */
	public void mostrarVistaAsignaturaAlum(Asignatura asignatura) {
		actualizarArbol();
		VistaAsignaturaAlum vista_asigAlum = new VistaAsignaturaAlum(asignatura);
		ControlVistaAsignaturaAlum control_asignaturaAlum = new ControlVistaAsignaturaAlum(vista_asigAlum, this, asignatura);
		ControlArbolAsignaturaAlum controlador_arbol = new ControlArbolAsignaturaAlum(vista_asigAlum);
		vista_asigAlum.setControlador(control_asignaturaAlum, controlador_arbol);
		this.add(vista_asigAlum, ESTUD_ASIGPANEL);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, ESTUD_ASIGPANEL);		
	}
	
	/**
	 * Metodo que muestra las asignaturas matriculadas de un Alumno
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaAsignaturasMat(){
		actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador a los botones de esta vista
	 * @author Alejandro Martin Climent
	 * @param controlador. Controlador que se quiere asignar
	 * @param control_arbo. Controlador del arbol
	 */
	public void setControlador(ActionListener controlador, ControlArbolMostrarAsigs control_arbol){
		this.botonAtras.addActionListener(controlador);
		
		//Controlador del arbol
	 	arbol.addTreeSelectionListener(control_arbol);
	}
	
	
}


