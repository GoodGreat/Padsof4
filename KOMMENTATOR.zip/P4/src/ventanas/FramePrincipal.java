package ventanas;

import java.awt.*;
import javax.swing.*;

import controladoresAlumno.*;
import controladoresProfesor.ControlArbolPrincipal;
import controladoresProfesor.ControlVistaPrincipalProf;
import panelesAlumno.*;
import panelesProfesor.VistaPrincipalProf;
/**
 * Clase que implementa la ventana principal de nuestra aplicacion
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class FramePrincipal extends JFrame {
	private static final long serialVersionUID = 1L;
	final static String LOGINPANEL = "Carta con el LOGIN";
	final static String GESTIONPANEL = "Carta para la gestion de matriculas";
	final static String PROF_PRINCIPANEL = "Carta con la vista del menu del Profesor";
	final static String ESTUD_PRINCIPANEL = "Carta con la vista del menu Alumno";
	final static String ESTUD_ASIGPANEL = "Carta con la vista de asignatura del Alumno";
	final static String ESTUD_TEMAPANEL = "Carta con la vista de tema del Alumno";
	final static String ESTUD_EJERPANEL = "Carta con la vista de un ejercicio del Alumno";
	final static String ESTUD_APUNTEPANEL = "Carta con la vista de un apunte del Alumno";
	final static String PROF_CREARTEMA = "Carta con la vista de crear Tema de un Profesor";
	
	/**
	 * Constructor de la ventana Principal
	 */
	public FramePrincipal (){
		super("E-DUUDLE");
		super.setFont(new Font("Times New Roman", Font.BOLD, 13));
		//Layout de Card
		
		Container container = this.getContentPane();
		container.setLayout(new CardLayout());
		
		VistaLogin vista_login = new VistaLogin();
		VistaPrincipalProf vista_princiProf = new VistaPrincipalProf();
		VistaPrincipalAlum vista_princiAlum = new VistaPrincipalAlum();
		
		ControlVistaLogin controladorLogin = new ControlVistaLogin(vista_login, this);
		ControlVistaPrincipalProf controladorPrincipalProf = new ControlVistaPrincipalProf(vista_princiProf, this);
		ControlVistaPrincipalAlum controlador = new ControlVistaPrincipalAlum(vista_princiAlum, this);
		ControlArbolPrincipal controlador_arbol = new ControlArbolPrincipal(vista_princiProf);
		
		vista_login.setControlador(controladorLogin);
		vista_princiProf.setControlador(controladorPrincipalProf, controlador_arbol);
		vista_princiAlum.setControlador(controlador);
		
		container.add(vista_login, LOGINPANEL);
		container.add(vista_princiProf, PROF_PRINCIPANEL);
		container.add(vista_princiAlum, ESTUD_PRINCIPANEL);		
	
		//Colocar los componentes de acuerdo a sus tama�os
		this.setPreferredSize(new Dimension(800, 500));
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	/**
	 * Metodo que muestra la vista de Login
	 */
	public void mostrarLogin(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), LOGINPANEL);
	}
	
	/**
	 * Metodo que muestra la ventana Principal de Profesor
	 */
	public void mostrarVistaPrinciProf(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), PROF_PRINCIPANEL);
	}
	
	/**
	 * Metodo que muestra la vista principal de un Alumno
	 */
	public void mostrarVistaPrinciEstudiante(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), ESTUD_PRINCIPANEL);
	}
}
