package interfaces;

/**
 * Interfaz que implementan los elementos de un JTree
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public interface NodoInterfaz {
	
	/**
	 * Metodo que devuelve la clas del objeto
	 * @author �lvaro Martinez de Navascues
	 * @return La clase del objeto
	 */
	public String getObjectClassName();
	
	/**
	 * Metodo toString que Devuelve la Clase a la que pertenece
	 * @return String. Nombre de la Clase
	 */
	public String toString();	
}
