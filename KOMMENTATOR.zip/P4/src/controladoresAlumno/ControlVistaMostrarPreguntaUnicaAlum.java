package controladoresAlumno;

import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import sistema.*;
import ejercicio.Opcion;
import ejercicio.PreguntaUnica;
import panelesAlumno.VistaEjercicioAlum;
import panelesAlumno.VistaPreguntaUnicaAlum;
/**
 * Clase que implementa el controlador de la Vista de Pregunta Unica para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaMostrarPreguntaUnicaAlum implements ActionListener{
		private PreguntaUnica pregunta; 
		private VistaPreguntaUnicaAlum vista;
		private VistaEjercicioAlum vistaEjer;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_Alum. Panel de la vista principal del Alum
		 */
		public ControlVistaMostrarPreguntaUnicaAlum(VistaPreguntaUnicaAlum vista, VistaEjercicioAlum vistaEjer, PreguntaUnica pregunta){
			this.vista = vista;
			this.vistaEjer = vistaEjer;
			this.pregunta = pregunta;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
				if(event.getSource().equals(this.vista.getBotonVolver())){
					vistaEjer.mostrarVistaPrincipal();
				}else if (event.getSource().equals(this.vista.getBotonEnviarRespuesta())) {
					List<Opcion> opciones = new ArrayList<Opcion>();
					for (int i = 0; i < this.pregunta.getOpciones().size(); i++) {
						if (this.vista.getCheckBoxAt(i).isSelected() == true) {
							Opcion opcion = new Opcion(this.vista.getCheckBoxAt(i).getText());
							System.out.println(i + this.vista.getCheckBoxAt(i).getText());
							opciones.add(opcion);
						}
					}
					if (this.vistaEjer.getEjercicio().registrarRespuestaAlumno(Sistema.getInstance().getAlumnoLogueado(),
							this.pregunta, opciones) == true) {
						
						JOptionPane.showMessageDialog(this.vista, "La respuesta ha sido enviada con exito",
								"RESPUESTA ENVIADA", JOptionPane.INFORMATION_MESSAGE);
						this.vistaEjer.mostrarVistaPreguntaUnicaAlum(pregunta, this.vistaEjer);
					}else{
						JOptionPane.showMessageDialog(this.vista, "No se puede responder dos veces ",
								"ERROR", JOptionPane.ERROR_MESSAGE);
						this.vistaEjer.mostrarVistaPreguntaUnicaAlum(pregunta, this.vistaEjer);
					}
				}
	}
}