package controladoresAlumno;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.Asignatura;
import interfaces.NodoInterfaz;
import panelesAlumno.VistaMostrarAsignaturas;
import sistema.Sistema;

/**
 * Clase que implementa el controlador del Arbol de las Asignaturas para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlArbolMostrarAsigs implements TreeSelectionListener{
	private VistaMostrarAsignaturas vista_mostrarAsigs;
	
	/**
	 * Constructor de la clase
	 * @param vista_mostrarAsigs. Vista de Mostrar Asignaturas
	 */
	public ControlArbolMostrarAsigs(VistaMostrarAsignaturas vista_mostrarAsigs){
		this.vista_mostrarAsigs = vista_mostrarAsigs;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0
				|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent())
						.equals(this.vista_mostrarAsigs.getRaiz())) {
			// No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if (((DefaultMutableTreeNode) this.vista_mostrarAsigs.getArbol().getLastSelectedPathComponent()) != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_mostrarAsigs.getArbol()
						.getLastSelectedPathComponent()).getUserObject();
				if (nodo.getObjectClassName().equals("Asignatura")) {
					for (Asignatura asignaturaAux: Sistema.getInstance().getAsignaturas()){
						if (asignaturaAux.getNombre().equals(((Asignatura) nodo).getNombre())){
							Asignatura asignatura = asignaturaAux;
							this.vista_mostrarAsigs.mostrarVistaAsignaturaAlum(asignatura);;
						}
					}
				}
			}
		}
	}
}
