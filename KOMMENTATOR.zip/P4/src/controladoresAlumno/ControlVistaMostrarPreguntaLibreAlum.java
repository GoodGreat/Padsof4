package controladoresAlumno;

import java.awt.event.*;
import java.util.ArrayList;
import java.util.List;

import javax.swing.JOptionPane;
import sistema.*;
import ejercicio.Opcion;
import ejercicio.PreguntaLibre;
import panelesAlumno.VistaEjercicioAlum;
import panelesAlumno.VistaPreguntaLibreAlum;
/**
 * Clase que implementa el controlador de la Vista de Pregunta Libre para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaMostrarPreguntaLibreAlum implements ActionListener {
	private PreguntaLibre pregunta;
	private VistaPreguntaLibreAlum vista;
	private VistaEjercicioAlum vistaEjer;

	/**
	 * Constructor del controlador de la Vista LOGIN
	 * 
	 * @author Alejandro Martin
	 * @param vista.
	 *            Panel que ve el usuario
	 * @param vista_Alum.
	 *            Panel de la vista principal del Alume
	 */
	public ControlVistaMostrarPreguntaLibreAlum(VistaPreguntaLibreAlum vista, VistaEjercicioAlum vistaEjer,
			PreguntaLibre pregunta) {
		this.vista = vista;
		this.vistaEjer = vistaEjer;
		this.pregunta = pregunta;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())) {
			vistaEjer.mostrarVistaPrincipal();
		} else if (event.getSource().equals(this.vista.getBotonEnviarRespuesta())) {
			List<Opcion> opciones = new ArrayList<Opcion>();
			Opcion opcion = new Opcion(this.vista.getTextRespuesta().getText());
			opciones.add(opcion);
			if (this.vistaEjer.getEjercicio().registrarRespuestaAlumno(Sistema.getInstance().getAlumnoLogueado(),
					this.pregunta, opciones) == true) {
				JOptionPane.showMessageDialog(this.vista, "La respuesta ha sido enviada con exito", "RESPUESTA ENVIADA",
						JOptionPane.INFORMATION_MESSAGE);
				this.vistaEjer.mostrarVistaPreguntaLibreAlum(pregunta, this.vistaEjer);
			} else {
				JOptionPane.showMessageDialog(this.vista, "No se puede responder dos veces ", "ERROR",
						JOptionPane.ERROR_MESSAGE);
				this.vistaEjer.mostrarVistaPreguntaLibreAlum(pregunta, this.vistaEjer);
			}
		} else {
			JOptionPane.showMessageDialog(this.vista, "No se pueden seleccionar mas de una", "ERROR",
					JOptionPane.ERROR_MESSAGE);
		}

	}
}