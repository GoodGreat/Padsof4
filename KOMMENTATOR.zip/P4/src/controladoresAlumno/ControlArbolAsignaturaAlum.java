package controladoresAlumno;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import interfaces.NodoInterfaz;
import panelesAlumno.VistaAsignaturaAlum;

/**
 * Clase que implementa el controlador del Arbol de la Asignatura para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlArbolAsignaturaAlum implements TreeSelectionListener{
	private VistaAsignaturaAlum vista_asig;
	
	/**
	 * Constructor de la clase
	 * @param vista_asigAlum. Vista de la asignatura
	 */
	public ControlArbolAsignaturaAlum(VistaAsignaturaAlum vista_asigAlum){
		this.vista_asig = vista_asigAlum;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).equals(this.vista_asig.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if ((DefaultMutableTreeNode) this.vista_asig.getArbol().getLastSelectedPathComponent() != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_asig.getArbol()
						.getLastSelectedPathComponent()).getUserObject();

				if (nodo.getObjectClassName().equals("Tema")) {
					Tema tema = (Tema) nodo;
					this.vista_asig.mostrarVistaTemaAlum(tema);
				}
			}
		}			
	}
}
