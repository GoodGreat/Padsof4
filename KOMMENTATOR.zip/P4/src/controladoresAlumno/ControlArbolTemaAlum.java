package controladoresAlumno;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import ejercicio.Ejercicio;
import interfaces.NodoInterfaz;
import panelesAlumno.VistaTemaAlum;

/**
 * Clase que implementa el controlador del Arbol del Tema para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlArbolTemaAlum implements TreeSelectionListener{
	private VistaTemaAlum vista_temaAlum;
	
	/**
	 * Constructor del Controlador del arbol de Tema de Alumno
	 * @param vista_temaAlum. La vista del Tema
	 */
	public ControlArbolTemaAlum(VistaTemaAlum vista_temaAlum){
		this.vista_temaAlum = vista_temaAlum;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0||
				((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).equals(this.vista_temaAlum.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if ((DefaultMutableTreeNode) this.vista_temaAlum.getArbol().getLastSelectedPathComponent() != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_temaAlum.getArbol()
						.getLastSelectedPathComponent()).getUserObject();

				if (nodo.getObjectClassName().equals("Tema")) {
					Tema tema = (Tema)nodo;
					this.vista_temaAlum.mostrarVistaSubtemaAlum(tema);
				} else if (nodo.getObjectClassName().equals("Ejercicio")) {
					Ejercicio ejercicio = (Ejercicio) nodo;
					this.vista_temaAlum.mostrarVistaEjercicioAlum(ejercicio);
				} else if (nodo.getObjectClassName().equals("Apunte")) {
					Apunte apunte = (Apunte)nodo;
					this.vista_temaAlum.mostrarVistaApunteAlum(apunte);
				}
			}
		}		
	}
}
