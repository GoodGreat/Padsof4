package controladoresAlumno;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import panelesAlumno.VistaMostrarAsignaturas;
import panelesAlumno.VistaPrincipalAlum;
/**
 * Clase que implementa el controlador de la Vista de Mostrar Asignaturas para un Alumno
 * @author �lvaro Martinez de Navascues y Alejandro Martin Climent
 *
 */
public class ControlVistaMostrarAsignaturas implements ActionListener{
	private VistaMostrarAsignaturas vista;
	private VistaPrincipalAlum vista_principal;
	
	/**
	 * Constructor de la clase
	 * @param vista. Vista de Mostrar Asignaturas
	 * @param vista_principal. Vista principal del Alumno
	 */
	public ControlVistaMostrarAsignaturas(VistaMostrarAsignaturas vista, VistaPrincipalAlum vista_principal){
		this.vista = vista;
		this.vista_principal = vista_principal;
	}
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if (e.getSource().equals(this.vista.getBotonAtras())){
			this.vista_principal.mostrarVistaPrincipalAlum();
		}		
	}
}
