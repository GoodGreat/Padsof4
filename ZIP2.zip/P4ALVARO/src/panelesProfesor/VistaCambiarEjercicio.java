package panelesProfesor;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.LayoutManager;
import java.awt.event.*;
import javax.swing.*;

import controladoresProfesor.ControlVistaCambiarEjercicio;
import controladoresProfesor.ControlVistaCrearMultipregunta;
import controladoresProfesor.ControlVistaCrearPreguntaBooleana;
import controladoresProfesor.ControlVistaCrearPreguntaLibre;
import controladoresProfesor.ControlVistaCrearPreguntaUnica;
import ejercicio.Ejercicio;

public class VistaCambiarEjercicio extends JPanel{
	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista principal de Cambiar Ejercicio (del Profesor)";
	final static String CAMBIAR_EJERCICIO = "Carta con la vista de cambio ejercicio del Profesor";
	final static String ANIADIR_PREGUNTABOOL = "Carta con la vista de aniadir pregunta booleana a un ejercicio (del Profesor)";
	final static String ANIADIR_MULTIPREGUNTA = "Carta con la vista de aniadir pregunta multiple a un ejercicio (del Profesor)";
	final static String ANIADIR_PREGUNTAUNICA = "Carta con la vista de aniadir pregunta unica a un ejercicio (del Profesor)";
	final static String ANIADIR_PREGUNTALIBRE = "Carta con la vista de aniadir pregunta libre a un ejercicio (del Profesor)";
	private JLabel titulo, etiquetaTipoPreg;
	private JLabel etiquetaNombre, etiquetaPeso, etiquetaVisible, etiquetaAleatorio, etiquetaIni, etiquetaFin;
	private JLabel etiquetaAno, etiquetaMes, etiquetaDia, etiquetaHora, etiquetaMinuto;
	private JTextField textNombre, textPeso;
	private JTextField textAnoFin, textMesFin, textDiaFin, textHoraFin, textMinFin;
	private JTextField textAnoIni, textMesIni, textDiaIni, textHoraIni, textMinIni;
	private JComboBox<String> comboBoxVisible, comboBoxAleatorio, comboBoxPregunta;
	private JButton botonGuardarCambios, botonAniadirPregunta, botonVolver;
	private JPanel principal_ejercicio;
	
	
	/**
	 * Constructor del panel de Crear Asignatura
	 * @author Alvaro Martinez de Navascues
	 */
	public VistaCambiarEjercicio(){
		// Panel de CardLayout
		this.setLayout(new CardLayout());

		String opciones[] = { "Visible", "Oculto" };
		String opciones2[] = { "Aleatorio", "No Aleatorio" };
		String preguntas[] = { "Booleana", "Multipregunta", "Unica", "Libre" };

		// Layout del JPanel principal
		this.principal_ejercicio = new JPanel();
		SpringLayout layoutPrincipal = new SpringLayout();
		this.principal_ejercicio.setLayout(layoutPrincipal);

		titulo = new JLabel("CAMBIANDO EJERCICIO");
		titulo.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.principal_ejercicio.add(titulo);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, titulo, 0, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, titulo, 30, SpringLayout.NORTH, this.principal_ejercicio);

		// Creamos nuestros componentes
		etiquetaNombre = new JLabel("Nombre del Ejercicio: ");
		this.principal_ejercicio.add(etiquetaNombre);
		textNombre = new JTextField(20);
		this.principal_ejercicio.add(textNombre);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, -100,
				SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaNombre, 30, SpringLayout.SOUTH, titulo);
		layoutPrincipal.putConstraint(SpringLayout.WEST, textNombre, 5, SpringLayout.EAST, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textNombre, 0, SpringLayout.NORTH, etiquetaNombre);

		etiquetaPeso = new JLabel("Peso del Ejercicio: ");
		this.principal_ejercicio.add(etiquetaPeso);
		textPeso = new JTextField(20);
		this.principal_ejercicio.add(textPeso);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.EAST, etiquetaPeso, 0, SpringLayout.EAST, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaPeso, 20, SpringLayout.SOUTH, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.WEST, textPeso, 5, SpringLayout.EAST, etiquetaPeso);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textPeso, 0, SpringLayout.NORTH, etiquetaPeso);

		// IMPLEMENTAR CAMBIO DE STRING A NUMERO
		// String numCadena = "1";
		// int numEntero = Integer.parseInt(numCadena);

		etiquetaVisible = new JLabel("�Oculto o visible?: ");
		this.principal_ejercicio.add(etiquetaVisible);
		comboBoxVisible = new JComboBox<String>(opciones);
		this.principal_ejercicio.add(comboBoxVisible);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaVisible, 20, SpringLayout.SOUTH, etiquetaPeso);
		layoutPrincipal.putConstraint(SpringLayout.EAST, etiquetaVisible, 0, SpringLayout.EAST, etiquetaPeso);
		layoutPrincipal.putConstraint(SpringLayout.WEST, comboBoxVisible, 5, SpringLayout.EAST, etiquetaVisible);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, comboBoxVisible, 0, SpringLayout.NORTH, etiquetaVisible);

		etiquetaAleatorio = new JLabel("�Orden Aleatorio?: ");
		this.principal_ejercicio.add(etiquetaAleatorio);
		comboBoxAleatorio = new JComboBox<String>(opciones2);
		this.principal_ejercicio.add(comboBoxAleatorio);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaAleatorio, 20, SpringLayout.SOUTH, etiquetaVisible);
		layoutPrincipal.putConstraint(SpringLayout.EAST, etiquetaAleatorio, 0, SpringLayout.EAST, etiquetaVisible);
		layoutPrincipal.putConstraint(SpringLayout.WEST, comboBoxAleatorio, 5, SpringLayout.EAST, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, comboBoxAleatorio, 0, SpringLayout.NORTH, etiquetaAleatorio);

		etiquetaIni = new JLabel("Fecha de Inicio: ");
		this.principal_ejercicio.add(etiquetaIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaIni, 40, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaIni, -200, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaFin = new JLabel("Fecha de Fin: ");
		this.principal_ejercicio.add(etiquetaFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaFin, 20, SpringLayout.SOUTH, etiquetaIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaFin, -200, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

	

		etiquetaAno = new JLabel("A�o");
		this.principal_ejercicio.add(etiquetaAno);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaAno, 10, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaAno, -110, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textAnoIni = new JTextField(4);
		this.principal_ejercicio.add(textAnoIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textAnoIni, 10, SpringLayout.SOUTH, etiquetaAno);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textAnoIni, -110, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textAnoFin = new JTextField(4);
		this.principal_ejercicio.add(textAnoFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textAnoFin, 10, SpringLayout.SOUTH, textAnoIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textAnoFin, -110, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaMes = new JLabel("Mes");
		this.principal_ejercicio.add(etiquetaMes);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaMes, 10, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaMes, -70, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textMesIni = new JTextField(2);
		this.principal_ejercicio.add(textMesIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textMesIni, 10, SpringLayout.SOUTH, etiquetaMes);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textMesIni, -70, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textMesFin = new JTextField(2);
		this.principal_ejercicio.add(textMesFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textMesFin, 10, SpringLayout.SOUTH, textMesIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textMesFin, -70, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaDia = new JLabel("Dia");
		this.principal_ejercicio.add(etiquetaDia);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaDia, 10, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaDia, -33, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textDiaIni = new JTextField(2);
		this.principal_ejercicio.add(textDiaIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textDiaIni, 10, SpringLayout.SOUTH, etiquetaDia);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textDiaIni, -30, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textDiaFin = new JTextField(2);
		this.principal_ejercicio.add(textDiaFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textDiaFin, 10, SpringLayout.SOUTH, textDiaIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textDiaFin, -30, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaHora = new JLabel("Hora");
		this.principal_ejercicio.add(etiquetaHora);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaHora, 10, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaHora, 0, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textHoraIni = new JTextField(2);
		this.principal_ejercicio.add(textHoraIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textHoraIni, 10, SpringLayout.SOUTH, etiquetaHora);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textHoraIni, -0, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textHoraFin = new JTextField(2);
		this.principal_ejercicio.add(textHoraFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textHoraFin, 10, SpringLayout.SOUTH, textHoraIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textHoraFin, 0, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaMinuto = new JLabel("Minuto");
		this.principal_ejercicio.add(etiquetaMinuto);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaMinuto, 10, SpringLayout.SOUTH, etiquetaAleatorio);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaMinuto, 40,
				SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);

		textMinIni = new JTextField(2);
		this.principal_ejercicio.add(textMinIni);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textMinIni, 10, SpringLayout.SOUTH, etiquetaMinuto);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textMinIni, 40, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		textMinFin = new JTextField(2);
		this.principal_ejercicio.add(textMinFin);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textMinFin, 10, SpringLayout.SOUTH, textMinIni);
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, textMinFin, 40, SpringLayout.HORIZONTAL_CENTER,
				this.principal_ejercicio);

		etiquetaTipoPreg = new JLabel("Tipo de pregunta: ");
		this.principal_ejercicio.add(etiquetaTipoPreg);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaTipoPreg, 30, SpringLayout.SOUTH, etiquetaFin);
		layoutPrincipal.putConstraint(SpringLayout.WEST, etiquetaTipoPreg, 0, SpringLayout.WEST, etiquetaIni);

		comboBoxPregunta = new JComboBox<String>(preguntas);
		this.principal_ejercicio.add(comboBoxPregunta);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, comboBoxPregunta, 0, SpringLayout.NORTH, etiquetaTipoPreg);
		layoutPrincipal.putConstraint(SpringLayout.WEST, comboBoxPregunta, 10, SpringLayout.EAST, etiquetaTipoPreg);
		
		botonAniadirPregunta = new JButton("Aniadir Pregunta");
		this.principal_ejercicio.add(botonAniadirPregunta);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.NORTH, botonAniadirPregunta, 0, SpringLayout.NORTH,etiquetaTipoPreg);
		layoutPrincipal.putConstraint(SpringLayout.WEST, botonAniadirPregunta, 20, SpringLayout.EAST, comboBoxPregunta);

		botonGuardarCambios = new JButton("Guardar Cambios");
		this.principal_ejercicio.add(botonGuardarCambios);

		// Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonGuardarCambios, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
		layoutPrincipal.putConstraint(SpringLayout.SOUTH, botonGuardarCambios, -10, SpringLayout.SOUTH, this.principal_ejercicio);
		
		botonVolver = new JButton("Volver");
		this.principal_ejercicio.add(botonVolver);
		layoutPrincipal.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this.principal_ejercicio);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, botonVolver, 20, SpringLayout.NORTH, this.principal_ejercicio);
		
		
		this.add(this.principal_ejercicio, PRINCIPAL);
	} 
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el Nombre del ejercicio
	 * @author Alejandro Martin Climent
	 * @return String. El nombre del ejercicio
	 */
	public JTextField getNombre(){
		return this.textNombre;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el Nombre del ejercicio
	 * @author Alvaro Martinez de Navascues
	 * @return String. El nombre del ejercicio
	 */
	public JTextField getPeso(){
		return this.textPeso;
	}
	
	public JComboBox<String> getComboBoxPregunta(){
		return this.comboBoxPregunta;
	}
	
	/**
	 * Metodo que sirve para retornar la opcion seleccionada en la ComboBox
	 * @author Alvaro Martinez de Navascues
	 * @return boolean, true si es visible, false en caso contrario
	 */
	/*public String getComboBoxPregunta(){
		if (comboBoxVisible.getSelectedItem().equals("Booleana")){
			System.out.println("Booleana");
			return "Booleana";
		}else if(comboBoxVisible.getSelectedItem().equals("Libre")){
			return "Libre";
		}else if(comboBoxVisible.getSelectedItem().equals("Unica")){
			return "Unica";
		}else if(comboBoxVisible.getSelectedItem().equals("Multipregunta")){
			return "Multipregunta";
		}
		return null;
	}*/
	
	/**
	 * Metodo que sirve para retornar la opcion seleccionada en la ComboBox
	 * @author Alvaro Martinez de Navascues
	 * @return boolean, true si es visible, false en caso contrario
	 */
	public boolean getComboBoxSelectedVis(){
		if (comboBoxAleatorio.getSelectedItem().equals("Visible")){
			return true;
		}else {
			return false;
		}	
	}
	
	/**
	 * Metodo que sirve para retornar la opcion seleccionada en la ComboBox
	 * @author Alvaro Martinez de Navascues
	 * @return boolean, true si es aleatorio, false en caso contrario
	 */
	public boolean getComboBoxSelectedAleat(){
		if (comboBoxAleatorio.getSelectedItem().equals("Aleatorio")){
			return true;
		}else{
			return false;
		}		
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en 
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getAnoIni(){
		return this.textAnoIni;
	}
	
	/**
	 * Getter del boton Guardar Cambios
	 * @return JButton. El boton guardar Cambios
	 */
	public JButton getBotonGuardarCambios() {
		return botonGuardarCambios;
	}

	/**
	 * Getter del boton Aniadir Pregunta
	 * @return JButton. El boton guardar Cambios
	 */
	public JButton getBotonAniadirPregunta() {
		return botonAniadirPregunta;
	}

	/**
	 * Getter del boton Volver
	 * @return JButton. El boton guardar Cambios
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}

	/**
	 * Metodo que sirve para retornar el texto contenido en 
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getAnoFin(){
		return this.textAnoFin;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getMesIni(){
		return this.textMesIni;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getMesFin(){
		return this.textMesFin;
	}

	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getDiaIni(){
		return this.textDiaIni;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getDiaFin(){
		return this.textDiaFin;
	}
	
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getHoraIni(){
		return this.textHoraFin;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getHoraFin() {
		return textHoraFin;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getMinIni(){
		return this.textMinIni;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getMinFin(){
		return this.textMinFin;
	}
	
	/**
	 *Metodo que muestra la vista principal del cambio de ejercicio
	 *@author �lvaro Martinez de Navascues 
	 */
	public void mostrarVistaPrincipalCambioEj(){
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarCrearPreguntaBoooleana(Ejercicio ejercicio){
		VistaCrearPreguntaBooleana vista_preg = new VistaCrearPreguntaBooleana(ejercicio);
		ControlVistaCrearPreguntaBooleana control_preg = new ControlVistaCrearPreguntaBooleana(vista_preg, this, ejercicio);
		vista_preg.setControlador(control_preg);
		this.add(vista_preg, ANIADIR_PREGUNTABOOL);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, ANIADIR_PREGUNTABOOL);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarCrearMultipregunta(Ejercicio ejercicio){
		VistaCrearMultipregunta vista_preg = new VistaCrearMultipregunta(ejercicio);
		ControlVistaCrearMultipregunta control_preg = new ControlVistaCrearMultipregunta(vista_preg, this, ejercicio);
		vista_preg.setControlador(control_preg);
		this.add(vista_preg, ANIADIR_MULTIPREGUNTA);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, ANIADIR_MULTIPREGUNTA);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarCrearPreguntaUnica(Ejercicio ejercicio){
		VistaCrearPreguntaUnica vista_preg = new VistaCrearPreguntaUnica(ejercicio);
		ControlVistaCrearPreguntaUnica control_preg = new ControlVistaCrearPreguntaUnica(vista_preg, this, ejercicio);
		vista_preg.setControlador(control_preg);
		this.add(vista_preg, ANIADIR_PREGUNTAUNICA);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, ANIADIR_PREGUNTAUNICA);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarCrearPreguntaLibre(Ejercicio ejercicio){
		VistaCrearPreguntaLibre vista_preg = new VistaCrearPreguntaLibre(ejercicio);
		ControlVistaCrearPreguntaLibre control_preg = new ControlVistaCrearPreguntaLibre(vista_preg, this, ejercicio);
		vista_preg.setControlador(control_preg);
		this.add(vista_preg, ANIADIR_PREGUNTALIBRE);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, ANIADIR_PREGUNTALIBRE);
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Crear Asignatura
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador){
		this.botonAniadirPregunta.addActionListener(controlador);
		this.botonGuardarCambios.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}
}