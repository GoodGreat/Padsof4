package controladoresProfesor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import ejercicio.Pregunta;
import panelesProfesor.*;

public class ControlVistaEjercicioProf implements ActionListener{
	private VistaEjercicioProf vista;
	private VistaTemaProf vista_tema;
	
	public ControlVistaEjercicioProf(VistaEjercicioProf vista, VistaTemaProf vista_tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_tema.mostrarVistaTemaProf();
		}else if(event.getSource().equals(this.vista.getBotonCambiarEjercicio())){
			this.vista.mostrarVistaCambiarEjercicio();
		} else if(event.getSource().equals(this.vista.getBotonIr())){
			if(this.vista.getComboBoxPregunta() != null){
				Pregunta pregunta = this.vista.getComboBoxPregunta();
				this.vista.mostrarVistaPregunta(pregunta);
			}
		}
	}
}
