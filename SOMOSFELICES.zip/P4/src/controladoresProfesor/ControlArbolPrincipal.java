package controladoresProfesor;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.Asignatura;
import interfaces.NodoInterfaz;
import panelesProfesor.VistaPrincipalProf;
import sistema.Sistema;

/**
 * ControlArbolPrincipal, implementa el controlador del JTree de las asignaturas
 */
public class ControlArbolPrincipal implements TreeSelectionListener{
	private VistaPrincipalProf vista_prof;
	
	/**
	 * Contructor del controlador de la vista principal dle profesor
	 * @param vista_prof, la vista principal del profesor
	 */
	public ControlArbolPrincipal(VistaPrincipalProf vista_prof){
		this.vista_prof = vista_prof;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0
				|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent())
						.equals(this.vista_prof.getRaiz())) {
			// No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if (((DefaultMutableTreeNode) this.vista_prof.getArbol().getLastSelectedPathComponent()) != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_prof.getArbol()
						.getLastSelectedPathComponent()).getUserObject();
				if (nodo.getObjectClassName().equals("Asignatura")) {
					for (Asignatura asignaturaAux: Sistema.getInstance().getAsignaturas()){
						if (asignaturaAux.getNombre().equals(((Asignatura) nodo).getNombre())){
							Asignatura asignatura = asignaturaAux;
							this.vista_prof.mostrarVistaAsignatura(asignatura);
						}
					}					
				}
			}
		}
	}
}
