package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaPrincipalProf;
import sistema.Alumno;

/**
 * Clase ControlVistaAsignaturaProf, controlador de la vista de una asignatura del profesor
 * @author �lvaro
 *
 */
public class ControlVistaAsignaturaProf implements ActionListener{
		private Asignatura asignatura; 
		private VistaAsignaturaProf vista;
		private VistaPrincipalProf vista_prof;
		
		/**
		 * Constructor del controlador de la Vista Asignatura de un profesor
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_prof. Panel de la vista principal del profe
		 */
		public ControlVistaAsignaturaProf(VistaAsignaturaProf vista, VistaPrincipalProf vista_prof, Asignatura asignatura){
			this.vista = vista;
			this.vista_prof = vista_prof;
			this.asignatura = asignatura;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			//El primer paso es validar lo introducido por el usuario
			if (event.getSource().equals(this.vista.getBotonCrearTema())){
				this.vista.mostrarVistaCrearTema();
			}else if(event.getSource().equals(this.vista.getBotonGestionAlum())){
				this.vista.mostrarVistaGestionAlum();
			}else if(event.getSource().equals(this.vista.getBotonCambiarAsig())){
				this.vista.mostrarVistaCambiarAsignatura();
			} else if(event.getSource().equals(this.vista.getBotonCalcularNotaAlum())){
				if(this.vista.getNombreAlum().getText().equals("")){
					JOptionPane.showMessageDialog(this.vista, "Introduce el nombre de un alumno", "Error",
							JOptionPane.ERROR_MESSAGE);
				}else{
					for(Alumno alumnoaux: asignatura.getAlumnos()){
						if(this.vista.getNombreAlum().getText().equals(alumnoaux.getNumA())){
							JOptionPane.showMessageDialog(this.vista, "La nota del alumno "
									+ alumnoaux.getNombre() + " " + alumnoaux.getApellido() + " en la asignatura "
									+ this.asignatura.getNombre() + " es " + asignatura.consultarCalificacionesAlumno(alumnoaux), "CALIFICACION DEL ALUMNO",
									JOptionPane.INFORMATION_MESSAGE);
						}
					}
				}
			}else if(event.getSource().equals(this.vista.getBotonVolver())){
				this.vista_prof.mostrarVistaPrincipalProf();
			}
		}
	}