package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;

import ejercicio.Ejercicio;
import panelesProfesor.VistaCambiarEjercicio;
import panelesProfesor.VistaCrearPreguntaLibre;
import sistema.*;

/**
 * Clase que se encargara de controlar la creacion de una PreguntaLibre
 * @author �lvaro
 *
 */
public class ControlVistaCrearPreguntaLibre implements ActionListener{
	private VistaCrearPreguntaLibre vista;
	private Sistema sistema;
	private Ejercicio ejercicio;
	private VistaCambiarEjercicio vista_cambiar;
	
	/**
	 * Constructor del controlador de la vistaCrearPreguntaLibre
	 * @param vista, la vista que ve el usuario
	 * @param vistaCambiarEjercicio, la vista de cambiar un ejercicio
	 * @param ejercicio, el ejercicio al que pertenecera esta pregunta
	 */
	public ControlVistaCrearPreguntaLibre(VistaCrearPreguntaLibre vista, VistaCambiarEjercicio vistaCambiarEjercicio, Ejercicio ejercicio){
		this.vista = vista;
		this.sistema = Sistema.getInstance();
		this.vista_cambiar = vistaCambiarEjercicio;
		this.ejercicio = ejercicio;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if(event.getSource().equals(this.vista.getBotonCrearPregunta())){
			if (this.vista.getEnunciado().equals("") || this.vista.getPuntuacion().equals("") || 
					this.vista.getResta().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos los campos", "Error",
						JOptionPane.ERROR_MESSAGE);
				//this.vista_cambiar.mostrarCrearPreguntaBooleana(ejercicio);
			} else {
				
				float peso = Float.parseFloat(this.vista.getPuntuacion());
				float resta = Float.parseFloat(this.vista.getResta());
				
				if (sistema.crearPregunta(ejercicio, this.vista.getEnunciado(), peso, this.vista.getComboBoxSelectedResta(),
						resta, "Libre") == false) {
					JOptionPane.showMessageDialog(this.vista, "Error al crear el ejercicio", "Error",
							JOptionPane.ERROR_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(this.vista,
							"La pregunta " + this.vista.getEnunciado() + " ha sido creada con exito",
							"CREACION DE PREGUNTA", JOptionPane.INFORMATION_MESSAGE);
					
				}
				this.vista_cambiar.mostrarVistaPrincipalCambioEj();
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_cambiar.mostrarVistaPrincipalCambioEj();
		}
	}	
}