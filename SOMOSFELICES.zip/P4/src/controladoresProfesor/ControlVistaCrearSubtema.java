package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.*;
import panelesProfesor.VistaCrearSubtema;
import panelesProfesor.VistaTemaProf;

public class ControlVistaCrearSubtema implements ActionListener{
	private VistaCrearSubtema vista;
	private VistaTemaProf vista_tema;
	private Tema tema;
	
	/**
	 * Constructor del controlador de la VistaCrearSubtema
	 * @author �lvaro Martinez de xNavascues
	 * @param vista. Panel que ve el usuario
	 * @param tema, el tema en el que se creara
	 */
	public ControlVistaCrearSubtema(VistaCrearSubtema vista, VistaTemaProf vista_tema, Tema tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (event.getSource().equals(this.vista.getbotonCrearSubtema())) {
			
			if (this.vista.getNombre().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos los campos", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else {
				if (this.vista.getComboBoxSelected() == false) {
					System.out.println("Estoy aqui");
					Tema subtema = new Tema(this.vista.getNombre(), false);
					if (this.tema.aniadirSubtema(subtema) == false) {
						JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
								JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(this.vista,
								"El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA",
								JOptionPane.INFORMATION_MESSAGE);
						this.vista_tema.mostrarVistaTemaProf();
					}
				}else{
					Tema subtema = new Tema(this.vista.getNombre(), true);
					if (this.tema.aniadirSubtema(subtema) == false) {
						JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
								JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(this.vista,
								"El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA",
								JOptionPane.INFORMATION_MESSAGE);
						this.vista_tema.mostrarVistaTemaProf();
					}
				}
			}
		} else if (event.getSource().equals(this.vista.getBotonVolver())) {
			this.vista_tema.mostrarVistaTemaProf();
		}
	}
}
