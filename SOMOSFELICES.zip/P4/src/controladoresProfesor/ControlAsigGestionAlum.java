package controladoresProfesor;

public class ControlAsigGestionAlum {

}
