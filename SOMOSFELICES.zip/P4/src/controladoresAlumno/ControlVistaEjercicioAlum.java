package controladoresAlumno;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import ejercicio.Multipregunta;
import ejercicio.Pregunta;
import ejercicio.PreguntaBooleana;
import ejercicio.PreguntaLibre;
import ejercicio.PreguntaUnica;
import panelesAlumno.VistaEjercicioAlum;
import panelesAlumno.VistaTemaAlum;
import panelesProfesor.*;

public class ControlVistaEjercicioAlum implements ActionListener{
	private VistaEjercicioAlum vista;
	private VistaTemaAlum vista_tema;
	
	public ControlVistaEjercicioAlum(VistaEjercicioAlum vista, VistaTemaAlum vista_tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_tema.mostrarVistaTemaAlum();
		}else if(event.getSource().equals(this.vista.getBotonContestar())){
			 Pregunta pregunta = (Pregunta)this.vista.getComboBoxPregunta().getSelectedItem();
			if(pregunta.getTipo().equals("Booleana")){
				PreguntaBooleana preg = (PreguntaBooleana) pregunta;
				this.vista.mostrarVistaPreguntaBooleanaAlum(preg, vista);
			} else if(pregunta.getTipo().equals("Unica")){	
				PreguntaUnica preg = (PreguntaUnica) pregunta;
				this.vista.mostrarVistaPreguntaUnicaAlum(preg, vista);
			} else if(pregunta.getTipo().equals("Libre")){	
				PreguntaLibre preg = (PreguntaLibre) pregunta;
				this.vista.mostrarVistaPreguntaLibreAlum(preg, vista);
			} else if(pregunta.getTipo().equals("Multipregunta")){
				Multipregunta preg = (Multipregunta) pregunta;
				this.vista.mostrarVistaMultipreguntaAlum(preg, vista);
			}
		}		
	}
}
