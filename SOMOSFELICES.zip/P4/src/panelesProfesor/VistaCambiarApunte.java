package panelesProfesor;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.*;
import javax.swing.*;

public class VistaCambiarApunte extends JPanel{
	private static final long serialVersionUID = 1L;
	private JLabel titulo, etiquetaNombre, etiquetaVisible, etiquetaContenido;
	private JTextField textNombre, textContenido;
	private JComboBox<String> comboBoxVisible;
	private JButton botonGuardarCambios, botonVolver;
	
	/**
	 * Constructor del panel de Crear Asignatura
	 * @author Alvaro Martinez de Navascues
	 */
	public VistaCambiarApunte(){
		String opciones[] = {"Visible", "Oculto"};		
		
		//Layout del JPanel principal
		SpringLayout layoutPrincipal = new SpringLayout();
		this.setLayout(layoutPrincipal);
		
		titulo = new JLabel("CAMBIANDO APUNTE");
		titulo.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.add(titulo);
		
		//Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, titulo, 0, SpringLayout.HORIZONTAL_CENTER, this);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, titulo, 30, SpringLayout.NORTH, this);
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel("Nombre del Apunte: ");
		this.add(etiquetaNombre);
		textNombre = new JTextField(20);
		this.add(textNombre);
		
		//Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, -100, SpringLayout.HORIZONTAL_CENTER, this);
		layoutPrincipal.putConstraint(SpringLayout.VERTICAL_CENTER, etiquetaNombre, -70, SpringLayout.VERTICAL_CENTER, this);
		layoutPrincipal.putConstraint(SpringLayout.WEST, textNombre, 5, SpringLayout.EAST, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textNombre, 0, SpringLayout.NORTH, etiquetaNombre);
		
		
		etiquetaContenido = new JLabel("Contenido: ");
		this.add(etiquetaContenido);
		textContenido = new JTextField(60);
		this.add(textContenido);
		
		
		//Constraints
		layoutPrincipal.putConstraint(SpringLayout.WEST, etiquetaContenido, 0, SpringLayout.WEST, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaContenido, 10, SpringLayout.SOUTH, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.WEST, textContenido, 5, SpringLayout.EAST, etiquetaContenido);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, textContenido, 0, SpringLayout.NORTH, etiquetaContenido);
		
		
		etiquetaVisible = new JLabel("�Oculto o visible?: ");
		this.add(etiquetaVisible);
		comboBoxVisible = new JComboBox<String>(opciones);
		this.add(comboBoxVisible);
		
		//Constraints
		layoutPrincipal.putConstraint(SpringLayout.WEST, etiquetaVisible, 0, SpringLayout.WEST, etiquetaNombre);
		layoutPrincipal.putConstraint(SpringLayout.NORTH, etiquetaVisible, 10, SpringLayout.SOUTH, etiquetaContenido);		
		layoutPrincipal.putConstraint(SpringLayout.WEST, comboBoxVisible, 5, SpringLayout.EAST, etiquetaVisible);
		layoutPrincipal.putConstraint(SpringLayout.BASELINE, comboBoxVisible, 0, SpringLayout.BASELINE, etiquetaVisible);
		
		botonGuardarCambios = new JButton("Guardar Cambios");
		this.add(botonGuardarCambios);
		
		//Constraints
		layoutPrincipal.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonGuardarCambios, 0, SpringLayout.HORIZONTAL_CENTER, this);
		layoutPrincipal.putConstraint(SpringLayout.SOUTH, botonGuardarCambios, -30, SpringLayout.SOUTH, this);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 40));
		this.add(botonVolver);
		
		layoutPrincipal.putConstraint(SpringLayout.NORTH, botonVolver, 0, SpringLayout.NORTH, titulo);
		layoutPrincipal.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this);
		
	} 
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el Nombre de la ASignatura
	 * @author Alejandro Martin Climent
	 * @return String. El nombre de la asignatura
	 */
	public JTextField getNombre(){
		return this.textNombre;
	}
	
	/**
	 * Metodo que sirve para retornar el contenido del apunte
	 * @author Alvaro Martinez de Navascues
	 * @return String. El nombre de la asignatura
	 */
	public JTextField getContenido(){
		return this.textContenido;
	}
	
	/**
	 * Metodo que sirve para retornar la JComboBox
	 * @return JComboBox. La comboBox
	 */
	public JComboBox<String> getComboBoxVisible(){
		return comboBoxVisible;
	}
	
	/**
	 * Metodo que sirve para retornar el boton Volver
	 * @return JButton. El boton
	 */
	public JButton getBotonVolver(){
		return botonVolver;
	}
	
	/**
	 * Metodo que sirve para retornar el boton Guardar Cambios
	 * @return JButton. El boton
	 */
	public JButton getBotonGuardarCambios(){
		return botonGuardarCambios;
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador a los botones de esta vista
	 * @author Alejandro Martin Climent
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador){
		this.botonGuardarCambios.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}
}