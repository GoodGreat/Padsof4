package controladoresProfesor;

import java.awt.event.*;

import javax.swing.JOptionPane;
import sistema.*;
import asignatura.*;
import ejercicio.Multipregunta;
import ejercicio.Multirrespuesta;
import ejercicio.Opcion;
import ejercicio.Pregunta;
import ejercicio.PreguntaLibre;
import ejercicio.PreguntaUnica;
import ejercicio.RespuestaUnica;
import panelesProfesor.VistaEjercicioProf;
import panelesProfesor.VistaPreguntaLibreProf;
import panelesProfesor.VistaPreguntaUnicaProf;

public class ControlVistaMostrarPreguntaLibre implements ActionListener{
		private PreguntaLibre pregunta; 
		private VistaPreguntaLibreProf vista;
		private VistaEjercicioProf vistaEjer;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_prof. Panel de la vista principal del profe
		 */
		public ControlVistaMostrarPreguntaLibre(VistaPreguntaLibreProf vista, VistaEjercicioProf vistaEjer, PreguntaLibre pregunta){
			this.vista = vista;
			this.vistaEjer = vistaEjer;
			this.pregunta = pregunta;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
				if(event.getSource().equals(this.vista.getBotonVolver())){
					vistaEjer.mostrarVistaPrincipal();
				} else if(event.getSource().equals(this.vista.getBotonAniadirSolucion())){
					if(this.vista.getTextAniadirSol().getText().equals("")){
						JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar el campo de la solucion", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Deberia2");
						vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
					}else{
						System.out.println("Deberia3");
						String opcion = this.vista.getTextAniadirSol().getText();
						Opcion opcion1 = new Opcion(opcion);
						pregunta.pregAniadirOpcion(opcion1);
						if(pregunta.getRespuestaProf() == null){
							Multirrespuesta respuesta = new Multirrespuesta(null);
							respuesta.resAniadirOpcion(opcion1);
							pregunta.setRespuestaProf(respuesta);
							vista.actualizar();
							vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
						}else{
							pregunta.getRespuestaProf().resAniadirOpcion(opcion1);
							vista.actualizar();
							vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
						}
				} 
		}else if (event.getSource().equals(this.vista.getBotonEliminarSolucion())){
			if(pregunta.getRespuestaProf() == null){
				JOptionPane.showMessageDialog(this.vista, "No existe solucion del Profesor, no puedes borrarla", "Error",
						JOptionPane.ERROR_MESSAGE);
				System.out.println("Deberia6");
				vista.actualizar();
				vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
				}
			
			for(int k =0; k < pregunta.getRespuestaProf().getOpciones().size(); k++){
				if(pregunta.getRespuestaProf().getOpciones().get(k).equals((Opcion)this.vista.getcomboBoxSoluciones().getSelectedItem())){
					for(int h =0; h < pregunta.getOpciones().size(); h++){
						if(pregunta.getRespuestaProf().getOpciones().get(k).equals(pregunta.getOpciones().get(h))){
							pregunta.getOpciones().remove(pregunta.getOpciones().get(h));
							pregunta.getRespuestaProf().getOpciones().remove(pregunta.getRespuestaProf().getOpciones().get(k));
						}
				}
			}
		}
			System.out.println("Deberia111");
			vista.actualizar();
			vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
		}else if(event.getSource().equals(this.vista.getBotonMostrarEstadisticas())){
			JOptionPane.showMessageDialog(this.vista, "El porcentaje de alumnos que contestaron esta pregunta es "
					+ pregunta.alumnosContestados() + "% " + " y un "
					+ pregunta.alumnosContestadosCorrecto()  + "% contesto correctamente. ", 
					"ESTADISTICAS", JOptionPane.INFORMATION_MESSAGE);
			vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
		}else{
			vista.actualizar();
			vistaEjer.mostrarVistaPreguntaLibre(pregunta, vistaEjer);
		}
	}
}