package controladores;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import interfaces.NodoInterfaz;
import paneles.VistaAsignaturaProf;


public class ControlArbolAsignatura implements TreeSelectionListener{
	private DefaultMutableTreeNode nodo;
	private VistaAsignaturaProf vista_asig;
	
	public ControlArbolAsignatura(VistaAsignaturaProf vista_asig){
		this.vista_asig = vista_asig;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).equals(this.vista_asig.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
			}else{
			NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_asig.getArbol().getLastSelectedPathComponent()).getUserObject();
			
			if (nodo.getObjectClassName().equals("Tema")) {
				Tema tema = (Tema)nodo;
				this.vista_asig.mostrarVistaTema(tema);
			}
			
			}		
	}

}
