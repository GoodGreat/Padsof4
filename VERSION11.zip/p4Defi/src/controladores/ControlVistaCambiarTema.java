package controladores;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.Tema;
import paneles.*;
import sistema.*;

public class ControlVistaCambiarTema implements ActionListener{
	private VistaCambiarTema vista;
	private Sistema sistema;
	private VistaTemaProf vista_tema;
	private Tema tema;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCambiarTema(VistaCambiarTema vista, VistaTemaProf vista_temaProf, Tema tema){
		this.vista = vista;
		this.sistema = Sistema.getInstance();
		this.vista_tema = vista_temaProf;
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// SI NO ES O "" O EL NOMBRE QUE YA TENIA ANTES, CAMBIAMOS POR EL INTRODUCIDO POR EL USUARIO
		if (this.vista.getNombre().equals("") == false && this.vista.getNombre().equals(tema.getNombre()) == false) {
			tema.setNombre(this.vista.getNombre());
		}
		
		/*if(this.vista.getComboBoxSelected() == false && this.asignatura.getVisible() == true) {
			tema.ocultarTema();
		} else if(this.vista.getComboBoxSelected() == true && this.asignatura.getVisible() == false)
			for(int i=0; i < sistema.getAsignaturas().size(); i++){
				if( sistema.getAsignaturas().get(i).getNombre().equals(asignatura.getNombre()) == true){
					sistema.getAsignaturas().get(i).ocultarAsignatura();
							
				}
			}
			*/
	/*else{
			JOptionPane.showMessageDialog(this.vista, "La asignatura " + this.vista.getNombre() + " ha sido creada con exito",
					"CREACION DE ASIGNATURA", JOptionPane.INFORMATION_MESSAGE);
			this.vista_asig.mostrarVistaAsignaturaProf();
		}*/
		
		this.vista_tema.mostrarVistaTemaProf();
	}
}
