package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;
import paneles.*;
import sistema.*;
import asignatura.*;
import ventanas.*;

public class ControlVistaSubtemaProf implements ActionListener{
		private Tema tema; 
		private VistaTemaProf vista;
		private VistaTemaProf vista_temaSup;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param sistema. Clase principal de nuestro proyecto
		 */
		public ControlVistaSubtemaProf(VistaTemaProf vista, VistaTemaProf vista_temaSup, Tema tema){
			this.vista = vista;
			this.vista_temaSup = vista_temaSup;
			this.tema = tema;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			if (event.getSource().equals(this.vista.getBotonCrearSubtema())){
				this.vista.mostrarVistaCrearSubtema();
			} else if(event.getSource().equals(this.vista.getBotonCrearEjercicio())){
				this.vista.mostrarVistaCrearEjercicio();
			} else if(event.getSource().equals(this.vista.getBotonCrearApunte())){
				this.vista.mostrarVistaCrearApunte();
			}else if(event.getSource().equals(this.vista.getBotonCambiarTema())){
						this.vista.mostrarVistaCambiarTema();	
			}else if(event.getSource().equals(this.vista.getBotonVolver())){
			//	this.vista_asig.mostrarVistaAsignaturaProf();
			}
			
		}
	}