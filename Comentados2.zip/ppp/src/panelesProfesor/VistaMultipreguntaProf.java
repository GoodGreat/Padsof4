package panelesProfesor;


import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;
import javax.swing.*;
import ejercicio.*;

/**
 * VistaMultipreguntaProf, clase de la vista dde una multipregunta
 * @author �lvaro
 *
 */
public class VistaMultipreguntaProf extends JPanel{

	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista de la pregunta del Profesor";
	private JLabel etiquetaEnunciado, etiquetaPuntuacion;
	private JButton botonMostrarEstadistica, botonAniadirOpcion, botonEliminarOpcion, botonAniadirSolucion, botonEliminarSolucion, botonVolver;
	private JLabel etiquetaOpciones;
	private JComboBox<Opcion> comboBoxOpciones;
	private JLabel etiquetaSoluciones;
	private JComboBox<Opcion> comboBoxSoluciones;
	private JTextField textAniadirSol;
	private JTextField textAniadirOp;
	private Multipregunta pregunta;

	
	/**
	 * Constructor de la vista VistaMultipreguntaProf
	 * @param pregunta, pregunta que le entra
	 * @param vista_ej, vista del ejercicio
	 */
	public VistaMultipreguntaProf(Multipregunta pregunta, VistaEjercicioProf vista_ej){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		this.pregunta = pregunta;
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		this.add(etiquetaEnunciado);
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaEnunciado, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		if(pregunta.getFalloResta() == true){
			etiquetaPuntuacion = new JLabel("Esta pregunta vale: " + pregunta.getPuntuacion() +
					" puntos, y en caso de fallo resta: "+ pregunta.getResta() + "puntos");
		} else {
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y  no resta en caso de fallo");
		}
		
		this.add(etiquetaPuntuacion);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaPuntuacion, 20, SpringLayout.SOUTH, etiquetaEnunciado);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaPuntuacion, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		GridLayout glayout = new GridLayout(3,1);
		JPanel Checkbox = new JPanel((glayout));
		
		Checkbox.add(new JLabel("Seleccione las opciones correctas: "));
		this.add(Checkbox);
		
		//JCheckBox casilla = new JCheckBox(pregunta.getOpciones().get(0).getOpcion());
		//Checkbox.add(casilla);

		for(Opcion opcionAux: pregunta.getOpciones()){
			JCheckBox opcion = new JCheckBox(opcionAux.getOpcion());
			Checkbox.add(opcion);
		}

		layout.putConstraint(SpringLayout.NORTH, Checkbox, 20, SpringLayout.SOUTH, this.etiquetaPuntuacion);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, Checkbox, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		this.setPreferredSize(new Dimension(800, 350));
		
		botonMostrarEstadistica = new JButton("Mostrar Estadistica");
		this.add(botonMostrarEstadistica);
		
		layout.putConstraint(SpringLayout.SOUTH, botonMostrarEstadistica, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonMostrarEstadistica, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonAniadirOpcion = new JButton("Aniadir Opcion");
		this.add(botonAniadirOpcion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirOpcion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirOpcion, -300, SpringLayout.HORIZONTAL_CENTER, this);
	
		
		botonEliminarOpcion = new JButton("Eliminar Opcion");
		this.add(botonEliminarOpcion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarOpcion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarOpcion, -150, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonVolver = new JButton("Volver");
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonVolver, -300, SpringLayout.HORIZONTAL_CENTER, this);
		
		Opcion[] opciones = new Opcion[pregunta.getOpciones().size()];
		
		int i =0;
		
		for(i=0; i < pregunta.getOpciones().size(); i++){
			{
					opciones[i] = pregunta.getOpciones().get(i);
			}
		}
		
		etiquetaOpciones = new JLabel("Opciones: ");
		this.add(etiquetaOpciones);
		comboBoxOpciones = new JComboBox<Opcion>(opciones);
		this.add(comboBoxOpciones);
		
		//Constraints
		layout.putConstraint(SpringLayout.NORTH, etiquetaOpciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaOpciones, -600, SpringLayout.EAST, this);		
		layout.putConstraint(SpringLayout.EAST, comboBoxOpciones, -600, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, comboBoxOpciones, 200, SpringLayout.NORTH, this);

		
		botonAniadirSolucion = new JButton("Aniadir Solucion");
		this.add(botonAniadirSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirSolucion, 150, SpringLayout.HORIZONTAL_CENTER, this);
		
		
		botonEliminarSolucion = new JButton("Eliminar Solucion");
		this.add(botonEliminarSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarSolucion, 300, SpringLayout.HORIZONTAL_CENTER, this);

			
		etiquetaSoluciones = new JLabel("Soluciones: ");
		this.add(etiquetaSoluciones);
		layout.putConstraint(SpringLayout.NORTH, etiquetaSoluciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaSoluciones, -200, SpringLayout.EAST, this);
		
		if(pregunta.getRespuestaProf() != null){
			Opcion[] opciones2 = new Opcion[pregunta.getRespuestaProf().getOpciones().size()];
			for(i=0; i < pregunta.getRespuestaProf().getOpciones().size(); i++){
				{
						opciones2[i] = pregunta.getRespuestaProf().getOpciones().get(i);
				}
			}
			
			comboBoxSoluciones = new JComboBox<Opcion>(opciones2);
			this.add(comboBoxSoluciones);

			
			layout.putConstraint(SpringLayout.EAST, comboBoxSoluciones, -200, SpringLayout.EAST, this);
			layout.putConstraint(SpringLayout.NORTH, comboBoxSoluciones, 200, SpringLayout.NORTH, this);
		}	
		
		
		
		//Creamos nuestros componentes
	
		textAniadirOp = new JTextField(10);
		this.add(textAniadirOp);
		layout.putConstraint(SpringLayout.EAST, textAniadirOp, -635, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, textAniadirOp, 350, SpringLayout.NORTH, this);
		
		textAniadirSol = new JTextField(10);
		this.add(textAniadirSol);
		
		layout.putConstraint(SpringLayout.EAST, textAniadirSol, -183, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, textAniadirSol, 350, SpringLayout.NORTH, this);
	}
	
	/**
	 * Funcion de actualizar
	 * @author �lvaro
	 */
	public void actualizar(){
		this.removeAll();
		
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		this.add(etiquetaEnunciado);
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaEnunciado, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		if(pregunta.getFalloResta() == true){
			etiquetaPuntuacion = new JLabel("Esta pregunta vale: " + pregunta.getPuntuacion() +
					" puntos, y en caso de fallo resta: "+ pregunta.getResta() + "puntos");
		} else {
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y  no resta en caso de fallo");
		}
		
		this.add(etiquetaPuntuacion);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaPuntuacion, 20, SpringLayout.SOUTH, etiquetaEnunciado);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaPuntuacion, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		GridLayout glayout = new GridLayout(3,1);
		JPanel Checkbox = new JPanel((glayout));
		
		Checkbox.add(new JLabel("Seleccione las opciones correctas: "));
		this.add(Checkbox);
		
		//JCheckBox casilla = new JCheckBox(pregunta.getOpciones().get(0).getOpcion());
		//Checkbox.add(casilla);

		for(Opcion opcionAux: pregunta.getOpciones()){
			JCheckBox opcion = new JCheckBox(opcionAux.getOpcion());
			Checkbox.add(opcion);
		}

		layout.putConstraint(SpringLayout.NORTH, Checkbox, 20, SpringLayout.SOUTH, this.etiquetaPuntuacion);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, Checkbox, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		this.setPreferredSize(new Dimension(800, 350));
		
		botonMostrarEstadistica = new JButton("Cambiar Pregunta");
		this.add(botonMostrarEstadistica);
		
		layout.putConstraint(SpringLayout.SOUTH, botonMostrarEstadistica, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonMostrarEstadistica, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonAniadirOpcion = new JButton("Aniadir Opcion");
		this.add(botonAniadirOpcion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirOpcion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirOpcion, -300, SpringLayout.HORIZONTAL_CENTER, this);
	
		
		botonEliminarOpcion = new JButton("Eliminar Opcion");
		this.botonVolver.setPreferredSize(new Dimension(100,50));
		this.add(botonEliminarOpcion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarOpcion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarOpcion, -150, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonVolver = new JButton("Volver");
		this.botonVolver.setPreferredSize(new Dimension(100,50));
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonVolver, -300, SpringLayout.HORIZONTAL_CENTER, this);
		
		Opcion[] opciones = new Opcion[pregunta.getOpciones().size()];
		
		int i =0;
		
		for(i=0; i < pregunta.getOpciones().size(); i++){
			{
					opciones[i] = pregunta.getOpciones().get(i);
			}
		}
		
		etiquetaOpciones = new JLabel("Opciones: ");
		this.add(etiquetaOpciones);
		comboBoxOpciones = new JComboBox<Opcion>(opciones);
		this.add(comboBoxOpciones);
		
		//Constraints
		layout.putConstraint(SpringLayout.NORTH, etiquetaOpciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaOpciones, -600, SpringLayout.EAST, this);		
		layout.putConstraint(SpringLayout.EAST, comboBoxOpciones, -600, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, comboBoxOpciones, 200, SpringLayout.NORTH, this);

		
		botonAniadirSolucion = new JButton("Aniadir Solucion");
		this.add(botonAniadirSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirSolucion, 150, SpringLayout.HORIZONTAL_CENTER, this);
		
		
		botonEliminarSolucion = new JButton("Eliminar Solucion");
		this.add(botonEliminarSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarSolucion, 300, SpringLayout.HORIZONTAL_CENTER, this);



		etiquetaSoluciones = new JLabel("Soluciones: ");
		this.add(etiquetaSoluciones);
		layout.putConstraint(SpringLayout.NORTH, etiquetaSoluciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaSoluciones, -200, SpringLayout.EAST, this);
		
		if(pregunta.getRespuestaProf() != null){
			Opcion[] opciones2 = new Opcion[pregunta.getRespuestaProf().getOpciones().size()];
			
			for(i=0; i < pregunta.getRespuestaProf().getOpciones().size(); i++){
				{
						opciones2[i] = pregunta.getRespuestaProf().getOpciones().get(i);
				}
			}
			
			comboBoxSoluciones = new JComboBox<Opcion>(opciones2);
			this.add(comboBoxSoluciones);

			
			layout.putConstraint(SpringLayout.EAST, comboBoxSoluciones, -200, SpringLayout.EAST, this);
			layout.putConstraint(SpringLayout.NORTH, comboBoxSoluciones, 200, SpringLayout.NORTH, this);
		}	
		
		
		//Creamos nuestros componentes
	
		textAniadirOp = new JTextField(10);
		this.add(textAniadirOp);
		layout.putConstraint(SpringLayout.EAST, textAniadirOp, -635, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, textAniadirOp, 350, SpringLayout.NORTH, this);
		
		textAniadirSol = new JTextField(10);
		this.add(textAniadirSol);
		
		layout.putConstraint(SpringLayout.EAST, textAniadirSol, -183, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.NORTH, textAniadirSol, 350, SpringLayout.NORTH, this);
	}
	
	
	/**
	 * Metodo que sirve para retornar La opcion seleccionada
	 * @author Alvaro Martinez de Navascues
	 * @return JComboBox<Opcion>. La opcion seleccionada
	 */
	public JComboBox<Opcion> getcomboBoxOpciones(){
		return comboBoxOpciones;
	}
	
	/**
	 * Metodo que sirve para retornar La opcion seleccionada
	 * @author Alvaro Martinez de Navascues
	 * @return JComboBox<Opcion>. La opcion seleccionada
	 */
	public JComboBox<Opcion> getcomboBoxSoluciones(){
		return comboBoxSoluciones;
	}
	
	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton, boton
	*/
	public JButton getBotonAniadirOpcion() {
		 return botonAniadirOpcion;
    }
	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton, boton
	*/
	public JButton getBotonEliminarOpcion() {
		 return botonEliminarOpcion;
    }
	
	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton, boton
	*/
	public JButton getBotonAniadirSolucion() {
		 return botonAniadirSolucion;
    }
	
	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton, boton
	*/
	public JButton getBotonVolver() {
		 return botonVolver;
    }

	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton, boton
	*/
	public JButton getBotonEliminarSolucion() {
		 return botonEliminarSolucion;
    }
	
	/**
	 * Metodo que sirve para retornar el texto contenido
	 * @author Alejandro Martin Climent
	 * @return JTextField, texto
	 */
	public JTextField getTextAniadirOp(){
		return this.textAniadirOp;
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido
	 * @author Alejandro Martin Climent
	 * @return JTextField, texto
	 */
	public JTextField getTextAniadirSol(){
		return this.textAniadirSol;
	}
	
	/**
	* Getter del boton MostrarEstadisticas"
	* @author Alejandro Martin Climent
	* @return JButton.
	*/
	public JButton getBotonMostrarEstadisticas() {
		 return botonMostrarEstadistica;
    }
	
	/**
	 * Metodo que asigna el controlador a los botones de esta vista
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador de los botones
	 */
	public void setControlador(ActionListener controlador){
	
		this.botonMostrarEstadistica.addActionListener(controlador);
		this.botonAniadirOpcion.addActionListener(controlador);
		this.botonEliminarOpcion.addActionListener(controlador);
		this.botonAniadirSolucion.addActionListener(controlador);
		this.botonEliminarSolucion.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}
}

