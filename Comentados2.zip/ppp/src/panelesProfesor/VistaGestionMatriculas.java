package panelesProfesor;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.SpringLayout;

import sistema.*;

/**
 * VistaGestionMatriculas, vista de la gestion de las matriculas
 * @author �lvaro
 *
 */
public class VistaGestionMatriculas extends JPanel{

	private JButton botonAceptarMatricula, botonDenegarMatricula, botonVolver ;
	private static final long serialVersionUID = 1L;
	private DefaultListModel<Solicitud> modeloLista;
	private JList<Solicitud> lista;
	
	/**
	 * Constructor de la clase VistaGestionMatriculas
	 */
	public VistaGestionMatriculas(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		this.modeloLista = new DefaultListModel<Solicitud>();
		for (Solicitud solicitudAux: Sistema.getInstance().getSolicitudes()){
			this.modeloLista.addElement(solicitudAux);
		}
		this.lista = new JList<Solicitud>(this.modeloLista);
		
		lista.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane panel_lista = new JScrollPane(lista);
		panel_lista.setPreferredSize(new Dimension(780, 300));
		
		this.add(panel_lista);		
		
		JLabel etiquetaTitulo = new JLabel("GESTION DE MATRICULAS");
		etiquetaTitulo.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.add(etiquetaTitulo);
		layout.putConstraint(SpringLayout.NORTH, etiquetaTitulo, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaTitulo, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		layout.putConstraint(SpringLayout.NORTH, panel_lista, 20, SpringLayout.SOUTH, etiquetaTitulo);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, panel_lista, 0, SpringLayout.HORIZONTAL_CENTER, this);
				
		botonVolver = new JButton("Volver");
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonVolver, -320, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonAceptarMatricula = new JButton("Aceptar Matricula");
		this.add(botonAceptarMatricula);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAceptarMatricula, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAceptarMatricula, -75, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonDenegarMatricula = new JButton("Denegar Matricula");
		this.add(botonDenegarMatricula);
		
		layout.putConstraint(SpringLayout.SOUTH, botonDenegarMatricula, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonDenegarMatricula, 75, SpringLayout.HORIZONTAL_CENTER, this);
		this.setPreferredSize(new Dimension(800, 500));
	}
	
	/**
	 * Metodo que actualiza la Lista
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizarLista(){
		this.modeloLista.removeAllElements();
		for (Solicitud solicitudAux: Sistema.getInstance().getSolicitudes()){
			this.modeloLista.addElement(solicitudAux);
		}
	}
		
	/**
	 * Getter del boton "Aceptar Matricula"
	 * @author Alejandro Martin Climent
	 * @return JButton, boton
	 */
	public JButton getBotonAceptarMatricula() {
		return botonAceptarMatricula;
	}
	    
	/**
	 * Getter del boton "Denegar Matricula"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton, boton
	 */
	public JButton getBotonDenegarMatricula() {
		return botonDenegarMatricula;
	}

	/**
	 * Getter del boton "Volver"
	 * 
	 * @author Alejandro Martin Climent
	 * @return JButton, boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}

	/**
	 * Metodo que asigna los controladores a los botones de esta Vista. Tambien asigna controlador a la Lista
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador de los botones
	 * @param controlador_lista. Controlador de la lista
	 */
	public void setControlador(ActionListener controlador) {
		this.botonVolver.addActionListener(controlador);
		this.botonAceptarMatricula.addActionListener(controlador);
		this.botonDenegarMatricula.addActionListener(controlador);		
	}
	
	/**
	 * Getter del atributo lista
	 * 
	 * @author Alejandro Martin Climent
	 * @return JList. La lista
	 */
	public JList<Solicitud> getLista(){
		return this.lista;
	}
	
	/**
	 * Getter del Atributo modelo Lista
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @return DefaultListModel. El modelo
	 */
	public DefaultListModel<Solicitud> getModeloLista(){
		return this.modeloLista;
	}
}
