package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.*;
import panelesAlumno.*;
import panelesProfesor.VistaCrearTema;
import panelesProfesor.VistaTemaProf;
import sistema.*;
import ventanas.*;

public class ControlVistaCrearSubtema implements ActionListener{
	private VistaCrearTema vista;
	private VistaTemaProf vista_tema;
	private Sistema sistema;
	private Tema tema;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCrearSubtema(VistaCrearTema vista, VistaTemaProf vista_tema, Tema tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
		this.sistema = Sistema.getInstance();
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (this.vista.getNombre().equals("")) {
			JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar ambos campos", "Error",
					JOptionPane.ERROR_MESSAGE);
		} else if (sistema.crearTema(tema.getAsignatura(), this.vista.getNombre(), this.vista.getComboBoxSelected()) == false){
			JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
					JOptionPane.ERROR_MESSAGE);
		}else{
			JOptionPane.showMessageDialog(this.vista, "El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA", JOptionPane.INFORMATION_MESSAGE);
			this.vista_tema.mostrarVistaTemaProf();
		}
	}
}
