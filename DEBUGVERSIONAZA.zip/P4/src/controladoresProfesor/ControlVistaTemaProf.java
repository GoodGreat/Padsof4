package controladoresProfesor;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import asignatura.*;
import panelesAlumno.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaTemaProf;
import ventanas.*;

public class ControlVistaTemaProf implements ActionListener{
		private Tema tema; 
		private VistaTemaProf vista;
		private VistaAsignaturaProf vista_asig;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param sistema. Clase principal de nuestro proyecto
		 */
		public ControlVistaTemaProf(VistaTemaProf vista, VistaAsignaturaProf vista_asig, Tema tema){
			this.vista = vista;
			this.vista_asig = vista_asig;
			this.tema = tema;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			if (event.getSource().equals(this.vista.getBotonCrearSubtema())){
				this.vista.mostrarVistaCrearSubtema();
			} else if(event.getSource().equals(this.vista.getBotonCrearEjercicio())){
				this.vista.mostrarVistaCrearEjercicio();
			} else if(event.getSource().equals(this.vista.getBotonCrearApunte())){
				this.vista.mostrarVistaCrearApunte();
			}else if(event.getSource().equals(this.vista.getBotonCambiarTema())){
				this.vista.mostrarVistaCambiarTema();	
			}else if(event.getSource().equals(this.vista.getBotonVolver())){
				this.vista_asig.mostrarVistaAsignaturaProf();
			}
			
		}
	}