package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;

import asignatura.Asignatura;
import panelesAlumno.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaCrearTema;
import sistema.*;
import ventanas.*;

public class ControlVistaCrearTema implements ActionListener{
	private VistaCrearTema vista;
	private VistaAsignaturaProf vista_asig;
	private Sistema sistema;
	private Asignatura asignatura;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de xNavascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCrearTema(VistaCrearTema vista, VistaAsignaturaProf vista_asig, Asignatura asignatura){
		this.vista = vista;
		this.vista_asig = vista_asig;
		this.sistema = Sistema.getInstance();
		this.asignatura = asignatura;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (this.vista.getNombre().equals("")) {
			JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar ambos campos", "Error",
					JOptionPane.ERROR_MESSAGE);
		} else if (sistema.crearTema(asignatura, this.vista.getNombre(), this.vista.getComboBoxSelected()) == false){
			JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
					JOptionPane.ERROR_MESSAGE);
		}else{
			JOptionPane.showMessageDialog(this.vista, "El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA", JOptionPane.INFORMATION_MESSAGE);
			this.vista_asig.mostrarVistaAsignaturaProf();
		}
	}
}
