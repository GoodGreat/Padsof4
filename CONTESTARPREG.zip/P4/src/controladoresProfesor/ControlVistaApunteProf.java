package controladoresProfesor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import panelesProfesor.VistaApunteProf;
import panelesProfesor.VistaTemaProf;

public class ControlVistaApunteProf implements ActionListener{
	
	private VistaApunteProf vista;
	private VistaTemaProf vista_temaProf;
	
	/**
	 * Constructor del controlador de la vista de Apunte
	 * @param vista. Vista del apunte.
	 * @param vista_temaProf. Vista del tema.
	 */
	public ControlVistaApunteProf(VistaApunteProf vista, VistaTemaProf vista_temaProf){
		this.vista = vista;
		this.vista_temaProf = vista_temaProf;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonCambiarApunte())){
			this.vista.mostrarVistaCambiarApunteProf();
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_temaProf.mostrarVistaTemaProf();
		}
	}
}
