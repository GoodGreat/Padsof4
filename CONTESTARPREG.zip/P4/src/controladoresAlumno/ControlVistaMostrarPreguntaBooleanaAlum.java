package controladoresAlumno;

import java.awt.event.*;

import javax.swing.JOptionPane;
import sistema.*;
import asignatura.*;
import ejercicio.Opcion;
import ejercicio.Pregunta;
import ejercicio.PreguntaBooleana;
import ejercicio.RespuestaBooleana;
import panelesProfesor.VistaEjercicioProf;
import panelesProfesor.VistaMultipreguntaProf;
import panelesProfesor.VistaPreguntaBooleanaProf;

public class ControlVistaMostrarPreguntaBooleanaAlum implements ActionListener{
		private PreguntaBooleana pregunta; 
		private VistaPreguntaBooleanaProf vista;
		private VistaEjercicioProf vistaEjer;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_prof. Panel de la vista principal del profe
		 */
		public ControlVistaMostrarPreguntaBooleanaAlum(VistaPreguntaBooleanaProf vista, VistaEjercicioProf vistaEjer, PreguntaBooleana pregunta){
			this.vista = vista;
			this.vistaEjer = vistaEjer;
			this.pregunta = pregunta;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
				if(event.getSource().equals(this.vista.getBotonVolver())){
					vistaEjer.mostrarVistaPrincipal();
				}
				else if (event.getSource().equals(this.vista.getBotonAniadirOpcion())){
					if(this.vista.getTextAniadirOp().getText().equals("")){
						JOptionPane.showMessageDialog(this.vista, "Es obligatorio el campo de la opcion", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Deberia0");
						vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
				}else{
					System.out.println("Deberia1");
					String opcion = this.vista.getTextAniadirOp().getText();
					Opcion opcion1 = new Opcion(opcion);
					
					if(pregunta.getOpciones().size() == 1){
						JOptionPane.showMessageDialog(this.vista, "No puedes aniadir mas de 2 opciones no validas, es booleana", "Error",
								JOptionPane.ERROR_MESSAGE);
						vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
					} else if(pregunta.pregAniadirOpcion(opcion1) == false){
						JOptionPane.showMessageDialog(this.vista, "Error al crear la opcion", "Error",
								JOptionPane.ERROR_MESSAGE);
						vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
					}
				}
					vista.actualizar();
					vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
			} else if(event.getSource().equals(this.vista.getBotonAniadirSolucion())){
				if(this.vista.getTextAniadirSol().getText().equals("")){
					JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar el campo de la solucion", "Error",
							JOptionPane.ERROR_MESSAGE);
					System.out.println("Deberia2");
					vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
				}else{
					if(pregunta.getRespuestaProf() == null){
						System.out.println("Deberia3");
						String opcion = this.vista.getTextAniadirSol().getText();
						Opcion opcion1 = new Opcion(opcion);
						pregunta.pregAniadirOpcion(opcion1);
						RespuestaBooleana respuesta = new RespuestaBooleana(null);
						respuesta.resAniadirOpcion(opcion1);
						pregunta.setRespuestaProf(respuesta);
						vista.actualizar();
						vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
					}else{
						JOptionPane.showMessageDialog(this.vista, "Elimine antes la solucion ya dada", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Deberia5");
						vista.actualizar();
						vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
					}
				} 
			}else if(event.getSource().equals(this.vista.getBotonEliminarOpcion())){
				for(int i =0; i < pregunta.getOpciones().size(); i++){
					if(pregunta.getRespuestaProf() != null){
						if( pregunta.getOpciones().get(i).equals((Opcion)this.vista.getcomboBoxOpciones().getSelectedItem())){
						for(int j =0; i < pregunta.getOpciones().size(); j++){
							
								if(pregunta.getRespuestaProf().getOpciones().get(j).equals((Opcion)this.vista.getcomboBoxOpciones().getSelectedItem())){
								JOptionPane.showMessageDialog(this.vista, "Las soluciones no se borran aqui", "Error",
										JOptionPane.ERROR_MESSAGE);
								System.out.println("Deberia4");
								vista.actualizar();
								vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
								}
						//	}
						}
						}	
					}
					pregunta.getOpciones().remove(pregunta.getOpciones().get(i));
					vista.actualizar();
					vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
				}
		}else if (event.getSource().equals(this.vista.getBotonEliminarSolucion())){
			if(pregunta.getRespuestaProf() == null){
				JOptionPane.showMessageDialog(this.vista, "No existe solucion del Profesor, no puedes borrarla", "Error",
						JOptionPane.ERROR_MESSAGE);
				System.out.println("Deberia6");
				vista.actualizar();
				vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
				}
			
			for(int k =0; k < pregunta.getOpciones().size(); k++){
				if(pregunta.getOpciones().get(k).equals(pregunta.getRespuestaProf().getOpciones().get(0))){
					pregunta.getOpciones().remove(pregunta.getOpciones().get(k));
				}
			}
			pregunta.setRespuestaProf(null);
			System.out.println("Deberia111");
			vista.actualizar();
			vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
		}else{
			vista.actualizar();
			vistaEjer.mostrarVistaPreguntaBooleana(pregunta, vistaEjer);
		}
	}
}