package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;

import asignatura.Tema;
import panelesAlumno.*;
import panelesProfesor.VistaCrearEjercicio;
import panelesProfesor.VistaTemaProf;
import sistema.*;
import ventanas.*;

public class ControlVistaCrearEjercicio implements ActionListener{

	private VistaCrearEjercicio vista;
	private Sistema sistema;
	private VistaTemaProf vista_tema;
	private Tema tema;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCrearEjercicio(VistaCrearEjercicio vista, VistaTemaProf vista_tema, Tema tema){
		this.vista = vista;
		this.sistema = Sistema.getInstance();
		this.vista_tema = vista_tema;
		this.tema = tema;
		
	}
	

	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (event.getSource().equals(this.vista.getBotonCrearEjercicio())){
			if (this.vista.getNombre().getText().equals("") || this.vista.getPeso().getText().equals("")
					|| this.vista.getAnoIni().getText().equals("") || this.vista.getAnoFin().getText().equals("")
					|| this.vista.getMesIni().getText().equals("") || this.vista.getMesFin().getText().equals("")
					|| this.vista.getDiaIni().getText().equals("") || this.vista.getDiaFin().getText().equals("")
					|| this.vista.getHoraIni().getText().equals("") || this.vista.getHoraFin().getText().equals("")
					|| this.vista.getMinIni().getText().equals("") || this.vista.getMinFin().getText().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos los campos", "Error",
						JOptionPane.ERROR_MESSAGE);
				this.vista_tema.mostrarVistaTemaProf();
			} else {
				float peso = Float.parseFloat(this.vista.getAnoIni().getText());
				int anoIni = Integer.parseUnsignedInt(this.vista.getAnoIni().getText());
				int anoFin = Integer.parseUnsignedInt(this.vista.getAnoFin().getText());
				int mesIni = Integer.parseUnsignedInt(this.vista.getMesIni().getText());
				int mesFin = Integer.parseUnsignedInt(this.vista.getMesFin().getText());
				int diaIni = Integer.parseUnsignedInt(this.vista.getDiaIni().getText());
				int diaFin = Integer.parseUnsignedInt(this.vista.getDiaFin().getText());
				int horaIni = Integer.parseUnsignedInt(this.vista.getHoraIni().getText());
				int horaFin = Integer.parseUnsignedInt(this.vista.getHoraFin().getText());
				int minIni = Integer.parseUnsignedInt(this.vista.getMinIni().getText());
				int minFin = Integer.parseUnsignedInt(this.vista.getMinIni().getText());

				if (sistema.crearEjercicio(tema, this.vista.getNombre().getText(), peso, anoIni, mesIni, diaIni, horaIni, minIni,
						anoFin, mesFin, diaFin, horaFin, minFin, this.vista.getComboBoxSelectedVis(),
						this.vista.getComboBoxSelectedAleat()) == false) {
					JOptionPane.showMessageDialog(this.vista, "Error al crear el ejercicio", "Error",
							JOptionPane.ERROR_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(this.vista,
							"El ejercicio " + this.vista.getNombre() + " ha sido creado con exito",
							"CREACION DE EJERCICIO", JOptionPane.INFORMATION_MESSAGE);
					this.vista_tema.mostrarVistaTemaProf();
				}
			}
		}
	}
}
