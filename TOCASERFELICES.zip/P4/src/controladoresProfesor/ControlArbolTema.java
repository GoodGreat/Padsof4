package controladoresProfesor;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import ejercicio.Ejercicio;
import interfaces.NodoInterfaz;
import panelesAlumno.*;
import panelesProfesor.VistaTemaProf;


public class ControlArbolTema implements TreeSelectionListener{
	private VistaTemaProf vista_tema;
	
	public ControlArbolTema(VistaTemaProf vista_tema){
		this.vista_tema = vista_tema;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0
				|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent())
						.equals(this.vista_tema.getRaiz())) {
			// No hacer nada si se selecciona un nodo con al menos un hijo, o si
			// es la raiz
		} else {
			if (((DefaultMutableTreeNode) this.vista_tema.getArbol().getLastSelectedPathComponent()) != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_tema.getArbol()
						.getLastSelectedPathComponent()).getUserObject();
				if (nodo.getObjectClassName().equals("Tema")) {
					Tema subtema = (Tema) nodo;
					this.vista_tema.mostrarVistaSubtemaProf(subtema);
				} else if (nodo.getObjectClassName().equals("Ejercicio")) {
					Ejercicio ejercicio = (Ejercicio) nodo;
					this.vista_tema.mostrarVistaEjercicioProf(ejercicio);
				} else if (nodo.getObjectClassName().equals("Apunte")) {
					Apunte apunte = (Apunte) nodo;
					this.vista_tema.mostrarVistaApunteProf(apunte);
				}
			}
		}
	}
}
