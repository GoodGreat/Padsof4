package tester;

import java.util.*;

import asignatura.Tema;
import sistema.*;
import ventanas.*;

public class TesterGUI {
	
	
	public static void main(String args[]){
		
		/**
		 * CARGAR Y GUARDAR DATOS
		 */
		System.out.println("\nProbando --> Cargar y Guardar Datos <--\n");
		//Creamos dos sistemas
		Sistema sistema = Sistema.getInstance();
		List<Alumno> alumnosAntes = new ArrayList<Alumno>();
		boolean comprobacion = false;
		try{
			//En el primer sistema introducimos datos de alumnos
			sistema.leerDatosAlumno("src/alumnos.txt");
			//Guardamos el sistema en un archivo
			sistema.guardarDatosSistema("src/Sistema.obj");
			
			//Comprobamos que los alumnos se han cargado correctamente
			for (Alumno alumno: sistema.getAlumnos()){
				alumnosAntes.add(alumno);
			}
			
			//Cargamos el sistema anteriormente guardado en un nuevo Sistema
			sistema.cargarDatosSistema("src/Sistema.obj");
			
			//Comprobamos que en el nuevo Sistema, la informacion no se ha alterado
			for (int i = 0; i < sistema.getAlumnos().size(); i++){
				if (alumnosAntes.get(i).getNombre().equals(sistema.getAlumnos().get(i).getNombre())){
					comprobacion = true;
				}else{
					comprobacion = false;
				}
			}
			
			//Comprobar que cada alumno queda totalmente inalterado
			if (comprobacion == true){
				System.out.println("Los alumnos no se han alterado, este mensaje SI debe aparecer");
			}
			
		}catch (Exception e){
			System.err.println("Error");
		}
		
		Sistema.getInstance().log_in("ab", "a");
		sistema.crearAsignatura("PADSOF", true);
		sistema.crearAsignatura("ADSOF", true);
		sistema.crearTema(sistema.getAsignaturas().get(0), "tema 1", true);
		Tema subtema = new Tema("Subtema", true);
		sistema.crearEjercicio(sistema.getAsignaturas().get(0).getTemas().get(0), "EJ1", 10, 2017, 5, 3, 9, 0, 2017, 05, 10, 9, 0, true, false);
		sistema.getAsignaturas().get(0).getTemas().get(0).aniadirSubtema(subtema);
		Sistema.getInstance().log_out();
		sistema.log_in("1289", "JoA");
		sistema.crearSolicitud(sistema.getAsignaturas().get(0));
		sistema.crearSolicitud(sistema.getAsignaturas().get(1));
		sistema.log_out();
		new FramePrincipal();
	}
}
