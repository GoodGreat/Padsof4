package controladoresAlumno;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import asignatura.*;
import panelesAlumno.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaTemaProf;
import ventanas.*;

public class ControlVistaTemaAlum implements ActionListener{
		private Tema tema; 
		private VistaTemaAlum vista;
		private VistaAsignaturaAlum vista_asig;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param sistema. Clase principal de nuestro proyecto
		 */
		public ControlVistaTemaAlum(VistaTemaAlum vista, VistaAsignaturaAlum vista_asig, Tema tema){
			this.vista = vista;
			this.vista_asig = vista_asig;
			this.tema = tema;	
		}
		
		
		@Override
		public void actionPerformed(ActionEvent event) {
		if(event.getSource().equals(this.vista.getBotonVolver())){
				this.vista_asig.mostrarVistaAsignaturaAlum();
			}
			
		}
	}