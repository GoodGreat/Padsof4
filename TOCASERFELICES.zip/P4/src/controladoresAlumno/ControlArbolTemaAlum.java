package controladoresAlumno;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.*;
import interfaces.NodoInterfaz;
import panelesAlumno.VistaAsignaturaAlum;
import panelesAlumno.VistaTemaAlum;
import panelesProfesor.VistaAsignaturaProf;


public class ControlArbolTemaAlum implements TreeSelectionListener{
	private DefaultMutableTreeNode nodo;
	private VistaTemaAlum vista_tema;
	
	public ControlArbolTemaAlum(VistaTemaAlum vista_temaAlum){
		this.vista_tema = vista_tema;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).equals(this.vista_tema.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
			}else{
			NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_tema.getArbol().getLastSelectedPathComponent()).getUserObject();
			
			if (nodo.getObjectClassName().equals("Tema")) {
				//Tema tema = (Tema)nodo;
				//this.vista_tema.mostrarVistaTemaAlum(tema);
			} else if(nodo.getObjectClassName().equals("Ejercicio")) {
				//Ejercicio ejercicio = (Ejercicio)nodo;
				//this.vista_tema.mostrarVistaEjercicioAlum(ejercicio);
			} else if(nodo.getObjectClassName().equals("Apunte")) {
			//	Apunte apunte = (Apunte)nodo;
				//this.vista_tema.mostrarVistaApunteAlum(apunte);
			} 
			
		}		
	}

}
