package controladoresAlumno;

import java.awt.event.*;

import javax.swing.JOptionPane;

import sistema.*;
import asignatura.*;
import panelesAlumno.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaPrincipalProf;
import ventanas.*;

public class ControlVistaAsignaturaAlum implements ActionListener{
		private Asignatura asignatura; 
		private VistaAsignaturaAlum vista;
		private VistaMostrarAsignaturas vista_mostrarAsigs;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_prof. Panel de la vista principal del profe
		 */
		public ControlVistaAsignaturaAlum(VistaAsignaturaAlum vista, VistaMostrarAsignaturas vista_mostrarAsigs, Asignatura asignatura){
			this.vista = vista;
			this.vista_mostrarAsigs = vista_mostrarAsigs;
			this.asignatura = asignatura;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			if(event.getSource().equals(this.vista.getBotonVolver())){
			//	this.vista_mostrarAsigs.mostrarVistaAsignaturas();
			}
		}
	}