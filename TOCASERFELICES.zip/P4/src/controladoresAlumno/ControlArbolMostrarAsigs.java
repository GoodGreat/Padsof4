package controladoresAlumno;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import asignatura.Asignatura;
import asignatura.Tema;
import interfaces.NodoInterfaz;
import panelesAlumno.VistaMostrarAsignaturas;

public class ControlArbolMostrarAsigs implements TreeSelectionListener{
	private DefaultMutableTreeNode nodo;
	private VistaMostrarAsignaturas vista_mostrarAsigs;
	
	public ControlArbolMostrarAsigs(VistaMostrarAsignaturas vista_mostrarAsigs){
		this.vista_mostrarAsigs = vista_mostrarAsigs;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0
				|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent())
						.equals(this.vista_mostrarAsigs.getRaiz())) {
			// No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if (((DefaultMutableTreeNode) this.vista_mostrarAsigs.getArbol().getLastSelectedPathComponent()) != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_mostrarAsigs.getArbol()
						.getLastSelectedPathComponent()).getUserObject();
				if (nodo.getObjectClassName().equals("Asignatura")) {
					Asignatura asignatura = (Asignatura) nodo;
					this.vista_mostrarAsigs.mostrarVistaAsignaturaAlum(asignatura);
				}
			}
		}
	}
}
