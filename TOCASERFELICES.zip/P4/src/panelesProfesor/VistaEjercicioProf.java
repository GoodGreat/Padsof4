package panelesProfesor;

import java.awt.CardLayout;
import java.awt.Dimension;
import java.awt.event.ActionListener;

import javax.swing.*;

import controladoresProfesor.ControlArbolTema;
import controladoresProfesor.ControlVistaCambiarEjercicio;
import controladoresProfesor.ControlVistaCrearPreguntaBooleana;
import ejercicio.*;
import sistema.Sistema;

public class VistaEjercicioProf extends JPanel{

	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista de ejercicio del Profesor";
	final static String CAMBIAR_EJERCICIO = "Carta con la vista de cambio ejercicio del Profesor";
	private JLabel etiquetaNombre;
	private JLabel etiquetaFechaIni;
	private JLabel etiquetaFechaFin;
	private JButton botonCambiarEjercicio, botonVolver, botonIr;
	private JPanel principal_ejercicio;
	private Ejercicio ejercicio;
	private Sistema sistema;
	private JLabel etiquetaPregunta;
	private JComboBox<Pregunta> comboBoxPregunta;
	private JComboBox<String> comboBoxVisible;
	
	
	public VistaEjercicioProf(Ejercicio ejercicio){
		this.ejercicio = ejercicio;
		this.setLayout(new CardLayout());
		
		this.principal_ejercicio = new JPanel();
		SpringLayout layout = new SpringLayout();
		this.principal_ejercicio.setLayout(layout);

		etiquetaNombre = new JLabel(ejercicio.getNombre());
		this.principal_ejercicio.add(etiquetaNombre);
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 10, SpringLayout.NORTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, 0, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
	
	 	etiquetaFechaIni = new JLabel("Fecha de inicio: " + ejercicio.getFechaIni().getTime());
	 	this.principal_ejercicio.add(etiquetaFechaIni);
		layout.putConstraint(SpringLayout.NORTH, etiquetaFechaIni, 10, SpringLayout.SOUTH, etiquetaNombre);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaFechaIni, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaNombre);
		
		
		etiquetaFechaFin = new JLabel("Fecha de final: " + ejercicio.getFechaFin().getTime());
		this.principal_ejercicio.add(etiquetaFechaFin);
		layout.putConstraint(SpringLayout.NORTH, etiquetaFechaFin, 10, SpringLayout.SOUTH, etiquetaFechaIni);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaFechaFin, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaFechaIni);
			
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 40));
		this.principal_ejercicio.add(botonVolver);
		
		layout.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 20, SpringLayout.NORTH, this.principal_ejercicio);
		
	   	botonCambiarEjercicio = new JButton("Cambiar Ejercicio");
		botonCambiarEjercicio.setPreferredSize(new Dimension(150,75));
		this.principal_ejercicio.add(botonCambiarEjercicio);
		
		layout.putConstraint(SpringLayout.SOUTH, botonCambiarEjercicio, -5, SpringLayout.SOUTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonCambiarEjercicio, -75, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
		

	   	botonIr = new JButton("Ir");
		botonIr.setPreferredSize(new Dimension(150,75));
		this.principal_ejercicio.add(botonIr);
		
		layout.putConstraint(SpringLayout.SOUTH, botonIr, -5, SpringLayout.SOUTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonIr, 75, SpringLayout.HORIZONTAL_CENTER, this.principal_ejercicio);
		
		//barajeamos las preguntas para que salgan en un orden aleatorio, distinto al introducido por el profesor
		if(ejercicio.getAleatorio() == true){
			ejercicio.barajarPreguntas();
		}
		
		sistema = Sistema.getInstance();
		
		Pregunta[] opciones = new Pregunta[ejercicio.getPreguntas().size()];
		
		int i =0;
		
		for(i=0; i < ejercicio.getPreguntas().size(); i++){
			{
					opciones[i] = ejercicio.getPreguntas().get(i);
			}
		}
		
		etiquetaPregunta = new JLabel("Seleccione pregunta ");
		this.principal_ejercicio.add(etiquetaPregunta);
		comboBoxPregunta = new JComboBox<Pregunta>(opciones);
		this.principal_ejercicio.add(comboBoxPregunta);
		
		
		//Constraints
		layout.putConstraint(SpringLayout.NORTH, etiquetaPregunta, 200, SpringLayout.NORTH, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.EAST, etiquetaPregunta, -400, SpringLayout.EAST, this.principal_ejercicio);		
		layout.putConstraint(SpringLayout.EAST, comboBoxPregunta, -300, SpringLayout.EAST, this.principal_ejercicio);
		layout.putConstraint(SpringLayout.NORTH, comboBoxPregunta, 200, SpringLayout.NORTH, this.principal_ejercicio);
		
		this.principal_ejercicio.setPreferredSize(new Dimension(800,350));
		this.add(this.principal_ejercicio, PRINCIPAL);
	}
	
	
	public void actualizar(){
		this.etiquetaNombre.setText(ejercicio.getNombre());
		this.etiquetaFechaFin.setText("Fecha de final: " + ejercicio.getFechaFin().getTime());
		this.etiquetaFechaIni.setText("Fecha de inicio: " + ejercicio.getFechaIni().getTime());
		
sistema = Sistema.getInstance();
		
		Pregunta[] opciones = new Pregunta[ejercicio.getPreguntas().size()];
		
		int i =0;
		
		for(i=0; i < ejercicio.getPreguntas().size(); i++){
			{
					opciones[i] = ejercicio.getPreguntas().get(i);
			}
		}
		
		etiquetaPregunta = new JLabel("Seleccione pregunta ");
		this.principal_ejercicio.add(etiquetaPregunta);
		comboBoxPregunta = new JComboBox<Pregunta>(opciones);
		this.principal_ejercicio.add(comboBoxPregunta);
		
	}

	/**
	 * Getter del Boton Cambiar Ejercicio
	 * @author Alejandro Martin Climent
	 * @return JButton
	 */
	public JButton getBotonCambiarEjercicio() {
		return botonCambiarEjercicio;
	}
	
	/**
	 * Getter del Boton Volver
	 * @author Alejandro Martin Climent
	 * @return JButton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
	
	/**
	 * Getter del Boton Volver
	 * @author Alejandro Martin Climent
	 * @return JButton
	 */
	public JButton getBotonIr() {
		return botonIr;
	}
	

	/**
	 * Metodo que sirve para retornar el texto contenido en la ComboBox
	 * @author Alvaro Martinez de Navascues
	 * @return String. La password del alumno/profesor
	 */
	public Pregunta getComboBoxPregunta(){
		return (Pregunta) comboBoxPregunta.getSelectedItem();
	}
	
	/**
	 * Metodo que muestra la vista principal de esta clase
	 * @author �lvaro MArtinez de Navascues
	 */
	public void mostrarVistaPrincipal(){
		actualizar();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Metodo que muestra la vista principal de esta clase
	 * @author Alejandro Martin Climent
	 */
	public void mostrarVistaCambiarEjercicio(){
		VistaCambiarEjercicio vista_cambioEj = new VistaCambiarEjercicio();
		ControlVistaCambiarEjercicio control_cambioEj = new ControlVistaCambiarEjercicio(vista_cambioEj, this, this.ejercicio);
		vista_cambioEj.setControlador(control_cambioEj);
		this.add(vista_cambioEj, CAMBIAR_EJERCICIO);
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CAMBIAR_EJERCICIO);
	}
	
	/**
	 * Metodo que muestra la vista principal de esta clase
	 * @author �lvaro MArtinez de Navascues
	 */
	public void mostrarVistaPregunta(Pregunta pregunta){
		actualizar();
		//VistaMostrarPregunta vista_mostrarPreg = new VistaMostrarPregunta();
	//	ControlVistaMostrarPregunta control_mostrarPreg= new ControlVistaMostrarPregunta(vista_mostrarPreg, this, pregunta);
	//	vista_mostrarPreg.setControlador(control_mostrarPreg);
	//	this.add(vista_mostrarPreg, PANEL_PREGUNTA);
		
		CardLayout cl = (CardLayout)(this.getLayout());
	//	cl.show(this, PANEL_PREGUNTA);
	}
	
	/**
	 * Metodo que asigna el controlador a los botones de esta vista
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador de los botones
	 */
	public void setControlador(ActionListener controlador){
		this.botonCambiarEjercicio.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}
}
