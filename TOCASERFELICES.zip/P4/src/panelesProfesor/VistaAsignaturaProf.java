package panelesProfesor;

import java.awt.*;
import java.awt.event.ActionListener;

import javax.swing.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import asignatura.*;
import controladoresAlumno.*;
import controladoresProfesor.ControlArbolAsignatura;
import controladoresProfesor.ControlArbolTema;
import controladoresProfesor.ControlVistaCambiarAsignatura;
import controladoresProfesor.ControlVistaCrearTema;
import controladoresProfesor.ControlVistaTemaProf;
import ejercicio.Ejercicio;
import panelesAlumno.*;
import sistema.Sistema;

public class VistaAsignaturaProf extends JPanel{
	
	private static final long serialVersionUID = 1L;
	
	final static String PRINCIPAL = "Carta con la vista principal de Asignatura (del Profesor)";
	final static String PROF_TEMAPANEL = "Carta con la vista de asignatura del Profesor";
	final static String CREARTEMA = "Carta con la vista de crear tema";
	final static String CAMBIARASIGNATURA = "Carta con la vista de cambiar Asignatura";
	final static String PROF_GESTIONALUMS = "Carta con la vista de gestion de alumnos";
	final static String CALCULARNOTA = "Carta con la vista principal Profesor";
	private Asignatura asignatura;
	private JLabel etiquetaNombre;
	private JButton botonGestionAlum ;
	private JButton botonCambiarAsig;
	private JButton botonCalcularNota;
	private JButton botonCrearTema;
	private JButton botonVolver;
	private JPanel principal_asignatura;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private JTree arbol;
	
	public VistaAsignaturaProf(Asignatura asignatura){
		
		CardLayout card_layout = new CardLayout();
		this.setLayout(card_layout);
		
		this.asignatura = asignatura;
		SpringLayout layout = new SpringLayout();
		
		principal_asignatura = new JPanel();
		principal_asignatura.setLayout(layout);
		
		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
				
		//Panel de botones 
		JPanel panel_botones = new JPanel();
				
		//Panel del arbol de contenido 
		JPanel panel_arbol = new JPanel();
		
		principal_asignatura.setLayout(new BorderLayout());
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel(asignatura.getNombre());
		panel_etiquetas.add(etiquetaNombre);
		
		botonCrearTema = new JButton("Crear Tema");
		botonCrearTema.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCrearTema);
		
		botonGestionAlum = new JButton("Gesti�n Alumnos");
		botonGestionAlum.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonGestionAlum);
		
		botonCambiarAsig =  new JButton("Cambiar Asignatura");
		botonCambiarAsig.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCambiarAsig);
		
		botonCalcularNota = new JButton("Calcular Nota");
		botonCalcularNota.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCalcularNota);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonVolver);
		
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		//Ponemos la derecha del botonCrearTema a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCrearTema, 5, SpringLayout.WEST, this);	
		//Ponemos el norte del botonGestionAlum a 5 pixeles al sur del botonCrearTema
		layout.putConstraint(SpringLayout.NORTH, botonGestionAlum, 5, SpringLayout.SOUTH, botonCrearTema);	
		//Ponemos el norte del botonCambiarAsig a 5 pixeles de la sur del botonGestionAlum
		layout.putConstraint(SpringLayout.NORTH, botonCambiarAsig, 5, SpringLayout.SOUTH, botonGestionAlum);
		//Ponemos el norte del botonCalcularNota a 5 pixeles de la sur del botonCambiarAsig
		layout.putConstraint(SpringLayout.NORTH, botonCalcularNota, 5, SpringLayout.SOUTH, botonCambiarAsig);
		//Ponemos el norte del botonCalcularNota a 5 pixeles de la sur del botonCambiarAsig
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 5, SpringLayout.SOUTH, botonCalcularNota);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode(asignatura.getNombre());
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		arbol = new JTree (modelo);
				
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(300, 200));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);		
		
		for(Tema temaAux: asignatura.getTemas()){
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			//construirArbol(temaAux, nodo_tema);
			i++;
		}
		
		panel_arbol.add(arbol);

		//Constraints
		
		this.setPreferredSize(new Dimension(450, 150));
		this.principal_asignatura.add(panel_etiquetas, BorderLayout.NORTH);
		this.principal_asignatura.add(panel_botones, BorderLayout.SOUTH);
		this.principal_asignatura.add(panel_arbol, BorderLayout.EAST);
		
		
		this.add(principal_asignatura, PRINCIPAL);

		VistaCrearTema vista_crearTema = new VistaCrearTema();
		ControlVistaCrearTema control_crearTema = new ControlVistaCrearTema(vista_crearTema, this, this.asignatura);
		vista_crearTema.setControlador(control_crearTema);
		this.add(vista_crearTema, CREARTEMA);
		
	
		VistaCambiarAsignatura vista_cambiarAsig = new VistaCambiarAsignatura();
		ControlVistaCambiarAsignatura control_cambiarAsig = new ControlVistaCambiarAsignatura(vista_cambiarAsig, this, this.asignatura);
		vista_cambiarAsig.setControlador(control_cambiarAsig);
		this.add(vista_cambiarAsig, CAMBIARASIGNATURA);
		
		/*VistaGestionAlumnos vista_gestionAlum = new VistaGestionAlumnos();
		ControlGestionAlumnos control_gestionAlum = new ControlGestionAlumnos(vista_gestionAlum, this, this.asignatura);
		vista_cambiarAsig.setControlador(control_gestionAlum);
		this.add(vista_gestionAlum, PROF_GESTIONALUMS);
		*/
		
	}
	
	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * @author �lvaro Martinez de Navascues
	 */
	private void actualizarArbol(){
		
		//Borrar el arbol
		for (int i = 0; i < raiz.getChildCount(); i++){
			DefaultMutableTreeNode treeNodeAux = (DefaultMutableTreeNode) raiz.getChildAt(i);
			modelo.removeNodeFromParent(treeNodeAux);
		}
		
		int i = 0;
		
		//Construir el arbol actualizado
		for(Tema temaAux: this.asignatura.getTemas()){
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			//construirArbol(temaAux, nodo_tema);
			i++;
		}
	}
	
	/**
	 * Metodo que sirve para actualizar el estado del arbol de asignaturas
	 * @author �lvaro Martinez de Navascues
	 */
	private void actualizar(){
		this.etiquetaNombre.setText(asignatura.getNombre());
	}
	
	/**
	 * Metodo que construye el arbol estructurado de la Aplicacion, empezando en Asignaturas
	 * @author Alejandro Martin Climent
	 * @param tema. Tema a partir del cual se construyen las ramas del arbol
	 * @param nodo. Nodo raiz de la rama
	 */
	/*private void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		//Aniadimos Ejercicios
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
			if(ejercicioAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(ejercicioAux), nodo, i);
				i++;
			}
		}
		
		//Aniadimos Apuntes
		for(Apunte apunteAux: tema.getApuntes()){
			if(apunteAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(apunteAux), nodo, i);
				i++;
			}
		}
		
		//Aniadimos Subtemas
		for(Tema temaAux: tema.getSubtemas()){
			if(temaAux.getVisible() == true){
				DefaultMutableTreeNode nodo_subtema = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_subtema, nodo, i);
				i++;
				construirArbol(temaAux, nodo_subtema);
			}
		}		
	}
	*/
	
	 /**
		 * Getter del boton "CrearAsignatura"
		 * @author Alejandro Martin Climent
		 * @return JButton.
		 */
	    public JButton getBotonCrearTema() {
			return botonCrearTema;
		}
	    /**
		 * Getter del boton "CrearAsignatura"
		 * @author Alejandro Martin Climent
		 * @return JButton.
		 */
	    public JButton getBotonCambiarAsig() {
			return botonCambiarAsig;
		}
	    /**
		 * Getter del boton "CrearAsignatura"
		 * @author Alejandro Martin Climent
		 * @return JButton.
		 */
	    public JButton getBotonGestionAlum() {
			return botonGestionAlum;
		}
	    
	    /**
		 * Getter del boton "CrearAsignatura"
		 * @author Alejandro Martin Climent
		 * @return JButton.
		 */
	    public JButton getBotonCalcularNotaAlum() {
			return botonCalcularNota;
		}
	    
	    /**
		 * Getter del boton "CrearAsignatura"
		 * @author Alejandro Martin Climent
		 * @return JButton.
		 */
	    public JButton getBotonVolver() {
			return botonVolver;
		}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Login
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador, ControlArbolAsignatura control_arbol){
		this.botonCrearTema.addActionListener(controlador);
		this.botonGestionAlum.addActionListener(controlador);
		this.botonCambiarAsig.addActionListener(controlador);
		this.botonCalcularNota.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
		
		//Controlador del arbol
	 	arbol.addTreeSelectionListener(control_arbol);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaPrincipalProf(){
		this.actualizarArbol();
		this.actualizar();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PRINCIPAL);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCrearTema(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CREARTEMA);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCambiarAsignatura(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CAMBIARASIGNATURA);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCalcularNotaAlum(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CALCULARNOTA);
	}

	public DefaultMutableTreeNode getRaiz() {
		return raiz;
	}

	public JTree getArbol() {
		return arbol;
	}

	public void mostrarVistaTema(Tema tema) {
		VistaTemaProf vista_temaProf = new VistaTemaProf(tema);
		ControlVistaTemaProf control_tema = new ControlVistaTemaProf(vista_temaProf, this, tema);
		ControlArbolTema control_arbol = new ControlArbolTema(vista_temaProf);
		vista_temaProf.setControlador(control_tema, control_arbol);
		this.add(vista_temaProf, PROF_TEMAPANEL);
		
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PROF_TEMAPANEL);	
	}
}
