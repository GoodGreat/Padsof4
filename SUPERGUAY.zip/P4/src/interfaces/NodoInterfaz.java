package interfaces;

public interface NodoInterfaz {
	
	/**
	 * Metodo que devuelve la clas del objeto
	 * @author �lvaro Martinez de Navascues
	 * @return La clase del objeto
	 */
	public String getObjectClassName();
	
	public String toString();	
}
