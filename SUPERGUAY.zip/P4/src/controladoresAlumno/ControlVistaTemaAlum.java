package controladoresAlumno;

import java.awt.event.*;

import panelesAlumno.*;
import sistema.Sistema;

public class ControlVistaTemaAlum implements ActionListener{
	private VistaTemaAlum vista;
	private VistaAsignaturaAlum vista_asig;

	/**
	 * Constructor del controlador de la Vista Tema Alum
	 * 
	 * @author Alejandro Martin
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaTemaAlum(VistaTemaAlum vista, VistaAsignaturaAlum vista_asig) {
		this.vista = vista;
		this.vista_asig = vista_asig;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())) {
			System.out.println(Sistema.getInstance().getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0).getPreguntas().get(0).getRespuestas().get(0).getAlumno().getNombre());
			this.vista_asig.mostrarVistaAsignaturaAlum();
		}
	}
}