package controladoresAlumno;

import java.awt.event.*;

import javax.swing.JOptionPane;

import asignatura.*;
import panelesAlumno.*;
import sistema.Sistema;

public class ControlVistaAsignaturaAlum implements ActionListener{
		private Asignatura asignatura; 
		private VistaAsignaturaAlum vista;
		private VistaMostrarAsignaturas vista_mostrarAsigs;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_prof. Panel de la vista principal del profe
		 */
		public ControlVistaAsignaturaAlum(VistaAsignaturaAlum vista, VistaMostrarAsignaturas vista_mostrarAsigs, Asignatura asignatura){
			this.vista = vista;
			this.vista_mostrarAsigs = vista_mostrarAsigs;
			this.asignatura = asignatura;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			if(event.getSource().equals(this.vista.getBotonVolver())){
				this.vista_mostrarAsigs.mostrarVistaAsignaturasMat();
			}else if (event.getSource().equals(this.vista.getBotonCalcularNota())){
				//Calcular Nota de esta Asignatura
				JOptionPane.showMessageDialog(this.vista, "Tu nota en la asignatura " + 
				asignatura.getNombre() + " es " + Sistema.getInstance().consultarCalificacionesPropias(asignatura)
				, "CALIFICACION DEL ALUMNO", JOptionPane.INFORMATION_MESSAGE);
			}
		}
	}