package tester;

import java.util.*;

import asignatura.*;
import ejercicio.Opcion;
import ejercicio.Respuesta;
import ejercicio.RespuestaBooleana;
import sistema.*;
import ventanas.*;

public class TesterGUI {
	
	
	public static void main(String args[]){
		
		/**
		 * CARGAR Y GUARDAR DATOS
		 */
		System.out.println("\nProbando --> Cargar y Guardar Datos <--\n");
		//Creamos dos sistemas
		Sistema sistema = Sistema.getInstance();
		List<Alumno> alumnosAntes = new ArrayList<Alumno>();
		boolean comprobacion = false;
		try{
			//En el primer sistema introducimos datos de alumnos
			sistema.leerDatosAlumno("src/alumnos.txt");
			//Guardamos el sistema en un archivo
			sistema.guardarDatosSistema("src/Sistema.obj");
			
			//Comprobamos que los alumnos se han cargado correctamente
			for (Alumno alumno: sistema.getAlumnos()){
				alumnosAntes.add(alumno);
			}
			
			//Cargamos el sistema anteriormente guardado en un nuevo Sistema
			sistema.cargarDatosSistema("src/Sistema.obj");
			
			//Comprobamos que en el nuevo Sistema, la informacion no se ha alterado
			for (int i = 0; i < sistema.getAlumnos().size(); i++){
				if (alumnosAntes.get(i).getNombre().equals(sistema.getAlumnos().get(i).getNombre())){
					comprobacion = true;
				}else{
					comprobacion = false;
				}
			}
			
			//Comprobar que cada alumno queda totalmente inalterado
			if (comprobacion == true){
				System.out.println("Los alumnos no se han alterado, este mensaje SI debe aparecer");
			}
			
		}catch (Exception e){
			System.err.println("Error");
		}
		
		Sistema.getInstance().log_in("ab", "a");
		sistema.crearAsignatura("PADSOF", true);
		sistema.crearAsignatura("ADSOF", true);
		sistema.crearTema(sistema.getAsignaturas().get(0), "tema 1", true);
		sistema.crearApunte(sistema.getAsignaturas().get(0).getTemas().get(0), "Apunte Tema 1", true, "Las nuevas tendencias....etc");
		Tema subtema = new Tema("Subtema", true);
		
		sistema.crearEjercicio(sistema.getAsignaturas().get(0).getTemas().get(0), "EJ1", 10, 2017, 3, 3, 9, 0, 2017, 10, 10, 9, 0, true, false);
		sistema.crearPregunta(sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0), "enunciadob", 1, true, 1, "Booleana");
		/*sistema.crearPregunta(sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0), "enunciadou", 1, true, 1, "Unica");
		sistema.crearPregunta(sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0), "enunciadom", 1, true, 1, "Multipregunta");
		sistema.crearPregunta(sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0), "enunciadol", 1, true, 1, "Libre");*/
		List<Opcion> opciones = new ArrayList<Opcion>();
		Opcion opcion = new Opcion("a");
		Opcion opcion2 = new Opcion("b");
		
		opciones.add(opcion);
		opciones.add(opcion2);
		Respuesta respuestaProf = new RespuestaBooleana(null);
		respuestaProf.resAniadirOpcion(opcion2);
		sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0).getPreguntas().get(0).pregAniadirOpcion(opcion);
		sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0).getPreguntas().get(0).pregAniadirOpcion(opcion2);
		sistema.getAsignaturas().get(0).getTemas().get(0).getEjercicios().get(0).getPreguntas().get(0).setRespuestaProf(respuestaProf);
		sistema.getAsignaturas().get(0).getTemas().get(0).aniadirSubtema(subtema);
		Sistema.getInstance().log_out();
		sistema.log_in("1289", "JoA");
		sistema.crearSolicitud(sistema.getAsignaturas().get(0));
		sistema.crearSolicitud(sistema.getAsignaturas().get(1));
		sistema.log_out();
		Sistema.getInstance().log_in("ab", "a");
		sistema.aceptarSolicitud(sistema.getSolicitudes().get(0));
		sistema.log_out();
		new FramePrincipal();
	}
}
