package ventanas;

import java.awt.*;
import javax.swing.*;
import asignatura.Asignatura;
import asignatura.Tema;
import controladores.*;
import ejercicio.Ejercicio;
import paneles.*;

public class FramePrincipal extends JFrame {
	private static final long serialVersionUID = 1L;
	final static String LOGINPANEL = "Carta con el LOGIN";
	final static String PROF_PRINCIPANEL = "Carta con la vista del menu del Profesor";
	final static String ESTUD_PRINCIPANEL = "Carta con la vista del menu Alumno";
	final static String PROF_ASIGPANEL = "Carta con la vista de asignatura del Profesor";
	final static String ESTUD_ASIGPANEL = "Carta con la vista de asignatura del Alumno";
	final static String PROF_TEMAPANEL = "Carta con la vista de tema del Profesor";
	final static String ESTUD_TEMAPANEL = "Carta con la vista de tema del Alumno";
	final static String PROF_EJERPANEL = "Carta con la vista de un ejercicio del Profesor";
	final static String ESTUD_EJERPANEL = "Carta con la vista de un ejercicio del Alumno";
	final static String PROF_APUNTEPANEL = "Carta con la vista de un apuntedel Profesor";
	final static String ESTUD_APUNTEPANEL = "Carta con la vista de un apunte del Alumno";
	private Asignatura asignatura;
	private Tema tema;
	private Ejercicio ejercicio;
	/**
	 * Constructor de la vista LOGIN
	 */
	public FramePrincipal (){
		super("E-DUUDLE");
		super.setFont(new Font(Font.SERIF, Font.BOLD, 13));
		//Layout de Card
		
		Container container = this.getContentPane();
		container.setLayout(new CardLayout());
		
		asignatura = new Asignatura("PADSOF", true);
		tema = new Tema("Tema1", true);
		ejercicio = new Ejercicio("Ejercicio1", 0.5f, 2000, 3, 10, 12, 0, 2017, 10, 11, 12, 0, true, false);
		
		//VistaLogin vista_login = new VistaLogin();
		//VistaPrincipalProf vista_princiProf = new VistaPrincipalProf();
		//VistaPrincipalAlum vista_princiAlum = new VistaPrincipalAlum();
		//VistaAsignaturaProf vista_asigProf = new VistaAsignaturaProf(asignatura);
		//VistaAsignaturaAlum vista_asigAlum = new VistaAsignaturaAlum(asignatura);
		//VistaTemaProf vista_temaProf = new VistaTemaProf(tema);
		//VistaTemaAlum vista_temaAlum = new VistaTemaAlum(tema);
		VistaEjercicioProf vista_ejercicioProf = new VistaEjercicioProf(ejercicio);
		//VistEjercicioAlum vista_ejercicioAlum = new VistaEjercicioAlum();
		//VistaApunteProf vista_apunteProf = new VistaApunteProf();
		//VistaApunteAlum vista_apunteAlum = new VistaApunteAlum();

		//ControlVistaLogin controlador = new ControlVistaLogin(vista_login, this);
		//ControlVistaPrincipalProf controlador = new ControlVistaPrincipalProf(vista_princiProf, this);
		//ControlVistaPrincipalAlum controlador = new ControlVistaPrincipalAlum(vista_princiAlum, this);
		//ControlVistaAsignaturaProf controlador = new ControlVistaAsignaturaProf(vista_asigProf, asignatura, this);
		//ControlVistaAsignaturaAlum controlador = new ControlVistaAsignaturalAlum(vista_asigAlum, this);
		//ControlVistaTemaProf controlador = new ControlVistaTemaProf(vista_temaProf, this);
		//ControlVistaTemaAlum controlador = new ControlVistaTemaAlum(vista_temaAlum, this);
		//ControlVistaEjercicioProf controlador = new ControlVistaEjercicioProf(vista_ejercicioProf, this);
		//ControlVistaEjercicioAlum controlador = new ControlVistaEjercicioAlum(vista_ejercicioAlum, this);
		//ControlVistaApunteProf controlador = new ControlVistaApunteProf(vista_apunteProf, this);
		//ControlVistaAPunteAlum controlador = new ControlVistaApunteAlum(vista_apunteAlum, this);
		
		//vista_login.setControlador(controlador);
		//vista_princiProf.setControlador(controlador);
		//vista_princiAlum.setControlador(controlador);
		//vista_asigProf.setControlador(controlador);
		//vista_asigAlum.setControlador(controlador);
		//vista_temaProf.setControlador(controlador);
		//vista_temaAlum.setControlador(controlador);
		//vista_ejercicioProf.setControlador(controlador);
		//vista_ejercicioAlum.setControlador(controlador);
		
		//Aniadimos los componentes al container
		//container.add(vista_login, LOGINPANEL);
		//container.add(vista_princiProf, PROF_PRINCIPANEL);
		//container.add(vista_princiAlum, ESTUD_PRINCIPANEL);
		//container.add(vista_asigProf, PROF_ASIGPANEL);
		//container.add(vista_asigAlum, ESTUD_ASIGPANEL);
		//container.add(vista_temaProf, PROF_TEMAPANEL);
		//container.add(vista_temaAlum, ESTUD_TEMAPANEL);
		//container.add(vista_temaProf, PROF_TEMAPANEL);
		container.add(vista_ejercicioProf, PROF_EJERPANEL);
	
		
		//Colocar los componentes de acuerdo a sus tama�os
		this.setPreferredSize(new Dimension(800, 350));
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void mostrarLogin(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), LOGINPANEL);
	}
	
	public void mostrarVistaPrinciProf(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), PROF_PRINCIPANEL);
	}
	
	public void mostrarVistaPrinciEstudiante(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), ESTUD_PRINCIPANEL);
	}
	
	public void mostrarVistaAsignaturaProfesor(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), PROF_ASIGPANEL);
	}
	
	public void mostrarVistaAsignaturaEstudiante(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), ESTUD_ASIGPANEL);
	}
	
	public void mostrarVistaTemaProfesor(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), PROF_TEMAPANEL);
	}
	
	public void mostrarVistaTemaEstudiante(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), ESTUD_TEMAPANEL);
	}
}
