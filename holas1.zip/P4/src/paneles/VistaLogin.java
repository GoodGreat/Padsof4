package paneles;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import layout.*;

public class VistaLogin extends JPanel{
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNia, etiquetaPassword;
	private JTextField textNia, textPassword;
	private JButton botonLogin;
	
	/**
	 * Constructor del panel de Datos, con Spring Layout y Spring Utilities
	 * @author Alvaro Martinez de Navascues
	 */
	public VistaLogin(){
		SpringLayout layout = new SpringLayout();
		
		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
		panel_etiquetas.setLayout(layout);
		
		//Panel de botones
		JPanel panel_botones = new JPanel();
		
		
		//Layout del JPanel principal
		this.setLayout(new BorderLayout());	
		
		//Creamos nuestros componentes
		etiquetaNia = new JLabel("NIA: ", JLabel.TRAILING);
		panel_etiquetas.add(etiquetaNia);
		textNia = new JTextField(10);
		etiquetaNia.setLabelFor(textNia);
		panel_etiquetas.add(textNia);
		
		etiquetaPassword = new JLabel ("PASSWORD: ", JLabel.TRAILING);
		panel_etiquetas.add(etiquetaPassword);
		textPassword = new JTextField(10);
		etiquetaPassword.setLabelFor(textPassword);
		panel_etiquetas.add(textPassword);
		
		botonLogin = new JButton("LOG-IN");
		botonLogin.setPreferredSize(new Dimension(100,50));
		panel_botones.add(botonLogin);
		
		SpringUtilities.makeCompactGrid(panel_etiquetas, 2, 2, 6, 6, 6, 6);
		panel_etiquetas.setPreferredSize(new Dimension(100, 50));
		this.setPreferredSize(new Dimension(400, 150));
		this.add(panel_etiquetas, BorderLayout.CENTER);
		this.add(panel_botones, BorderLayout.SOUTH);
	} 
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public String getNia(){
		return this.textNia.getText();
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en la PASSWORD
	 * @author Alvaro Martinez de Navascues
	 * @return String. La password del alumno/profesor
	 */
	public String getPassword(){
		return this.textPassword.getText();
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Login
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador){
		this.botonLogin.addActionListener(controlador);
	}
}
