package paneles;

import javax.swing.*;
import asignatura.*;

public class VistaApunteAlum extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JLabel etiquetaTexto;
	
	public VistaApunteAlum(Apunte apunte){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		etiquetaNombre = new JLabel(apunte.getTitulo());
		etiquetaTexto = new JLabel(apunte.getContenido());
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//Ponemos el norte de la etiquetaTexto distanciada a 5 del norte de la etiquetaNombre
		layout.putConstraint(SpringLayout.NORTH, etiquetaTexto, 5, SpringLayout.NORTH, etiquetaNombre);
	
		
	}
	
}
