package paneles;

import java.awt.BorderLayout;
import java.awt.Dimension;

import javax.swing.*;
import ejercicio.*;
import layout.SpringUtilities;

public class VistaEjercicioProf extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JLabel etiquetaFechaIni;
	private JLabel etiquetaFechaFin;
	private JButton botonCambiarEjercicio;
	
	
	public VistaEjercicioProf(Ejercicio ejercicio){
		SpringLayout layout = new SpringLayout();
		
		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
		//panel_etiquetas.setLayout(layout);
		
		//Panel de botones
		JPanel panel_botones = new JPanel();
				
		//Panel de las peguntas
		JPanel panel_preguntas = new JPanel();
	
		this.setLayout(new BorderLayout());
		
		etiquetaNombre = new JLabel(ejercicio.getNombre());
		panel_etiquetas.add(etiquetaNombre);

		etiquetaFechaIni = new JLabel("Fecha de inicio:" + ejercicio.getFechaIni().getTime());
		panel_etiquetas.add(etiquetaFechaIni);
		
		etiquetaFechaFin = new JLabel("Fecha de final:" + ejercicio.getFechaFin().getTime());
		panel_etiquetas.add(etiquetaFechaFin);
		
		//SpringUtilities.makeCompactGrid(panel_etiquetas, 2, 2, 6, 6, 6, 6);
		
		
		botonCambiarEjercicio = new JButton("Cambiar Ejercicio");
		botonCambiarEjercicio.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCambiarEjercicio);
		
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		//layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//barajeamos las preguntas para que salgan en un orden aleatorio, distinto al introducido por el profesor
		if(ejercicio.getAleatorio() == true){
			ejercicio.barajarPreguntas();
		}
		
		for(Pregunta preguntaAux: ejercicio.getPreguntas()){
			JButton pregunta = new JButton("hola" + i);//preguntaAux.getEnunciado());
			panel_preguntas.add(pregunta);
			//layout.putConstraint(SpringLayout.NORTH, pregunta, i, SpringLayout.NORTH, etiquetaNombre);
			i += 30 /*Numero de pixeles necesarios para que queden separadas*/;
		}

		//Ponemos la derecha del botoncambiarApunte a 5 pixeles de la izquierda del contenedor 
		//layout.putConstraint(SpringLayout.EAST, botonCambiarEjercicio, 5, SpringLayout.WEST, this);
		
		//Ponemos el sur de la etiquetaFechas a 5 pixeles del sur del contenedor 
		//layout.putConstraint(SpringLayout.NORTH, etiquetaFechas, 5, SpringLayout.SOUTH, this);
		
		this.setPreferredSize(new Dimension(450, 150));
		//this.add(panel_etiquetas, BorderLayout.NORTH);
		//this.add(panel_botones, BorderLayout.SOUTH);
		this.add(panel_preguntas, BorderLayout.NORTH);
	}
	
}
