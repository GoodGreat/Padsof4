package paneles;

import javax.swing.*;
import ejercicio.*;

public class VistaPreguntaLibreProf extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaEnunciado;
	private JButton botonCambiarPregunta;
	private JLabel respuesta;
	private JTextField textRespuesta;
	
	public VistaPreguntaLibreProf(Pregunta pregunta){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		botonCambiarPregunta = new JButton("Cambiar Pregunta");
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 5, SpringLayout.NORTH, this);
		
		//Ponemos la derecha del botoncambiarApunte a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCambiarPregunta, 5, SpringLayout.WEST, this);
				
		//Ponemos el norte de la etiquetaTexto distanciada a 5 del norte de la etiquetaNombre
		layout.putConstraint(SpringLayout.NORTH, respuesta, 50, SpringLayout.NORTH, etiquetaEnunciado);
		layout.putConstraint(SpringLayout.WEST, textRespuesta, 50, SpringLayout.EAST, respuesta);
		
	}
	
}
