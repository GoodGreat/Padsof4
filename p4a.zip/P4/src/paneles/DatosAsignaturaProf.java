package paneles;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class DatosAsignaturaProf extends JPanel{
	private JLabel etiquetaNombre, etiquetaPassword;
	private JTextField textNia, textPassword;
	private JButton botonModificarAsignatura;
	
	public DatosAsignaturaProf(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel(/*Este llevara el nombre de la asgnatura*/);
		textPassword = new JTextField("<Password>", 20);
		
		//Ponemos la izquierda de la etiqueta del NIA a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.WEST, etiquetaNombre, 5, SpringLayout.WEST, this);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta del NIA del NORTE del contenedor
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta Password del SUR de la etiqueta Nia
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.SOUTH, etiquetaNombre);
	}
}