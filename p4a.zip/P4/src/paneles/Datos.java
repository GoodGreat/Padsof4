package paneles;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class Datos extends JPanel{
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNia, etiquetaPassword;
	private JTextField textNia, textPassword;
	private JButton botonLogin;
	
	/**
	 * Constructor del panel de Datos, con Spring Layout
	 * @author Alvaro Martinez de Navascues
	 */
	public Datos(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		//Creamos nuestros componentes
		etiquetaNia = new JLabel("NIA: ");
		etiquetaPassword = new JLabel ("PASSWORD: ");
		textNia = new JTextField("", 20);
		textPassword = new JTextField("", 20);
		botonLogin = new JButton("LOG-IN");
		
		
		//Ponemos la izquierda de la etiqueta del NIA a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.WEST, etiquetaNia, 5, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.WEST, etiquetaPassword, 5, SpringLayout.WEST, this);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta del NIA del NORTE del contenedor
		layout.putConstraint(SpringLayout.NORTH, etiquetaNia, 5, SpringLayout.NORTH, this);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta Password del SUR de la etiqueta Nia
		layout.putConstraint(SpringLayout.NORTH, etiquetaPassword, 5, SpringLayout.SOUTH, etiquetaNia);
		
		//Alineamos los dos campos de texto
		layout.putConstraint(SpringLayout.WEST, textNia, 100, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.WEST, textPassword, 100, SpringLayout.WEST, this);
		layout.putConstraint(SpringLayout.NORTH, textPassword, 5, SpringLayout.SOUTH, textNia);
		//Centramos el boton de login debajo del panel
		layout.putConstraint(SpringLayout.SOUTH, botonLogin, 0, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonLogin, 0, SpringLayout.HORIZONTAL_CENTER, this);
		botonLogin.setPreferredSize(new Dimension(100,50));
		
		this.add(etiquetaNia);
		this.add(etiquetaPassword);
		this.add(textNia);
		this.add(textPassword);
		this.add(botonLogin);
		this.setPreferredSize(new Dimension(400, 150));
	} 
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public String getNia(){
		return this.textNia.getText();
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en la PASSWORD
	 * @author Alvaro Martinez de Navascues
	 * @return String. La password del alumno/profesor
	 */
	public String getPassword(){
		return this.textPassword.getText();
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Login
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador){
		this.botonLogin.addActionListener(controlador);
	}
}
