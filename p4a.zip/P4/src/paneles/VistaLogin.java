package paneles;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

public class VistaLogin extends JPanel{
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNia, etiquetaPassword;
	private JTextField textNia, textPassword;
	private JButton botonLogin;
	
	/**
	 * Constructor del panel de Datos, con Spring Layout
	 * @author Alvaro Martinez de Navascues
	 */
	public VistaLogin(){
		//Panel de etiquetas
		SpringLayout layout = new SpringLayout();	
		JPanel panel_etiquetas = new JPanel();
		panel_etiquetas.setLayout(layout);
		//Panel de botones
		JPanel panel_botones = new JPanel();
		
		//Layout del JPanel principal
		this.setLayout(new BorderLayout());
		
		
		
		//Creamos nuestros componentes
		etiquetaNia = new JLabel("NIA: ");
		etiquetaPassword = new JLabel ("PASSWORD: ");
		textNia = new JTextField("", 15);
		textPassword = new JTextField("", 15);
		botonLogin = new JButton("LOG-IN");
		
		
		//Ponemos la izquierda de la etiqueta del NIA a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.WEST, etiquetaNia, 5, SpringLayout.WEST, panel_etiquetas);
		layout.putConstraint(SpringLayout.WEST, etiquetaPassword, 5, SpringLayout.WEST, panel_etiquetas);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta del NIA del NORTE del contenedor
		layout.putConstraint(SpringLayout.NORTH, etiquetaNia, 5, SpringLayout.NORTH, panel_etiquetas);
		
		//Distanciamos 5 pixeles el NORTE de la etiqueta Password del SUR de la etiqueta Nia
		layout.putConstraint(SpringLayout.NORTH, etiquetaPassword, 5, SpringLayout.SOUTH, etiquetaNia);
		
		//Alineamos los dos campos de texto
		layout.putConstraint(SpringLayout.WEST, textNia, 100, SpringLayout.WEST, panel_etiquetas);
		layout.putConstraint(SpringLayout.WEST, textPassword, 100, SpringLayout.WEST, panel_etiquetas);
		layout.putConstraint(SpringLayout.NORTH, textPassword, 5, SpringLayout.SOUTH, textNia);
		//Centramos el boton de login debajo del panel
		botonLogin.setPreferredSize(new Dimension(100,50));
		
		panel_etiquetas.add(etiquetaNia);
		panel_etiquetas.add(etiquetaPassword);
		panel_etiquetas.add(textNia);
		panel_etiquetas.add(textPassword);
		panel_botones.add(botonLogin);
		this.setPreferredSize(new Dimension(400, 150));
		this.add(panel_etiquetas, BorderLayout.CENTER);
		this.add(panel_botones, BorderLayout.SOUTH);
	} 
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el NIA
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public String getNia(){
		return this.textNia.getText();
	}
	
	/**
	 * Metodo que sirve para retornar el texto contenido en la PASSWORD
	 * @author Alvaro Martinez de Navascues
	 * @return String. La password del alumno/profesor
	 */
	public String getPassword(){
		return this.textPassword.getText();
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador al boton de Login
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
	public void setControlador(ActionListener controlador){
		this.botonLogin.addActionListener(controlador);
	}
}
