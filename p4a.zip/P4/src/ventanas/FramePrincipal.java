package ventanas;

import java.awt.*;
import javax.swing.*;
import paneles.*;

public class FramePrincipal extends JFrame {
	private static final long serialVersionUID = 1L;
	private JPanel cards;
	private Datos datos;
	final static String LOGINPANEL = "Carta con JButtons";
	final static String VISTAPROFPANEL = "Carta con JTextField"; 
	
	/**
	 * Constructor de la vista LOGIN
	 */
	public FramePrincipal (Datos datos){
		super("E-DUUDLE");
		this.datos = datos;
		//Creamos el container
		Container container = this.getContentPane();
		//Layout de Borde
		container.setLayout(new BorderLayout());
		
		//Aniadimos los componentes al container
		container.add(datos, BorderLayout.CENTER);
		
		//Colocar los componentes de acuerdo a sus tama�os
		this.pack();
		
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}	
}
