package controladoresProfesor;

import java.awt.event.*;
import java.util.Calendar;

import javax.swing.JOptionPane;

import asignatura.Tema;
import ejercicio.Ejercicio;
import panelesAlumno.*;
import panelesProfesor.VistaCambiarEjercicio;
import panelesProfesor.VistaCrearEjercicio;
import panelesProfesor.VistaEjercicioProf;
import panelesProfesor.VistaTemaProf;
import sistema.*;
import ventanas.*;

public class ControlVistaCambiarEjercicio implements ActionListener{
	private VistaCambiarEjercicio vista;
	private VistaEjercicioProf vista_ejercicioProf;
	private Ejercicio ejercicio;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCambiarEjercicio(VistaCambiarEjercicio vista, VistaEjercicioProf vista_ejercicioProf, Ejercicio ejercicio){
		this.vista = vista;
		this.vista_ejercicioProf = vista_ejercicioProf;
		this.ejercicio = ejercicio;
		
	}
	

	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if(event.getSource().equals(this.vista.getBotonAniadirPregunta()) && ((this.vista.getComboBoxPregunta().getSelectedItem().equals("Booleana")) == true)){
			this.vista.mostrarCrearPreguntaBooleana(ejercicio);
		} else if (event.getSource().equals(this.vista.getBotonAniadirPregunta()) && ((this.vista.getComboBoxPregunta().getSelectedItem().equals("Libre")) == true)){
			this.vista.mostrarCrearPreguntaLibre(ejercicio);
		} else if (event.getSource().equals(this.vista.getBotonAniadirPregunta()) && ((this.vista.getComboBoxPregunta().getSelectedItem().equals("Unica")) == true)){
			this.vista.mostrarCrearPreguntaUnica(ejercicio);
		} else if (event.getSource().equals(this.vista.getBotonAniadirPregunta()) && ((this.vista.getComboBoxPregunta().getSelectedItem().equals("Multipregunta")) == true)){
			this.vista.mostrarCrearMultipregunta(ejercicio);
		}
	
		if (event.getSource().equals(this.vista.getBotonGuardarCambios())){
			if (this.vista.getNombre().getText().equals("") == false){
				ejercicio.setNombre(this.vista.getNombre().getText());
			}
			if(this.vista.getPeso().getText().equals("") == false){
				ejercicio.setPeso(Float.valueOf(this.vista.getPeso().getText()));
			}
			if (this.vista.getAnoIni().getText().equals("") == false || this.vista.getMesIni().getText().equals("") == false ||
				this.vista.getDiaIni().getText().equals("") == false || this.vista.getHoraIni().getText().equals("") == false ||
				this.vista.getMinIni().getText().equals("") == false){
				if (this.vista.getAnoIni().getText().equals("") == false
						&& this.vista.getMesIni().getText().equals("") == false
						&& this.vista.getDiaIni().getText().equals("") == false
						&& this.vista.getHoraIni().getText().equals("") == false
						&& this.vista.getMinIni().getText().equals("") == false) {
					Calendar fechaIni = Calendar.getInstance();
					fechaIni.set(Integer.parseInt(this.vista.getAnoIni().getText()),
							Integer.parseInt(this.vista.getMesIni().getText()),
							Integer.parseInt(this.vista.getDiaIni().getText()),
							Integer.parseInt(this.vista.getHoraIni().getText()),
							Integer.parseInt(this.vista.getMinIni().getText()));
					ejercicio.setFechaIni(fechaIni);
				} else {
					JOptionPane.showMessageDialog(this.vista,
							"Para cambiar una fecha es necesario rellenar todos los campos de la misma", "Error",
							JOptionPane.ERROR_MESSAGE);
					this.vista.mostrarVistaPrincipalCambioEj();
					return;
				}
			}
			
			if (this.vista.getAnoFin().getText().equals("") == false || this.vista.getMesFin().getText().equals("") == false ||
				this.vista.getDiaFin().getText().equals("") == false || this.vista.getHoraFin().getText().equals("") == false ||
					this.vista.getMinFin().getText().equals("") == false){
					if (this.vista.getAnoFin().getText().equals("") == false
							&& this.vista.getMesFin().getText().equals("") == false
							&& this.vista.getDiaFin().getText().equals("") == false
							&& this.vista.getHoraFin().getText().equals("") == false
							&& this.vista.getMinFin().getText().equals("") == false) {
						Calendar fechaFin = Calendar.getInstance();
						fechaFin.set(Integer.parseInt(this.vista.getAnoFin().getText()),
								Integer.parseInt(this.vista.getMesFin().getText()),
								Integer.parseInt(this.vista.getDiaFin().getText()),
								Integer.parseInt(this.vista.getHoraFin().getText()),
								Integer.parseInt(this.vista.getMinFin().getText()));
						ejercicio.setFechaFin(fechaFin);
					} else {
						JOptionPane.showMessageDialog(this.vista,
								"Para cambiar una fecha es necesario rellenar todos los campos de la misma", "Error",
								JOptionPane.ERROR_MESSAGE);
						this.vista.mostrarVistaPrincipalCambioEj();
						return;
					}
				}
			
			ejercicio.setAleatorio(this.vista.getComboBoxSelectedAleat());
			
			if (this.vista.getComboBoxSelectedVis() == true){
				ejercicio.publicarEjercicio();
			}else{
				ejercicio.ocultarEjercicio();
			}
		
			JOptionPane.showMessageDialog(this.vista, "Se han guardado todos los cambios",
					"CAMBIAR DE EJERCICIO", JOptionPane.INFORMATION_MESSAGE);
			this.vista_ejercicioProf.mostrarVistaPrincipal();
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_ejercicioProf.mostrarVistaPrincipal();
		}else if (event.getSource().equals(this.vista.getBotonAniadirPregunta())){
			
		}
	}
}
