package controladoresProfesor;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import ejercicio.Multipregunta;
import ejercicio.Pregunta;
import ejercicio.PreguntaBooleana;
import ejercicio.PreguntaLibre;
import ejercicio.PreguntaUnica;
import panelesProfesor.*;

public class ControlVistaEjercicioProf implements ActionListener{
	private VistaEjercicioProf vista;
	private VistaTemaProf vista_tema;
	
	public ControlVistaEjercicioProf(VistaEjercicioProf vista, VistaTemaProf vista_tema){
		this.vista = vista;
		this.vista_tema = vista_tema;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_tema.mostrarVistaTemaProf();
			
		}else if(event.getSource().equals(this.vista.getBotonCambiarEjercicio())){
			
			this.vista.mostrarVistaCambiarEjercicio();
			
		} else if(event.getSource().equals(this.vista.getBotonIr())){
			
			 this.vista.getComboBoxPregunta().getSelectedItem();
			 Pregunta pregunta = (Pregunta)this.vista.getComboBoxPregunta().getSelectedItem();
			if(pregunta.getTipo().equals("Booleana")){
				PreguntaBooleana preg = (PreguntaBooleana) pregunta;
				this.vista.mostrarVistaPreguntaBooleana(preg, vista);
			} else if(pregunta.getTipo().equals("Unica")){	
				PreguntaUnica preg = (PreguntaUnica) pregunta;
				System.out.println("AKIII");
				this.vista.mostrarVistaPreguntaUnica(preg, vista);
			} else if(pregunta.getTipo().equals("Libre")){	
				PreguntaLibre preg = (PreguntaLibre) pregunta;
				this.vista.mostrarVistaPreguntaLibre(preg, vista);
			} else if(pregunta.getTipo().equals("Multipregunta")){
				Multipregunta preg = (Multipregunta) pregunta;
				this.vista.mostrarVistaMultipregunta(preg, vista);
			}
		}
	}
}
