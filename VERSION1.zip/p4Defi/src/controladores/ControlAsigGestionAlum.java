package controladores;

public class ControlAsigGestionAlum {

}
