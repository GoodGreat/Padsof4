package controladores;

import java.awt.event.*;

import javax.swing.JOptionPane;
import paneles.*;
import sistema.*;
import asignatura.*;
import ventanas.*;

public class ControlVistaAsignaturaProf implements ActionListener{
		private Asignatura asignatura; 
		private VistaAsignaturaProf vista;
		private VistaPrincipalProf vista_prof;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param sistema. Clase principal de nuestro proyecto
		 */
		public ControlVistaAsignaturaProf(VistaAsignaturaProf vista, VistaPrincipalProf vista_prof, Asignatura asignatura){
			this.vista = vista;
			this.vista_prof = vista_prof;
			this.asignatura = asignatura;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
			
			//El primer paso es validar lo introducido por el usuario
			if (event.getSource().equals(this.vista.getBotonCrearTema())){
				this.vista.mostrarVistaCrearTema();
			} else if(event.getSource().equals(this.vista.getBotonCambiarAsig())){
				this.vista.mostrarVistaCambiarAsignatura();
			} else if(event.getSource().equals(this.vista.getBotonCalcularNotaAlum())){
				
			}else if(event.getSource().equals(this.vista.getBotonVolver())){
				this.vista_prof.mostrarVistaPrincipalProf();
			}
			
			//Preguntar en clase, QUIEN DEBE DAR EL FEEDBACK, HACER COMPROBACIONES EN LA CORRECCION DE LO INTRODUCIDO
			//Realizamos la accion segun se pinche el boton LOG-IN
			//this.sistema.log_in(this.vista.getNia(), this.vista.getPassword());
			
			//Mostrar nueva vista
		}
	}