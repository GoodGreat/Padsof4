package controladoresProfesor;

import java.awt.event.*;

import asignatura.Asignatura;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaCambiarAsignatura;
import sistema.*;

public class ControlVistaCambiarAsignatura implements ActionListener{
	private VistaCambiarAsignatura vista;
	private Sistema sistema;
	private VistaAsignaturaProf vista_asig;
	private Asignatura asignatura;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCambiarAsignatura(VistaCambiarAsignatura vista, VistaAsignaturaProf vista_asignaturaProf, Asignatura asignatura){
		this.vista = vista;
		this.sistema = Sistema.getInstance();
		this.vista_asig = vista_asignaturaProf;
		this.asignatura = asignatura;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// SI NO ES O "" O EL NOMBRE QUE YA TENIA ANTES, CAMBIAMOS POR EL INTRODUCIDO POR EL USUARIO
		if (this.vista.getNombre().equals("") == false && this.vista.getNombre().equals(asignatura.getNombre()) == false) {
			for(int i=0; i < sistema.getAsignaturas().size(); i++){
				if( sistema.getAsignaturas().get(i).getNombre().equals(asignatura.getNombre()) == true){
					sistema.getAsignaturas().get(i).setNombre(this.vista.getNombre());
				}
			}
		}
		
		if(this.vista.getComboBoxSelected() == false && this.asignatura.getVisible() == true) {
			for(int i=0; i < sistema.getAsignaturas().size(); i++){
				if( sistema.getAsignaturas().get(i).getNombre().equals(asignatura.getNombre()) == true){
					sistema.getAsignaturas().get(i).ocultarAsignatura();
						
				}
			}
		}else if(this.vista.getComboBoxSelected() == true && this.asignatura.getVisible() == false){
			for(int i=0; i < sistema.getAsignaturas().size(); i++){
				if( sistema.getAsignaturas().get(i).getNombre().equals(asignatura.getNombre()) == true){
					sistema.getAsignaturas().get(i).ocultarAsignatura();
							
				}
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_asig.mostrarVistaPrincipalProf();
		}
		
		this.vista_asig.mostrarVistaPrincipalProf();
	}
}