package panelesProfesor;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.*;

import asignatura.Asignatura;
import sistema.*;

public class VistaGestionAlumnos extends JPanel {
	private static final long serialVersionUID = 1L;
	private JList<Alumno> listaAlumMat;
	private DefaultListModel<Alumno> modeloLista1;
	private JList<Alumno> listaAlumExp;
	private DefaultListModel<Alumno> modeloLista2;
	private Asignatura asignatura;
	private JLabel titulo, etiquetaAlumnos1, etiquetaAlumnos2;
	private JButton botonVolver, botonExpulsar, botonReadmitir;

	public VistaGestionAlumnos(Asignatura asignatura){
		this.asignatura = asignatura;
		
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		titulo = new JLabel("GESTION DE ALUMNOS");
		titulo.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.add(titulo);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, titulo, 0, SpringLayout.HORIZONTAL_CENTER, this);
		layout.putConstraint(SpringLayout.NORTH, titulo, 30, SpringLayout.NORTH, this);
		
		etiquetaAlumnos1 = new JLabel("Alumnos matriculados en " + asignatura.getNombre());
		this.add(etiquetaAlumnos1);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos1, -200, SpringLayout.HORIZONTAL_CENTER, this);
		layout.putConstraint(SpringLayout.NORTH, etiquetaAlumnos1, 10, SpringLayout.SOUTH, titulo);
		
		etiquetaAlumnos2 = new JLabel("Alumnos expulsados de " + asignatura.getNombre());
		this.add(etiquetaAlumnos2);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos2, 200, SpringLayout.HORIZONTAL_CENTER, this);
		layout.putConstraint(SpringLayout.NORTH, etiquetaAlumnos2, 10, SpringLayout.SOUTH, titulo);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 30));
		this.add(botonVolver);
		
		//Constraints
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 0, SpringLayout.NORTH, titulo);
		layout.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this);
		
		botonExpulsar = new JButton("Expulsar");
		this.add(botonExpulsar);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonExpulsar, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos1);
		layout.putConstraint(SpringLayout.SOUTH, botonExpulsar, -40, SpringLayout.SOUTH, this);
		
		botonReadmitir = new JButton("Readmitir");
		this.add(botonReadmitir);
		
		//Constraints
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonReadmitir, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos2);
		layout.putConstraint(SpringLayout.SOUTH, botonReadmitir, -40, SpringLayout.SOUTH, this);
		
		//PRIMERA LISTA
		this.modeloLista1 = new DefaultListModel<Alumno>();
		for (Alumno alumnoAux: asignatura.getAlumnos()){
			this.modeloLista1.addElement(alumnoAux);
		}
		this.listaAlumMat = new JList<Alumno>(this.modeloLista1);
		
		listaAlumMat.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane panel_listaAlumMat = new JScrollPane(listaAlumMat);
		panel_listaAlumMat.setPreferredSize(new Dimension(390, 300));
		
		this.add(panel_listaAlumMat);
		
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, panel_listaAlumMat, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos1);
		layout.putConstraint(SpringLayout.NORTH, panel_listaAlumMat, 10, SpringLayout.SOUTH, etiquetaAlumnos1);
		
		//SEGUNDA LISTA
		this.modeloLista2 = new DefaultListModel<Alumno>();
		for (Expulsion expulsionAux: Sistema.getInstance().getExpulsiones()){
			if (expulsionAux.getAsignatura().getNombre().equals(asignatura.getNombre())){
				this.modeloLista2.addElement(expulsionAux.getAlumno());
			}
		}
		this.listaAlumExp = new JList<Alumno>(this.modeloLista2);
		
		listaAlumExp.getSelectionModel().setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		JScrollPane panel_listaAlumExp = new JScrollPane(listaAlumExp);
		panel_listaAlumExp.setPreferredSize(new Dimension(390, 300));
		
		this.add(panel_listaAlumExp);
		
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, panel_listaAlumExp, 0, SpringLayout.HORIZONTAL_CENTER, etiquetaAlumnos2);
		layout.putConstraint(SpringLayout.NORTH, panel_listaAlumExp, 10, SpringLayout.SOUTH, etiquetaAlumnos2);
	}

	/**
	 * Metodo que asigna los controladores a los botones de esta Vista. Tambien asigna controlador a la Lista
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador de los botones
	 * @param controlador_lista. Controlador de la lista
	 */
	public void setControlador(ActionListener controlador) {
		this.botonVolver.addActionListener(controlador);
		this.botonExpulsar.addActionListener(controlador);
		this.botonReadmitir.addActionListener(controlador);		
	}
	
	/**
	 * Metodo que actualiza la Lista 1
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizarListaAlumMat(){
		this.modeloLista1.removeAllElements();
		for (Alumno alumnoAux: asignatura.getAlumnos()){
			this.modeloLista1.addElement(alumnoAux);
		}
	}
	
	/**
	 * Metodo que actualiza la Lista 2
	 * @author Alejandro Martin Climent
	 */
	public void actualizarListaAlumExp(){
		this.modeloLista2.removeAllElements();
		for (Expulsion expulsionAux: Sistema.getInstance().getExpulsiones()){
			if (expulsionAux.getAsignatura().getNombre().equals(asignatura.getNombre())){
				this.modeloLista2.addElement(expulsionAux.getAlumno());
			}
		}
	}
	
	/**
	 * Getter de la lista de alumnos matriculas
	 * @return JList. La lista
	 */
	public JList<Alumno> getListaAlumMat() {
		return listaAlumMat;
	}

	/**
	 * Getter del modelo de la lista 1
	 * @return DefaultListModel. Modelo de la lista1
	 */
	public DefaultListModel<Alumno> getModeloLista1() {
		return modeloLista1;
	}

	/**
	 * Getter de la lista de alumnos expulsados
	 * @return JList. La lista
	 */
	public JList<Alumno> getListaAlumExp() {
		return listaAlumExp;
	}

	/**
	 * Getter del modelo de la lista 2
	 * @return DefaultListModel. Modelo de la lista2
	 */
	public DefaultListModel<Alumno> getModeloLista2() {
		return modeloLista2;
	}

	/**
	 * Getter del atributo asignatura
	 * @return Asignatura. La asignatura
	 */
	public Asignatura getAsignatura() {
		return asignatura;
	}

	/**
	 * Getter del Boton Volver
	 * @return JButton. El boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
	
	/**
	 * Getter del Boton Expulsar
	 * @return JButton. El boton
	 */
	public JButton getBotonExpulsar() {
		return botonExpulsar;
	}

	/**
	 * Getter del Boton Readmitir
	 * @return JButton. El boton
	 */
	public JButton getBotonReadmitir() {
		return botonReadmitir;
	}
}
