package panelesProfesor;

import java.awt.*;
import java.awt.event.ActionListener;
import javax.swing.*;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;
import asignatura.*;
import controladoresProfesor.ControlArbolAsignatura;
import controladoresProfesor.ControlArbolTema;
import controladoresProfesor.ControlVistaApunteProf;
import controladoresProfesor.ControlVistaCambiarAsignatura;
import controladoresProfesor.ControlVistaCambiarTema;
import controladoresProfesor.ControlVistaCrearApunte;
import controladoresProfesor.ControlVistaCrearEjercicio;
import controladoresProfesor.ControlVistaCrearSubtema;
import controladoresProfesor.ControlVistaCrearTema;
import controladoresProfesor.ControlVistaEjercicioProf;
import controladoresProfesor.ControlVistaTemaProf;
import ejercicio.Ejercicio;

public class VistaTemaProf extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private Tema tema;
	private VistaAsignaturaProf vista_asignatura;
	final static String PROF_ASIGPANEL = "Carta con la vista de asignatura del Profesor";
	final static String PROF_TEMAPANEL = "Carta con la vista de tema del Profesor";
	final static String PROF_EJERCICIOPANEL = "Carta con la vista de ejercicio del Profesor";
	final static String PROF_APUNTEPANEL = "Carta con la vista de apunte del Profesor";
	final static String PROF_SUBTEMA = "Carta con la vista de subtema del Profesor";
	final static String CREARSUBTEMA = "Carta con la vista de crear subtema";
	final static String CREAREJERCICIO = "Carta con la vista de crearEjercicio";
	final static String CREARAPUNTE = "Carta con la vista de crear apunte";
	final static String CAMBIARTEMA = "Carta con la vista de cambiar tema";
	private JPanel principal_tema;
	private JLabel etiquetaNombre;
	private JButton botonCrearSubtema;
	private JButton botonCrearEjercicio;
	private JButton botonCrearApunte;
	private JButton botonCambiarTema;
	private JButton botonVolver;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	private JTree arbol;
	
	public VistaTemaProf(Tema tema, VistaAsignaturaProf vista_asignatura){
		this.vista_asignatura = vista_asignatura;
		CardLayout card_layout = new CardLayout();
		this.setLayout(card_layout);
		
		this.tema = tema;
		SpringLayout layout = new SpringLayout();
		
		principal_tema = new JPanel();
		principal_tema.setLayout(layout);
	

		//Panel de etiquetas
		JPanel panel_etiquetas = new JPanel();
						
		//Panel de botones
		JPanel panel_botones = new JPanel();
				
		//Panel del arbol de contenido 
		JPanel panel_arbol = new JPanel();
		
		principal_tema.setLayout(new BorderLayout());
		
			
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel(tema.getNombre());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		panel_etiquetas.add(etiquetaNombre);
		
		botonCrearSubtema = new JButton("Crear Subtema");
		botonCrearSubtema.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCrearSubtema);
		
		botonCrearEjercicio = new JButton("Crear Ejercicio");
		botonCrearEjercicio.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCrearEjercicio);
		
		botonCrearApunte = new JButton("Crear Apunte");
		botonCrearApunte.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCrearApunte);
		
		botonCambiarTema = new JButton("Cambiar Tema");
		botonCambiarTema.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonCambiarTema);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(150,75));
		panel_botones.add(botonVolver);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode(tema.getNombre());
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		 modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		 this.arbol = new JTree (modelo);
		 
				
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(200, 200));
		arbol.getSelectionModel().setSelectionMode(TreeSelectionModel.SINGLE_TREE_SELECTION);		
		// Para a�adir hijos a un nodo usamos el m�todo insertNodeInto del modelo. El m�todo recibe el nodo
		// a insertar, el nodo padre donde se inserta, y la posici�n del nodo entre los hijos del padre.
		construirArbol(tema ,raiz);

		panel_arbol.add(arbol);

		this.setPreferredSize(new Dimension(700, 300));
		this.principal_tema.add(panel_etiquetas, BorderLayout.NORTH);
		this.principal_tema.add(panel_botones, BorderLayout.SOUTH);
		this.principal_tema.add(panel_arbol, BorderLayout.EAST);
	
		this.add(principal_tema);
		this.add(principal_tema, PROF_TEMAPANEL);
		
		VistaCrearApunte vista_crearApunte = new VistaCrearApunte();
		ControlVistaCrearApunte control_crearApunte = new ControlVistaCrearApunte(vista_crearApunte, this, this.tema);
		vista_crearApunte.setControlador(control_crearApunte);
		this.add(vista_crearApunte, CREARAPUNTE);
		
		VistaCrearEjercicio vista_crearEjercicio = new VistaCrearEjercicio();
		ControlVistaCrearEjercicio control_crearEjercicio = new ControlVistaCrearEjercicio(vista_crearEjercicio, this, this.tema);
		vista_crearEjercicio.setControlador(control_crearEjercicio);
		this.add(vista_crearEjercicio, CREAREJERCICIO);
		
		VistaCrearSubtema vista_crearSubtema = new VistaCrearSubtema();
		ControlVistaCrearSubtema control_crearSubtema = new ControlVistaCrearSubtema(vista_crearSubtema, this, this.tema);
		vista_crearSubtema.setControlador(control_crearSubtema);
		this.add(vista_crearSubtema, CREARSUBTEMA);
		
		VistaCambiarTema vista_cambiarTema = new VistaCambiarTema();
		ControlVistaCambiarTema control_cambiarTema = new ControlVistaCambiarTema(vista_cambiarTema, this, this.tema);
		vista_cambiarTema.setControlador(control_cambiarTema);
		this.add(vista_cambiarTema, CAMBIARTEMA);	
	}
	
	public void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
				DefaultMutableTreeNode nodo_ejer = new DefaultMutableTreeNode(ejercicioAux);
				modelo.insertNodeInto(nodo_ejer, raiz, i);
				i++;
		}
		//Aniadimos Apuntes
		for(Apunte apunteAux: tema.getApuntes()){
			DefaultMutableTreeNode nodo_apunte = new DefaultMutableTreeNode(apunteAux);
			modelo.insertNodeInto(nodo_apunte, raiz, i);
				i++;
		}
		
		//Aniadimos Subtemas
		for(Tema temaAux: tema.getSubtemas()){
			DefaultMutableTreeNode nodo_tema= new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			i++;
		}
			//construirArbol(temaAux, nodo_subtema);
	}
	
	
	/**
	 * Metodo que sirve para actualizar el estado del arbol de tema
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizarArbol(){
		
		//Borrar el arbol
		raiz.removeAllChildren();
		modelo.reload();
		
		//Actualizar el arbol
		int i = 0;
		//Aniadimos Ejercicios
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
				DefaultMutableTreeNode nodo_ejer = new DefaultMutableTreeNode(ejercicioAux);
				modelo.insertNodeInto(nodo_ejer, raiz, i);
				i++;
		}
		//Aniadimos Apuntes
		for(Apunte apunteAux: tema.getApuntes()){
			DefaultMutableTreeNode nodo_apunte = new DefaultMutableTreeNode(apunteAux);
			modelo.insertNodeInto(nodo_apunte, raiz, i);
				i++;
		}
		
		//Aniadimos Subtemas
		for(Tema temaAux: tema.getSubtemas()){
			DefaultMutableTreeNode nodo_tema= new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			i++;
		}
		
	}
	
	/**
	 * Metodo que sirve para actualizar el estado del Tema
	 * @author �lvaro Martinez de Navascues
	 */
	public void actualizar(){
		this.etiquetaNombre.setText(tema.getNombre());
	}
	
	/**
     * Getter del boton "CrearAsignatura"
     * @author Alejandro Martin Climent
     * @return JButton.
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
		
	/**
     * Getter del boton "CrearAsignatura"
     * @author Alejandro Martin Climent
     * @return JButton.
	 */
	public JButton getBotonCrearSubtema() {
		return botonCrearSubtema;
	}
	
	/**
	 * Getter del boton "CrearAsignatura"
	 * @author Alejandro Martin Climent
	 * @return JButton.
    */
	public JButton getBotonCrearEjercicio() {
		return botonCrearEjercicio;
	}
		
	 /**
	 * Getter del boton "Registrar Alumno"
	 * @author �lvaro Martinez de Navascues
	 * @return JButton.
	*/
	public JButton getBotonCrearApunte() {
		return botonCrearApunte;
	}	
	
	 /**
	 * Getter del boton "Registrar Alumno"
	 * @author �lvaro Martinez de Navascues
	 * @return JButton.
	 */
	public JButton getBotonCambiarTema() {
		return botonCambiarTema;
	}
	
	/**
	 * Metodo que sirve para aniadir un controlador a los botones de esta vista
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador que se quiere asignar
	 */
    public void setControlador(ActionListener controlador, ControlArbolTema control_arbol){
		this.botonCrearSubtema.addActionListener(controlador);
		this.botonCrearEjercicio.addActionListener(controlador);
	    this.botonCrearApunte.addActionListener(controlador);
	 	this.botonCambiarTema.addActionListener(controlador);
	 	this.botonVolver.addActionListener(controlador);
	 	
	 	//Controlador del arbol
	 	arbol.addTreeSelectionListener(control_arbol);
	}
    
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCrearSubtema(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CREARSUBTEMA);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCrearEjercicio(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CREAREJERCICIO);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCrearApunte(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CREARAPUNTE);
	}
	
	/**
	 * Metodo que muestra la vista principal del profesor
	 * @author Alejandro Martin Climent 
	 */
	public void mostrarVistaCambiarTema(){
		this.actualizarArbol();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, CAMBIARTEMA);
	}

	/**
	 * Metodo que muestra la vista del Tema de esta clase
	 * @author �lvaro Martinez de Navascues
	 */
	public void mostrarVistaTemaProf() {
		actualizarArbol();
		actualizar();
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PROF_TEMAPANEL);
	}
		
	/**
	 * Metodo que muestra la vista de un Ejercicio para un profesor
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param ejercicio. Ejercicio del cual se quiere mostrar la vista
	 */
	public void mostrarVistaEjercicioProf(Ejercicio ejercicio) {
		VistaEjercicioProf vista_ejercicioProf = new VistaEjercicioProf(ejercicio, this);
		ControlVistaEjercicioProf control_ejercicioProf = new ControlVistaEjercicioProf(vista_ejercicioProf, this);
		vista_ejercicioProf.setControlador(control_ejercicioProf);
		this.add(vista_ejercicioProf, PROF_EJERCICIOPANEL);
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PROF_EJERCICIOPANEL);
	}
	
	/**
	 * Metodo que muestra la vista de un Subtema para un profesor
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @param subtema. SubTema del cual se quiere mostrar la vista
	 */
	public void mostrarVistaSubtemaProf(Tema subtema){
		VistaTemaProf vista_subtema = new VistaTemaProf(subtema, this.vista_asignatura);
		ControlVistaTemaProf control_tema = new ControlVistaTemaProf(vista_subtema, subtema);
		ControlArbolTema control_arbol = new ControlArbolTema(vista_subtema);
		vista_subtema.setControlador(control_tema, control_arbol);
		this.add(vista_subtema, PROF_SUBTEMA);
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PROF_SUBTEMA);		
	}
	
	/**
	 * Metodo que muestra la vista de un apunte para un profesor
	 * 
	 * @author Alejandro Martin Climent
	 * @param apunte. Apunte del cual se quiere mostrar la vista
	 */
	public void mostrarVistaApunteProf(Apunte apunte) {
		this.actualizarArbol();
		this.actualizar();
		VistaApunteProf vista_apunte = new VistaApunteProf(apunte);
		ControlVistaApunteProf control_apunte = new ControlVistaApunteProf(vista_apunte, this);
		vista_apunte.setControlador(control_apunte);
		this.add(vista_apunte, PROF_APUNTEPANEL);
		CardLayout cl = (CardLayout)(this.getLayout());
		cl.show(this, PROF_APUNTEPANEL);
	}
    
	/**
	 * Getter del atributo Raiz
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @return DefaultMutableTreeNode. Raiz del arbol
	 */
    public DefaultMutableTreeNode getRaiz() {
		return raiz;
	}

    /**
     * Getter del atributo arbol
     * 
     * @author Alejandro Martin Climent
     * @return JTree. El arbol
     */
	public JTree getArbol() {
		return arbol;
	}

	/**
	 * Getter del atributo Tema
	 * 
	 * @author �lvaro Martinez de Navascues
	 * @return Tema. El tema
	 */
	public Tema getTema() {
		return tema;
	}
	
	/**
	 * Getter de la vista de la asignatura
	 * 
	 * @author Alejandor Martin Climent
	 * @return VistaAsignaturaProf. La vista de la asignatura
	 */
	public VistaAsignaturaProf getVistaAsignatura(){
		return this.vista_asignatura;
	}
}