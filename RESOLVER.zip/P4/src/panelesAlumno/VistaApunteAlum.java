package panelesAlumno;

import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionListener;

import javax.swing.*;
import asignatura.*;

public class VistaApunteAlum extends JPanel{

	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JLabel etiquetaTexto;
	private JButton botonVolver;
	
	/**
	 * Constructor de la vista de Apunte para Alumno
	 * @param apunte. Apunte del que se hace la vista
	 */
	public VistaApunteAlum(Apunte apunte){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		etiquetaNombre = new JLabel(apunte.getTitulo());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.BOLD, 20));
		this.add(etiquetaNombre);
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaNombre, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		etiquetaTexto = new JLabel(apunte.getContenido());
		etiquetaNombre.setFont(new Font("Rockwell Extra Bold", Font.ITALIC, 12));
		this.add(etiquetaTexto);
		
		layout.putConstraint(SpringLayout.NORTH, etiquetaTexto, 50, SpringLayout.SOUTH, this.etiquetaNombre);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaTexto, 0, SpringLayout.HORIZONTAL_CENTER, this.etiquetaNombre);
		
		botonVolver = new JButton("Volver");
		botonVolver.setPreferredSize(new Dimension(100, 40));
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 0, SpringLayout.NORTH, this.etiquetaNombre);
		layout.putConstraint(SpringLayout.WEST, botonVolver, 20, SpringLayout.WEST, this);
		
		this.setPreferredSize(new Dimension(800, 350));
	}

	/**
	 * Getter del boton Volver
	 * @return JButton. El boton
	 */
	public JButton getBotonVolver() {
		return botonVolver;
	}
	
	/**
	 * Metodo que asigna el controlador a los botones de esta vista
	 * @param controlador. El controlador asignado
	 */
	public void setControlador(ActionListener controlador){
		this.botonVolver.addActionListener(controlador);
	}	
}
