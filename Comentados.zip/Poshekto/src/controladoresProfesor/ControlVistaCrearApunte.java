package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.Tema;
import panelesProfesor.VistaCrearApunte;
import panelesProfesor.VistaTemaProf;
import sistema.*;

/**
 * Clase que se encargara de controlar la creacion de un apunte
 * @author �lvaro
 *
 */
public class ControlVistaCrearApunte implements ActionListener{
	private VistaCrearApunte vista;
	private Sistema sistema;
	private Tema tema;
	private VistaTemaProf vista_tema;
	
	/**
	 * Constructor del controlador de la VistaCrearApunte
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param vista_TemaProf, la vista de un tema del profesor
	 * @param tema, el tema que se en el que se creara ese apunte
	 */
	public ControlVistaCrearApunte(VistaCrearApunte vista, VistaTemaProf vista_tema, Tema tema){
		this.vista = vista;
		this.sistema = Sistema.getInstance();
		this.vista_tema = vista_tema;
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (event.getSource().equals(this.vista.getBotonCrearApunte())){
			if (this.vista.getNombre().equals("") || this.vista.getContenido().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos los campos", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else if (sistema.crearApunte(tema, this.vista.getNombre(), this.vista.getComboBoxSelected(),
					this.vista.getContenido()) == false) {
				JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error", JOptionPane.ERROR_MESSAGE);
			} else {
				JOptionPane.showMessageDialog(this.vista,
						"El apunte " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE APUNTE",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_tema.mostrarVistaTemaProf();
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_tema.mostrarVistaTemaProf();
		}
	}
}

