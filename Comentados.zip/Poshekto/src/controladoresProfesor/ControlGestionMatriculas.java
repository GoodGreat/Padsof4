package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import panelesProfesor.VistaGestionMatriculas;
import panelesProfesor.VistaPrincipalProf;
import sistema.*;

public class ControlGestionMatriculas implements ActionListener{
	private VistaGestionMatriculas  vista;
	private VistaPrincipalProf vista_principalProf;
	private Solicitud solicitud;
	
	/**
	 * Constructor del controlador de la VistaGestionMatriculas
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param vista_principalProf. Vista principal del profesor
	 */
	public ControlGestionMatriculas(VistaGestionMatriculas vista, VistaPrincipalProf vista_principalProf){
		this.vista = vista;
		this.vista_principalProf =  vista_principalProf;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonAceptarMatricula())){
			if (this.vista.getLista().getSelectedValue() != null){
				this.solicitud = this.vista.getLista().getSelectedValue();
				Sistema.getInstance().aceptarSolicitud(solicitud);
				this.vista.getModeloLista().removeElement(solicitud);
				JOptionPane.showMessageDialog(this.vista,"Se ha admitido a " + solicitud.getAlumno().getNombre() + " "+
						solicitud.getAlumno().getApellido() + " en " + solicitud.getAsignatura().getNombre(), "ADMISION ALUMNO",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_principalProf.mostrarVistaGestionMatriculas();
			}else{
				JOptionPane.showMessageDialog(this.vista, "Seleccione una de las solicitudes", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}else if (event.getSource().equals(this.vista.getBotonDenegarMatricula())){
			if (this.vista.getLista().getSelectedValue() != null){
				this.solicitud = this.vista.getLista().getSelectedValue();
				Sistema.getInstance().denegarSolicitud(solicitud);
				JOptionPane.showMessageDialog(this.vista,"No se ha admitido a " + solicitud.getAlumno().getNombre() +
						" "+ solicitud.getAlumno().getApellido() + " en " + solicitud.getAsignatura().getNombre(), "ADMISION ALUMNO",
						JOptionPane.INFORMATION_MESSAGE);
				this.vista_principalProf.mostrarVistaGestionMatriculas();
			}else{
				JOptionPane.showMessageDialog(this.vista, "Seleccione una de las solicitudes", "Error",
						JOptionPane.ERROR_MESSAGE);
			}
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_principalProf.mostrarVistaPrincipalProf();
		}
	}
}
