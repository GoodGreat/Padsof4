package paneles;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import sistema.*;
import asignatura.*;
import ejercicio.*;



public class DatosPrincipalProf extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JButton botonCrearAsig;
	private JButton botonRegistrarAlumno;
	private JButton botonGestionSolicitudes;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	
	
	public DatosPrincipalProf(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel("MENU PRINCIPAL");
		botonCrearAsig = new JButton("Crear Asignatura");
		botonRegistrarAlumno =  new JButton("Registrar Alumno");
		botonGestionSolicitudes = new JButton("Gesti�n Solicitudes");
		int i = 0;
		int j = 0;		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//Ponemos la derecha del botonCrearAsig a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCrearAsig, 5, SpringLayout.WEST, this);
				
		//Ponemos el norte del botonRegistrarAlumno a 5 pixeles al sur del botonCrearAsig
		layout.putConstraint(SpringLayout.NORTH, botonRegistrarAlumno, 5, SpringLayout.SOUTH, botonCrearAsig);
				
		//Ponemos el norte del botonGestionSolicitudes a 5 pixeles de la sur del botonRegistrarAlumno
		layout.putConstraint(SpringLayout.NORTH, botonGestionSolicitudes, 5, SpringLayout.SOUTH, botonRegistrarAlumno);
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode("Asignaturas");
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		 modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		JTree arbol = new JTree (modelo);
		
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(200, 40));
		
		Sistema sistema = Sistema.getInstance();
		
		// Para a�adir hijos a un nodo usamos el m�todo insertNodeInto del modelo. El m�todo recibe el nodo
		// a insertar, el nodo padre donde se inserta, y la posici�n del nodo entre los hijos del padre.
		for(Asignatura asignaturaAux: sistema.getAsignaturas()){
			DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(asignaturaAux);
			modelo.insertNodeInto(nodo_asignatura, raiz, i);
			j = 0;
			for(Tema temaAux: asignaturaAux.getTemas()){
				DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_tema, nodo_asignatura, j);
				construirArbol(temaAux, nodo_tema);
				j++;
			}
			i++;
		}

		//Ponemos el ComboBox a 30 pixeles al sur de la etiquetaNombre
		layout.putConstraint(SpringLayout.NORTH, arbol, 30, SpringLayout.NORTH, etiquetaNombre);
			
	}
	
	public void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		 
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
			modelo.insertNodeInto(new DefaultMutableTreeNode(ejercicioAux), nodo, i);
			i++;
		}
		
		for(Apunte apunteAux: tema.getApuntes()){
			modelo.insertNodeInto(new DefaultMutableTreeNode(apunteAux), nodo, i);
			i++;
		}
		for(Tema temaAux: tema.getSubtemas()){
			DefaultMutableTreeNode nodo_subtema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_subtema, nodo, i);
			i++;
			
			construirArbol(temaAux, nodo_subtema);
		}
	}

}