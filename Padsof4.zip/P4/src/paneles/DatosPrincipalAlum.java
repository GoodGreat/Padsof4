package paneles;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;

import sistema.Sistema;
import asignatura.*;
import ejercicio.Ejercicio;
public class DatosPrincipalAlum extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	
	public DatosPrincipalAlum(){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		int i = 0;
		int j = 0;	
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel("MENU PRINCIPAL");
		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);


		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode("Asignaturas");
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		 modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		JTree arbol = new JTree (modelo);
		
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(200, 40));
		
		Sistema sistema = Sistema.getInstance();
		
		// Para a�adir hijos a un nodo usamos el m�todo insertNodeInto del modelo. El m�todo recibe el nodo
		// a insertar, el nodo padre donde se inserta, y la posici�n del nodo entre los hijos del padre.
		for(Asignatura asignaturaAux: sistema.getAsignaturas()){
			if(asignaturaAux.getVisible()== true){
				DefaultMutableTreeNode nodo_asignatura = new DefaultMutableTreeNode(asignaturaAux);
				modelo.insertNodeInto(nodo_asignatura, raiz, i);
				j = 0;
				for(Tema temaAux: asignaturaAux.getTemas()){
					if(temaAux.getVisible() == true){
						DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
						modelo.insertNodeInto(nodo_tema, nodo_asignatura, j);
						construirArbol(temaAux, nodo_tema);
						j++;
					}
				}
				i++;
			}
		}	

		//Ponemos el ComboBox a 30 pixeles al sur de la etiquetaNombre
		layout.putConstraint(SpringLayout.NORTH, arbol, 30, SpringLayout.NORTH, etiquetaNombre);
			
	}
	
	public void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		 
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
			if(ejercicioAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(ejercicioAux), nodo, i);
				i++;
			}
		}
		
		for(Apunte apunteAux: tema.getApuntes()){
			if(apunteAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(apunteAux), nodo, i);
				i++;
			}
		}
		for(Tema temaAux: tema.getSubtemas()){
			if(temaAux.getVisible() == true){
				DefaultMutableTreeNode nodo_subtema = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_subtema, nodo, i);
				i++;
				construirArbol(temaAux, nodo_subtema);
			}
		}
	}
		
}
	
	
	