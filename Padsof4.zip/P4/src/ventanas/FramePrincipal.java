package ventanas;

import java.awt.*;
import javax.swing.*;

import controladores.ControlVistaLogin;
import paneles.*;

public class FramePrincipal extends JFrame {
	private static final long serialVersionUID = 1L;
	final static String LOGINPANEL = "Carta con el LOGIN";
	final static String VISTAPROFPANEL = "Carta con la vista del Profesor";
	final static String VISTAESTUDPANEL = "Carta con la vista del Alumno";
	
	/**
	 * Constructor de la vista LOGIN
	 */
	public FramePrincipal (){
		super("E-DUUDLE");
		super.setFont(new Font(Font.SERIF, Font.BOLD, 13));
		//Layout de Card
		
		Container container = this.getContentPane();
		container.setLayout(new CardLayout());
		
		//
		VistaLogin vista_login = new VistaLogin();
		ControlVistaLogin controlador = new ControlVistaLogin(vista_login, this);
		vista_login.setControlador(controlador);
		
		//Aniadimos los componentes al container
		container.add(vista_login, LOGINPANEL);
		//Colocar los componentes de acuerdo a sus tama�os
		this.pack();
		this.setVisible(true);
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	public void mostrarLogin(){
		CardLayout cl = (CardLayout)(this.getContentPane().getLayout());
		cl.show(this.getContentPane(), LOGINPANEL);
	}
}
