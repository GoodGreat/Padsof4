package paneles;

import java.awt.*;
import javax.swing.*;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import asignatura.*;
import ejercicio.Ejercicio;
public class DatosAsignaturaProf extends JPanel{
	
	private static final long serialVersionUID = 1L;
	private JLabel etiquetaNombre;
	private JButton botonGestionAlum ;
	private JButton botonCambiarAsig;
	private JButton botonCalcularNota;
	private JButton botonCrearTema;
	private DefaultMutableTreeNode raiz;
	private DefaultTreeModel modelo;
	
	public DatosAsignaturaProf(Asignatura asignatura){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		//Creamos nuestros componentes
		etiquetaNombre = new JLabel(asignatura.getNombre());
		botonCrearTema = new JButton("Crear Tema");
		botonGestionAlum = new JButton("Gesti�n Alumnos");
		botonCambiarAsig =  new JButton("Cambiar Asignatura");
		botonCalcularNota = new JButton("Calcular Nota");
		int i = 0;
		
		//Ponemos el norte de la etiqueta del Nombre de la asignatura a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaNombre, 5, SpringLayout.NORTH, this);
		
		//Ponemos la derecha del botonCrearTema a 5 pixeles de la izquierda del contenedor 
		layout.putConstraint(SpringLayout.EAST, botonCrearTema, 5, SpringLayout.WEST, this);
				
		//Ponemos el norte del botonGestionAlum a 5 pixeles al sur del botonCrearTema
		layout.putConstraint(SpringLayout.NORTH, botonGestionAlum, 5, SpringLayout.SOUTH, botonCrearTema);
				
		//Ponemos el norte del botonCambiarAsig a 5 pixeles de la sur del botonGestionAlum
		layout.putConstraint(SpringLayout.NORTH, botonCambiarAsig, 5, SpringLayout.SOUTH, botonGestionAlum);
		
		//Ponemos el norte del botonCalcularNota a 5 pixeles de la sur del botonCambiarAsig
		layout.putConstraint(SpringLayout.NORTH, botonCalcularNota, 5, SpringLayout.SOUTH, botonCambiarAsig);
	
		
		// Crear el nodo ra�z del �rbol, pasando el texto que mostrar�
	    raiz = new DefaultMutableTreeNode(asignatura.getNombre());
	    
		// Crear el modelo de datos del �rbol, pasando el nodo ra�z
		 modelo = new DefaultTreeModel(raiz);
		 
		// Crear el �rbol, pas�ndole el modelo de datos
		JTree arbol = new JTree (modelo);

				
		// Podemos fijar el tama�o del �rbol
		arbol.setPreferredSize(new Dimension(200, 40));
				
		// Para a�adir hijos a un nodo usamos el m�todo insertNodeInto del modelo. El m�todo recibe el nodo
		// a insertar, el nodo padre donde se inserta, y la posici�n del nodo entre los hijos del padre.
		
		for(Tema temaAux: asignatura.getTemas()){
			DefaultMutableTreeNode nodo_tema = new DefaultMutableTreeNode(temaAux);
			modelo.insertNodeInto(nodo_tema, raiz, i);
			construirArbol(temaAux, nodo_tema);
			i++;
		}


		//Ponemos el ComboBox a 30 pixeles al sur de la etiquetaNombre
		layout.putConstraint(SpringLayout.NORTH, arbol, 30, SpringLayout.NORTH, etiquetaNombre);
			
	}
	
	public void construirArbol(Tema tema, DefaultMutableTreeNode nodo){
		int i = 0;
		 
		for(Ejercicio ejercicioAux: tema.getEjercicios()){
			if(ejercicioAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(ejercicioAux), nodo, i);
				i++;
			}
		}
		
		for(Apunte apunteAux: tema.getApuntes()){
			if(apunteAux.getVisible() == true){
				modelo.insertNodeInto(new DefaultMutableTreeNode(apunteAux), nodo, i);
				i++;
			}
		}
		for(Tema temaAux: tema.getSubtemas()){
			if(temaAux.getVisible() == true){
				DefaultMutableTreeNode nodo_subtema = new DefaultMutableTreeNode(temaAux);
				modelo.insertNodeInto(nodo_subtema, nodo, i);
				i++;
				construirArbol(temaAux, nodo_subtema);
			}
		}

		
	}
	
	
}