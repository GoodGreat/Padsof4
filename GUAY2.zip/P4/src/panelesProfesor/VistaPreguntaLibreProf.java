package panelesProfesor;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionListener;

import javax.swing.*;

import ejercicio.*;

public class VistaPreguntaLibreProf extends JPanel{

	private static final long serialVersionUID = 1L;
	final static String PRINCIPAL = "Carta con la vista de la pregunta del Profesor";
	private JLabel etiquetaEnunciado, etiquetaPuntuacion;
	private JButton botonCambiarPregunta, botonAniadirSolucion, botonEliminarSolucion, botonVolver;
	private JLabel etiquetaSoluciones;
	private JComboBox<Opcion> comboBoxSoluciones;
	private JTextField textAniadirSol;
	private PreguntaLibre pregunta;
	private VistaEjercicioProf vista_ej;
	
	public VistaPreguntaLibreProf(PreguntaLibre pregunta, VistaEjercicioProf vista_ej){
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		this.vista_ej = vista_ej;
		this.pregunta = pregunta;
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		this.add(etiquetaEnunciado);
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaEnunciado, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		if(pregunta.getFalloResta() == true){
			etiquetaPuntuacion = new JLabel("Esta pregunta vale: " + pregunta.getPuntuacion() +
					" puntos, y en caso de fallo resta: "+ pregunta.getResta() + "puntos");
		} else {
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y  no resta en caso de fallo");
		}
		
		this.add(etiquetaPuntuacion);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaPuntuacion, 20, SpringLayout.SOUTH, etiquetaEnunciado);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaPuntuacion, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		this.setPreferredSize(new Dimension(800, 350));
		
		botonCambiarPregunta = new JButton("Cambiar Pregunta");
		this.add(botonCambiarPregunta);
		
		layout.putConstraint(SpringLayout.SOUTH, botonCambiarPregunta, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonCambiarPregunta, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		botonVolver = new JButton("Volver");
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonVolver, -300, SpringLayout.HORIZONTAL_CENTER, this);
		
		Opcion[] opciones = new Opcion[pregunta.getOpciones().size()];
		
		int i =0;
		
		for(i=0; i < pregunta.getOpciones().size(); i++){
			{
					opciones[i] = pregunta.getOpciones().get(i);
			}
		}
		
		botonAniadirSolucion = new JButton("Aniadir Solucion");
		this.add(botonAniadirSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirSolucion, 150, SpringLayout.HORIZONTAL_CENTER, this);
		
		
		botonEliminarSolucion = new JButton("Eliminar Solucion");
		this.add(botonEliminarSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarSolucion, 300, SpringLayout.HORIZONTAL_CENTER, this);

		etiquetaSoluciones = new JLabel("Soluciones: ");
		this.add(etiquetaSoluciones);
		layout.putConstraint(SpringLayout.NORTH, etiquetaSoluciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaSoluciones, -200, SpringLayout.EAST, this);
		
		if(pregunta.getRespuestaProf() != null){
			Opcion[] opciones2 = new Opcion[pregunta.getRespuestaProf().getOpciones().size()];
			
			for(i=0; i < pregunta.getRespuestaProf().getOpciones().size(); i++){
				{
						opciones2[i] = pregunta.getRespuestaProf().getOpciones().get(i);
				}
			}
			
			comboBoxSoluciones = new JComboBox<Opcion>(opciones2);
			this.add(comboBoxSoluciones);

			
			layout.putConstraint(SpringLayout.EAST, comboBoxSoluciones, -200, SpringLayout.EAST, this);
			layout.putConstraint(SpringLayout.NORTH, comboBoxSoluciones, 200, SpringLayout.NORTH, this);
		}	
	
	
		
		textAniadirSol = new JTextField(10);
		this.add(textAniadirSol);
		
		layout.putConstraint(SpringLayout.EAST, textAniadirSol, -183, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.SOUTH, textAniadirSol, -20, SpringLayout.NORTH, botonAniadirSolucion);
	}
	
	
	public void actualizar(){
		this.removeAll();
		
		SpringLayout layout = new SpringLayout();
		this.setLayout(layout);
		
		etiquetaEnunciado = new JLabel(pregunta.getEnunciado());
		this.add(etiquetaEnunciado);
		layout.putConstraint(SpringLayout.NORTH, etiquetaEnunciado, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaEnunciado, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		if(pregunta.getFalloResta() == true){
			etiquetaPuntuacion = new JLabel("Esta pregunta vale: " + pregunta.getPuntuacion() +
					" puntos, y en caso de fallo resta: "+ pregunta.getResta() + "puntos");
		} else {
			etiquetaPuntuacion = new JLabel("Esta pregunta vale:" + pregunta.getPuntuacion() +
					"y  no resta en caso de fallo");
		}
		
		this.add(etiquetaPuntuacion);
		
		//Ponemos el norte de la etiqueta del Nombre del Apunte a 5 pixeles al norte del contenedor 
		layout.putConstraint(SpringLayout.NORTH, etiquetaPuntuacion, 20, SpringLayout.SOUTH, etiquetaEnunciado);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, etiquetaPuntuacion, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
	
		botonCambiarPregunta = new JButton("Cambiar Pregunta");
		this.add(botonCambiarPregunta);
		
		layout.putConstraint(SpringLayout.SOUTH, botonCambiarPregunta, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonCambiarPregunta, 0, SpringLayout.HORIZONTAL_CENTER, this);
		
		
		
		botonVolver = new JButton("Volver");
		this.botonVolver.setPreferredSize(new Dimension(100,50));
		this.add(botonVolver);
		
		layout.putConstraint(SpringLayout.NORTH, botonVolver, 10, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonVolver, -300, SpringLayout.HORIZONTAL_CENTER, this);
		
		Opcion[] opciones = new Opcion[pregunta.getOpciones().size()];
		
		int i =0;
		
		for(i=0; i < pregunta.getOpciones().size(); i++){
			{
					opciones[i] = pregunta.getOpciones().get(i);
			}
		}
		
		
		
		botonAniadirSolucion = new JButton("Aniadir Solucion");
		this.add(botonAniadirSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonAniadirSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonAniadirSolucion, 150, SpringLayout.HORIZONTAL_CENTER, this);
		
		
		botonEliminarSolucion = new JButton("Eliminar Solucion");
		this.add(botonEliminarSolucion);
		
		layout.putConstraint(SpringLayout.SOUTH, botonEliminarSolucion, -5, SpringLayout.SOUTH, this);
		layout.putConstraint(SpringLayout.HORIZONTAL_CENTER, botonEliminarSolucion, 300, SpringLayout.HORIZONTAL_CENTER, this);

		etiquetaSoluciones = new JLabel("Soluciones: ");
		this.add(etiquetaSoluciones);
		
		if(pregunta.getRespuestaProf() != null){
			Opcion[] opciones2 = new Opcion[pregunta.getRespuestaProf().getOpciones().size()];
			
			for(i=0; i < pregunta.getRespuestaProf().getOpciones().size(); i++){
				{
						opciones2[i] = pregunta.getRespuestaProf().getOpciones().get(i);
				}
			}
			
			comboBoxSoluciones = new JComboBox<Opcion>(opciones2);
			this.add(comboBoxSoluciones);

			
			layout.putConstraint(SpringLayout.EAST, comboBoxSoluciones, -200, SpringLayout.EAST, this);
			layout.putConstraint(SpringLayout.NORTH, comboBoxSoluciones, 200, SpringLayout.NORTH, this);
		}	
		

		//Constraints
		layout.putConstraint(SpringLayout.NORTH, etiquetaSoluciones, 175, SpringLayout.NORTH, this);
		layout.putConstraint(SpringLayout.EAST, etiquetaSoluciones, -200, SpringLayout.EAST, this);		

		
		//Creamos nuestros componentes
		textAniadirSol = new JTextField(10);
		this.add(textAniadirSol);
		
		layout.putConstraint(SpringLayout.EAST, textAniadirSol, -183, SpringLayout.EAST, this);
		layout.putConstraint(SpringLayout.SOUTH, textAniadirSol, -20, SpringLayout.NORTH, botonAniadirSolucion);
	}
	
	/**
	* Getter del boton "Aniadir Solucion"
	* @author Alejandro Martin Climent
	* @return JButton.
	*/
	public JButton getBotonAniadirSolucion() {
		 return botonAniadirSolucion;
    }
	
	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton.
	*/
	public JButton getBotonVolver() {
		 return botonVolver;
    }

	/**
	* Getter del boton "CrearAsignatura"
	* @author Alejandro Martin Climent
	* @return JButton.
	*/
	public JButton getBotonEliminarSolucion() {
		 return botonEliminarSolucion;
    }
	
	/**
	 * Metodo que sirve para retornar el texto contenido en el MinFin
	 * @author Alejandro Martin Climent
	 * @return String. El NIA del alumno/Login del profesor
	 */
	public JTextField getTextAniadirSol(){
		return this.textAniadirSol;
	}
	
	
	/**
	 * Metodo que sirve para retornar el texto contenido en la PASSWORD
	 * @author Alvaro Martinez de Navascues
	 * @return String. La password del alumno/profesor
	 */
	public JComboBox<Opcion> getcomboBoxSoluciones(){
		return comboBoxSoluciones;
	}
	

	/**
	 * Metodo que asigna el controlador a los botones de esta vista
	 * @author �lvaro Martinez de Navascues
	 * @param controlador. Controlador de los botones
	 */
	public void setControlador(ActionListener controlador){
	
		this.botonCambiarPregunta.addActionListener(controlador);
		this.botonAniadirSolucion.addActionListener(controlador);
		this.botonEliminarSolucion.addActionListener(controlador);
		this.botonVolver.addActionListener(controlador);
	}

	/**
	 * Getter de la vista del ejercicio
	 * @return VistaEjercicioProf. La vista
	 */
	public VistaEjercicioProf getVista_ej() {
		return vista_ej;
	}

}
