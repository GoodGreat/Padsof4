package controladoresAlumno;

import java.awt.event.*;

import panelesAlumno.*;

public class ControlVistaTemaAlum implements ActionListener{
	private VistaTemaAlum vista;
	private VistaAsignaturaAlum vista_asig;

	/**
	 * Constructor del controlador de la Vista Tema Alum
	 * 
	 * @author Alejandro Martin
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaTemaAlum(VistaTemaAlum vista, VistaAsignaturaAlum vista_asig) {
		this.vista = vista;
		this.vista_asig = vista_asig;
	}

	@Override
	public void actionPerformed(ActionEvent event) {
		if (event.getSource().equals(this.vista.getBotonVolver())) {
			this.vista_asig.mostrarVistaAsignaturaAlum();
		}
	}
}