package controladoresAlumno;

import java.awt.event.*;

import javax.swing.JOptionPane;
import sistema.*;
import asignatura.*;
import ejercicio.Multipregunta;
import ejercicio.Multirrespuesta;
import ejercicio.Opcion;
import ejercicio.Pregunta;
import ejercicio.PreguntaUnica;
import ejercicio.RespuestaUnica;
import panelesAlumno.VistaEjercicioAlum;
import panelesAlumno.VistaMultipreguntaAlum;
import panelesProfesor.VistaEjercicioProf;
import panelesProfesor.VistaMultipreguntaProf;
import panelesProfesor.VistaPreguntaBooleanaProf;
import panelesProfesor.VistaPreguntaUnicaProf;

public class ControlVistaMostrarMultipreguntaAlum implements ActionListener{
		private Multipregunta pregunta; 
		private VistaMultipreguntaAlum vista;
		private VistaEjercicioAlum vistaEjer;
		
		/**
		 * Constructor del controlador de la Vista LOGIN
		 * @author Alejandro Martin
		 * @param vista. Panel que ve el usuario
		 * @param vista_Alum. Panel de la vista principal del Alum
		 */
		public ControlVistaMostrarMultipreguntaAlum(VistaMultipreguntaAlum vista, VistaEjercicioAlum vistaEjer, Multipregunta pregunta){
			this.vista = vista;
			this.vistaEjer = vistaEjer;
			this.pregunta = pregunta;	
		}
		
		@Override
		public void actionPerformed(ActionEvent event) {
				if(event.getSource().equals(this.vista.getBotonVolver())){
					vistaEjer.mostrarVistaPrincipal();
				}else if (event.getSource().equals(this.vista.getBotonEnviarRespuesta())){
					
					/*if(this.vista.getTextAniadirOp().getText().equals("")){
						JOptionPane.showMessageDialog(this.vista, "Es obligatorio el campo de la opcion", "Error",
								JOptionPane.ERROR_MESSAGE);
						System.out.println("Deberia0");
						vistaEjer.mostrarVistaMultipreguntaAlum(pregunta, vistaEjer);
				}else{
					System.out.println("Deberia1");
					String opcion = this.vista.getTextAniadirOp().getText();
					Opcion opcion1 = new Opcion(opcion);
					
					if(pregunta.pregAniadirOpcion(opcion1) == false){
						JOptionPane.showMessageDialog(this.vista, "Error al crear la opcion", "Error",
								JOptionPane.ERROR_MESSAGE);
						vistaEjer.mostrarVistaMultipregunta(pregunta, vistaEjer);
					}
				}
		*/}
	}
}