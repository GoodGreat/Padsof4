package controladoresAlumno;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import panelesAlumno.VistaApunteAlum;
import panelesAlumno.VistaTemaAlum;

public class ControlVistaApunteAlum implements ActionListener{
	
	private VistaApunteAlum vista;
	private VistaTemaAlum vista_temaAlum;
	
	/**
	 * Constructor del controlador de la vista de Apunte
	 * @param vista. Vista del apunte.
	 * @param vista_temaAlum. Vista del tema.
	 */
	public ControlVistaApunteAlum(VistaApunteAlum vista, VistaTemaAlum vista_temaAlum){
		this.vista = vista;
		this.vista_temaAlum = vista_temaAlum;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		 if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_temaAlum.mostrarVistaTemaAlum();
		}
	}
}
