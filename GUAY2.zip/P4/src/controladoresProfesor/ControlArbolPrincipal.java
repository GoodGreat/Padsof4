package controladoresProfesor;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import asignatura.Asignatura;
import asignatura.Tema;
import interfaces.NodoInterfaz;
import panelesProfesor.VistaPrincipalProf;
import sistema.Sistema;

public class ControlArbolPrincipal implements TreeSelectionListener{
	private VistaPrincipalProf vista_prof;
	
	public ControlArbolPrincipal(VistaPrincipalProf vista_prof){
		this.vista_prof = vista_prof;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent event) {
		if (((DefaultMutableTreeNode) event.getPath().getLastPathComponent()).getChildCount() > 0
				|| ((DefaultMutableTreeNode) event.getPath().getLastPathComponent())
						.equals(this.vista_prof.getRaiz())) {
			// No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
		} else {
			if (((DefaultMutableTreeNode) this.vista_prof.getArbol().getLastSelectedPathComponent()) != null) {
				NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_prof.getArbol()
						.getLastSelectedPathComponent()).getUserObject();
				if (nodo.getObjectClassName().equals("Asignatura")) {
					for (Asignatura asignaturaAux: Sistema.getInstance().getAsignaturas()){
						if (asignaturaAux.getNombre().equals(((Asignatura) nodo).getNombre())){
							Asignatura asignatura = asignaturaAux;
							this.vista_prof.mostrarVistaAsignatura(asignatura);
						}
					}					
				}
			}
		}
	}
}
