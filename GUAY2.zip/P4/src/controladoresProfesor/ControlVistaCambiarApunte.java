package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;

import asignatura.Apunte;
import panelesProfesor.VistaApunteProf;
import panelesProfesor.VistaCambiarApunte;

public class ControlVistaCambiarApunte implements ActionListener{
	private VistaCambiarApunte vista;
	private VistaApunteProf vista_apunteProf;
	private Apunte apunte;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCambiarApunte(VistaCambiarApunte vista, VistaApunteProf vista_apunteProf, Apunte apunte){
		this.vista = vista;
		this.vista_apunteProf = vista_apunteProf;
		this.apunte = apunte;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// SI NO ES O "" O EL NOMBRE QUE YA TENIA ANTES, CAMBIAMOS POR EL INTRODUCIDO POR EL USUARIO
		if (event.getSource().equals(this.vista.getBotonGuardarCambios())){
			if (this.vista.getNombre().getText().equals("") == false
					&& this.vista.getNombre().equals(apunte.getTitulo()) == false) {
				apunte.setTitulo(this.vista.getNombre().getText());
			}
			
			if (this.vista.getContenido().getText().equals("") == false 
					&& this.vista.getContenido().getText().equals(apunte.getContenido()) == false){
				apunte.setContenido(this.vista.getContenido().getText());
			}

			if (this.vista.getComboBoxVisible().getSelectedItem().equals("Oculto") && this.apunte.getVisible() == true) {
				apunte.ocultarApunte();
			} else if (this.vista.getComboBoxVisible().getSelectedItem().equals("Visible") && this.apunte.getVisible() == false) {
				apunte.publicarApunte();
			}
			JOptionPane.showMessageDialog(this.vista, "Se han guardado todos los cambios",
					"CAMBIAR TEMA", JOptionPane.INFORMATION_MESSAGE);
			this.vista_apunteProf.actualizar();
			this.vista_apunteProf.mostrarVistaApunteProf();
		}else if (event.getSource().equals(this.vista.getBotonVolver())){
			this.vista_apunteProf.mostrarVistaApunteProf();
		}
	}
}
