package controladoresProfesor;

import java.awt.event.*;
import asignatura.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaTemaProf;
import sistema.Sistema;

public class ControlVistaTemaProf implements ActionListener {
	private VistaTemaProf vista;
	private Tema tema;

	/**
	 * Constructor del controlador de la Vista LOGIN
	 * 
	 * @author Alejandro Martin
	 * @param vista.
	 *            Panel que ve el usuario
	 * @param sistema.
	 *            Clase principal de nuestro proyecto
	 */
	public ControlVistaTemaProf(VistaTemaProf vista, Tema tema) {
		this.vista = vista;
		this.tema = tema;
	}

	@Override
	public void actionPerformed(ActionEvent event) {

		if (event.getSource().equals(this.vista.getBotonCrearSubtema())) {
			this.vista.mostrarVistaCrearSubtema();
		} else if (event.getSource().equals(this.vista.getBotonCrearEjercicio())) {
			this.vista.mostrarVistaCrearEjercicio();
		} else if (event.getSource().equals(this.vista.getBotonCrearApunte())) {
			this.vista.mostrarVistaCrearApunte();
		} else if (event.getSource().equals(this.vista.getBotonCambiarTema())) {
			this.vista.mostrarVistaCambiarTema();
		} else if (event.getSource().equals(this.vista.getBotonVolver())) {
			this.vista.getVistaAsignatura().mostrarVistaPrincipalProf();
		}
	}
}