package controladoresProfesor;

import java.awt.event.*;
import javax.swing.JOptionPane;
import asignatura.*;
import panelesAlumno.*;
import panelesProfesor.VistaAsignaturaProf;
import panelesProfesor.VistaCrearSubtema;
import panelesProfesor.VistaCrearTema;
import panelesProfesor.VistaTemaProf;
import sistema.*;
import ventanas.*;

public class ControlVistaCrearSubtema implements ActionListener{
	private VistaCrearSubtema vista;
	private VistaTemaProf vista_tema;
	private VistaAsignaturaProf vista_asignatura;
	private Tema tema;
	
	/**
	 * Constructor del controlador de la Vista LOGIN
	 * @author �lvaro Martinez de Navascues
	 * @param vista. Panel que ve el usuario
	 * @param sistema. Clase principal de nuestro proyecto
	 */
	public ControlVistaCrearSubtema(VistaCrearSubtema vista, VistaTemaProf vista_tema, Tema tema){
		this.vista = vista;
		this.vista_asignatura = vista_asignatura;
		this.vista_tema = vista_tema;
		this.tema = tema;
	}
	
	@Override
	public void actionPerformed(ActionEvent event) {
		// El primer paso es validar lo introducido por el usuario
		if (event.getSource().equals(this.vista.getbotonCrearSubtema())) {
			
			if (this.vista.getNombre().equals("")) {
				JOptionPane.showMessageDialog(this.vista, "Es obligatorio rellenar todos los campos", "Error",
						JOptionPane.ERROR_MESSAGE);
			} else {
				if (this.vista.getComboBoxSelected() == false) {
					System.out.println("Estoy aqui");
					Tema subtema = new Tema(this.vista.getNombre(), false);
					if (this.tema.aniadirSubtema(subtema) == false) {
						JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
								JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(this.vista,
								"El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA",
								JOptionPane.INFORMATION_MESSAGE);
						this.vista_tema.mostrarVistaTemaProf();
					}
				}else{
					Tema subtema = new Tema(this.vista.getNombre(), true);
					if (this.tema.aniadirSubtema(subtema) == false) {
						JOptionPane.showMessageDialog(this.vista, "Error al crear el tema", "Error",
								JOptionPane.ERROR_MESSAGE);
					} else {
						JOptionPane.showMessageDialog(this.vista,
								"El tema " + this.vista.getNombre() + " ha sido creado con exito", "CREACION DE TEMA",
								JOptionPane.INFORMATION_MESSAGE);
						this.vista_tema.mostrarVistaTemaProf();
					}
				}
			}
		} else if (event.getSource().equals(this.vista.getBotonVolver())) {
			this.vista_tema.mostrarVistaTemaProf();
		}
	}
}
