package controladores;

import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import asignatura.Asignatura;
import asignatura.Tema;
import interfaces.NodoInterfaz;
import paneles.VistaPrincipalProf;

public class ControlArbol implements TreeSelectionListener{
	private DefaultMutableTreeNode nodo;
	private VistaPrincipalProf vista_prof;
	
	public ControlArbol(VistaPrincipalProf vista_prof){
		this.vista_prof = vista_prof;
	}
	
	@Override
	public void valueChanged(TreeSelectionEvent e) {
		if (((DefaultMutableTreeNode) e.getPath().getLastPathComponent()).getChildCount() > 0|| ((DefaultMutableTreeNode) e.getPath().getLastPathComponent()).equals(this.vista_prof.getRaiz())){
				//No hacer nada si se selecciona un nodo con al menos un hijo, o si es la raiz
			}else{
			NodoInterfaz nodo = (NodoInterfaz) ((DefaultMutableTreeNode) this.vista_prof.getArbol().getLastSelectedPathComponent()).getUserObject();
			
			if (nodo.getObjectClassName().equals("Asignatura")) {
				Asignatura asignatura = (Asignatura) nodo;
				this.vista_prof.mostrarVistaAsignatura(asignatura);
			}else if (nodo.getObjectClassName().equals("Tema")){
				Tema tema = (Tema) nodo;
			}/* else {
				JOptionPane.showMessageDialog(new FramePrincipal(), nodo.getClass(), "Error",
						JOptionPane.ERROR_MESSAGE);
			}*/
			}		
	}

}
